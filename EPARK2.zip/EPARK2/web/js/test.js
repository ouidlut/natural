//test.js

$(function(){

    $("#service_id").change(function() {
      //document.getElementById("plan_info").style.display="none";
      var service_id = $('#service_id').val();
      var url = "http://172.16.249.154/marutoku_nyuukai_and_keiyaku/silex_front/web/index_dev.php/goods/plan.json?service_id="+ service_id;

          $.ajax({
            type: "GET",
            scriptCharset: 'utf-8',
            dataType:'json',
            url: url,
            success: function(options){
                var html = "<option value='0'>選択してください</option>";
                for(var i=0; i<options.length;i++){
                     html += "<option value='"+options[i]['plan_id']+"'>"+options[i]['plan_name']+"</options>"
                     if(options[i]['plan_id']!=0 && options.length>1) {
                       $("#plan_id").prop('disabled', false);
                     }
                     else {
                       $("#plan_id").prop('disabled', true);
                     }
                }
                $("#plan_id").html(html);
            }
          });

          if ($("#plan_id").change(function(){
                  var plan_id = $('#plan_id').val();
                  var url2 = "http://172.16.249.154/marutoku_nyuukai_and_keiyaku/silex_front/web/index_dev.php/goods/goods.json?service_id="+ service_id +"&plan_id="+plan_id;
                  $.ajax({
                  type: "GET",
                  scriptCharset: 'utf-8',
                  dataType:'json',
                  url: url2,
                  success: function(data){
                    console.dir(data);
                    var quantity = $('#quantity').val();
                    $('company').text(data.company);
                    $('#fee').text(data.fee);
                    $('#subscription_fee').text(data.subscription_fee);
                    $('#monthly_fee').text(data.monthly_fee);
                    $('#amount').text(data.amount);
                    $('#times').text(data.times);
                    $('#start_month').text(data.start_month);
                    $('#total_monthly_fee').text(parseInt(data.monthly_fee) * quantity);
                    $('#total_fee').text(parseInt(data.fee) * quantity);
                    $('#total_subscription_fee').text(parseInt(data.subscription_fee) * quantity);
                    $('#cancellation_penalty').text(data.cancellation_penalty);
                    $('#total_monthly_fee_with_tokutokuwari').text(parseInt(data.monthly_fee) * quantity - parseInt(data.amount) * quantity);
                    document.getElementById("plan_info").style.display="block";
                  }
                });
                if ($("#quantity").change(function(){

                        var url2 = "http://172.16.249.154/marutoku_nyuukai_and_keiyaku/silex_front/web/index_dev.php/goods/goods.json?service_id="+ service_id +"&plan_id="+plan_id;
                        $.ajax({
                        type: "GET",
                        scriptCharset: 'utf-8',
                        dataType:'json',
                        url: url2,
                        success: function(data){
                          console.dir(data);
                          var quantity = $('#quantity').val();
                          console.log(quantity);
                          $('#company').text(data.company);
                          $('#fee').text(data.fee);
                          $('#subscription_fee').text(data.subscription_fee);
                          $('#monthly_fee').text(data.monthly_fee);
                          $('#amount').text(data.amount);
                          $('#times').text(data.times);
                          $('#start_month').text(data.start_month);
                          $('#total_monthly_fee').text(parseInt(data.monthly_fee) * quantity);
                          $('#total_fee').text(parseInt(data.fee) * quantity);
                          $('#total_subscription_fee').text(parseInt(data.subscription_fee) * quantity);
                          $('#cancellation_penalty').text(data.cancellation_penalty);
                          $('#total_monthly_fee_with_tokutokuwari').text(parseInt(data.monthly_fee) * quantity - parseInt(data.amount) * quantity);
                          document.getElementById("plan_info").style.display="block";
                        }
                      });
                }));
          }));
　　　});
});

// function serviceChange(){
//
//       document.getElementById("plan_info").style.display="none";
//       var service_id = $('#service_id').val();
//       var url = "http://172.16.249.154/marutoku_nyuukai_and_keiyaku/silex_front/web/index_dev.php/goods/plan.json?service_id="+ service_id;
//
//           $.ajax({
//             type: "GET",
//             scriptCharset: 'utf-8',
//             dataType:'json',
//             url: url,
//             success: function(options){
//                 var html = "<option value='0'>選択してください</option>";
//                 for(var i=0; i<options.length;i++){
//                      html += "<option value='"+options[i]['plan_id']+"'>"+options[i]['plan_name']+"</options>"
//                      if(options[i]['plan_id']!=0 && options.length>1) {
//                        $("#plan_id").prop('disabled', false);
//                      }
//                      else {
//                        $("#plan_id").prop('disabled', true);
//                      }
//                 }
//                 $("#plan_id").html(html);
//             }
//           });
//
// }
//
// function planChange(){
//
//                   var plan_id = $('#plan_id').val();
//                   var url2 = "http://172.16.249.154/marutoku_nyuukai_and_keiyaku/silex_front/web/index_dev.php/goods/goods.json?service_id="+ service_id +"&plan_id="+plan_id;
//                   $.ajax({
//                   type: "GET",
//                   scriptCharset: 'utf-8',
//                   dataType:'json',
//                   url: url2,
//                   success: function(data){
//                     console.dir(data);
//                     var quantity = $('#quantity').val();
//                     $('#company').text(data.company);
//                     $('#fee').text(data.fee);
//                     $('#subscription_fee').text(data.subscription_fee);
//                     $('#monthly_fee').text(data.monthly_fee);
//                     $('#amount').text(data.amount);
//                     $('#times').text(data.times);
//                     $('#start_month').text(data.start_month);
//                     $('#total_monthly_fee').text(parseInt(data.monthly_fee) * quantity);
//                     $('#total_fee').text(parseInt(data.fee) * quantity);
//                     $('#total_subscription_fee').text(parseInt(data.subscription_fee) * quantity);
//                     $('#cancellation_penalty').text(data.cancellation_penalty);
//                     $('#total_monthly_fee_with_tokutokuwari').text(parseInt(data.monthly_fee) * quantity - parseInt(data.amount) * quantity);
//                     document.getElementById("plan_info").style.display="block";
//                   }
//                 });
// }
//
// function quantityChange(){
//                         var url2 = "http://172.16.249.154/marutoku_nyuukai_and_keiyaku/silex_front/web/index_dev.php/goods/goods.json?service_id="+ service_id +"&plan_id="+plan_id;
//                         $.ajax({
//                         type: "GET",
//                         scriptCharset: 'utf-8',
//                         dataType:'json',
//                         url: url2,
//                         success: function(data){
//                           console.dir(data);
//                           var quantity = $('#quantity').val();
//                           console.log(quantity);
//                           $('#total_monthly_fee').text(parseInt(data.monthly_fee) * quantity);
//                           $('#total_fee').text(parseInt(data.fee) * quantity);
//                           $('#total_subscription_fee').text(parseInt(data.subscription_fee) * quantity);
//                           $('#cancellation_penalty').text(data.cancellation_penalty);
//                           $('#total_monthly_fee_with_tokutokuwari').text(parseInt(data.monthly_fee) * quantity - parseInt(data.amount) * quantity);
//                           document.getElementById("plan_info").style.display="block";
//                         }
//                       });
// }
//
//
//
