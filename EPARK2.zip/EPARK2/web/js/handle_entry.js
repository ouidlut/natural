function onServiceNameEntry()
{
  $('#service_id'){
    
  }
}
