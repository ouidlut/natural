$(function () {
  'use strict';
  var point = 1;
  var li_num = 4;
  var li_total_num = $('.pagination li').children().length / 2;
  var total_num = ($('.pagination li').children().length -4) / 2;
  
  var movePager = function (point, li_num) {
    for (var i = 2; i < li_total_num; i++) {
      if (i >= point + 1 && i <= point + 1 + li_num) {
        $('.pagination li:nth-child('+ i +')').show();
      } else {
        $('.pagination li:nth-child('+ i +')').hide();
      }
    }
  };
  var addPoint = function () {
    if (1 <= point && total_num - li_num > point) point++;
  };
  var decPoint = function () {
    if (1 < point) point--;
  };
  
  $('.pager_pre').on('click', function() {
    decPoint();
    movePager(point, li_num);
  });
  
  $('.pager_next').on('click', function() {
    addPoint();
    movePager(point, li_num);
  });

});
