//product.js
$(function(){
  'use strict';
  //サービス名、プラン名から商品情報取得処理
  var url = location.protocol;
  url    += '//' + location.host;
  url    += location.pathname;
  var plan_url = url.replace(/\/entry\/.*/, '/goods/plan.json');
  var goods_url = url.replace(/\/entry\/.*/, '/goods/goods.json');

  var getGoodsJson = function (service_id, plan_id) {
    return $.ajax({
      type: "GET",
      url: goods_url,
      data: {'service_id' : service_id, 'plan_id' : plan_id}
    });
  };

  var getPlanJson = function (service_id) {
    return $.ajax({
      type: "GET",
      url: plan_url,
      data: {'service_id' : service_id}
    });
  };

  var getGoods = function(onload) {
    var onload_flag = onload || false;
    var service_id = $('#service_id').val();
    var plan_id = $('#plan_id_name').val();
    if (service_id == 9
        || service_id == 17
        || service_id == 18) {
      var plan_id = 0;
    }

    getGoodsJson(service_id, plan_id).done(function (data) {
      var quantity = $('div#quantity input').val() ? parseInt($('div#quantity input').val()) : 0;
      if ($('div#quantity input').prop('disabled')) {
        quantity = 1;
      }
      $('div#company p').text(data.company);
      $('div#fee p').text(data.fee);
      if (!onload_flag) {
        $('div#subscription_fee input,#subscription_fee_flag').val(data.subscription_fee);
        $('div#monthly_fee input,#monthly_fee').val(data.monthly_fee);
      }
      $('div#amount p').text(data.amount);
      $('div#times p').text(data.times);
      $('div#start_month p').text(data.start_month);
      $('div#total_monthly_fee p').text(parseInt(data.monthly_fee) * quantity);
      $('div#total_fee p').text(parseInt(data.fee) * quantity);
      $('div#total_subscription_fee p').text(parseInt(data.subscription_fee) * quantity);
      $('div#cancellation_penalty p').text(data.cancellation_penalty);
      $('div#total_monthly_fee_with_tokutokuwari p').text(
        parseInt(data.monthly_fee) * quantity - parseInt(data.amount) * quantity
      );
      if (!data) {
        $('div#company p').text('-');
        $('div#fee p').text('-');
        $('div#subscription_fee input').val('-');
        $('div#monthly_fee input').val('-');
        $('div#amount p').text('-');
        $('div#times p').text('-');
        $('div#start_month p').text('-');
        $('div#total_monthly_fee p').text('-');
        $('div#total_fee p').text('-');
        $('div#total_subscription_fee p').text('-');
        $('div#cancellation_penalty p').text('-');
        $('div#total_monthly_fee_with_tokutokuwari p').text('-');
      }
      if(data.entry_fee_flag == 0) {
        $('div#subscription_fee input').prop('disabled', true);
        $('#subscription_fee_flag').prop('disabled', false);
      }else{
        $('div#subscription_fee input').prop('disabled', false);
        $('#subscription_fee_flag').prop('disabled', true);
      }
      if(data.monthly_fee_flag == 0) {
        $('div#monthly_fee input').prop('disabled', true);
        $('#monthly_fee_flag').prop('disabled', false);
      }else{
        $('div#monthly_fee input').prop('disabled', false);
        $('#monthly_fee_flag').prop('disabled', true);
      }
   });
  };

  var getGoodsVariable = function() {
    var service_id = $('#service_id').val();
    var plan_id = $('#plan_id_name').val();
    getGoodsJson(service_id, plan_id).done(function (data) {
      var subscriptionFee = $('#subscription_fee input').val();
      var monthlyFee = $('#monthly_fee input').val();
      var quantity = $('div#quantity input').val() ? parseInt($('div#quantity input').val()) : 0;
      if ($('div#quantity input').prop('disabled')) {
        quantity = 1;
      }
      $('div#company p').text(data.company);
      $('div#fee p').text(data.fee);
      $('div#amount p').text(data.amount);
      $('div#times p').text(data.times);
      $('div#start_month p').text(data.start_month);
      $('div#total_monthly_fee p').text(parseInt(monthlyFee) * quantity);
      $('div#total_fee p').text(parseInt(data.fee) * quantity);
      $('div#total_subscription_fee p').text(parseInt(subscriptionFee) * quantity);
      $('div#cancellation_penalty p').text(data.cancellation_penalty);
      $('div#total_monthly_fee_with_tokutokuwari p').text(
        parseInt(monthlyFee) * quantity - parseInt(data.amount) * quantity
      );
      if (!data) {
        $('div#company p').text('-');
        $('div#fee p').text('-');
        $('div#subscription_fee input').val('-');
        $('div#monthly_fee input').val('-');
        $('div#amount p').text('-');
        $('div#times p').text('-');
        $('div#start_month p').text('-');
        $('div#total_monthly_fee p').text('-');
        $('div#total_fee p').text('-');
        $('div#total_subscription_fee p').text('-');
        $('div#cancellation_penalty p').text('-');
        $('div#total_monthly_fee_with_tokutokuwari p').text('-');
      }
   });
  };

  var getGoodsInstallmentSwitch = function(onload) {
    var onload_flag = onload || false;
    var service_id = $('#service_id').val();
    var plan_id = $('#plan_id_name').val();
    getGoodsJson(service_id, plan_id).done(function (data) {
      var quantity = $('div#quantity input').val() ? parseInt($('div#quantity input').val()) : 0;
      if ($('div#quantity input').prop('disabled')) {
        quantity = 1;
      }
      if(data.installment_flag == 0) {
        $('#service_content_installment').hide();
        $('#service_content_installment fieldset').prop('disabled', true);
        if (onload_flag) {
          bizCompassUnit();
          bizCompassFree();
          bizCompassPenalty();
        }
      } else if (!data) {
          $('div#goods_pass_date p').text("-");
          $('div#shipping_date p').text("-");
          $('div#goods_name p').text("-");
          $('div#model_number p').text("-");
          $('div#color p').text("-");
          $('div#manufacturer p').text("-");
          $('div#installment_quantity p').text("-");
          $('div#division_pay_money p').text("-");
          $('div#total_pay_money p').text("-");
          $('div#cash_sales_price p').text("-");
          $('div#pay_times p').text("-");
          $('div#pay_term p').text("-");
          $('div#division_pay_money_pay_start_date p').text("-");
          $('div#installment_contract_date p').text("-");
          $('div#deposit p').text("-");
          $('div#annual_percentage_rate p').text("-");
          $('div#payment_method p').text("-");
      } else {
        $('div#goods_pass_date p').text(data.goods_pass_date);
        $('div#shipping_date p').text(data.shipping_date);
        $('div#goods_name p').text(data.goods_name);
        $('div#model_number p').text(data.model_number);
        $('div#color p').text(data.color);
        $('div#manufacturer p').text(data.manufacturer);
        $('#installment_quantity p').text(quantity);
        $('div#division_pay_money p').text(data.division_pay_money * quantity);
        $('#total_pay_money p').text(quantity * data.division_pay_money * parseFloat(data.pay_times));
        $('div#cash_sales_price p').text(data.cash_sales_price);
        $('div#pay_times p').text(data.pay_times);
        $('div#pay_term p').text(data.pay_term);
        $('div#division_pay_money_pay_start_date p').text(data.division_pay_money_pay_start_date);
        $('div#installment_contract_date p').text(data.installment_contract_date);
        $('div#deposit p').text(data.deposit);
        $('div#annual_percentage_rate p').text(data.annual_percentage_rate);
        $('div#payment_method p').text(data.payment_method);
        $('#service_content_installment fieldset').prop('disabled', false);
        $('#service_content_installment').show();
      }
   });
  };

  var getGoodsQuantitySwitch = function() {
    var service_id = $('#service_id').val();
    var plan_id = $('#plan_id_name').val();
    getGoodsJson(service_id, plan_id).done(function (data) {
      if(data.quantity_flag == 0) {
        $('#selectQuantityBtn').hide();
        $('#quantityNumber, #quantityNumber_flag').val('1');
        $('#quantity input').prop('disabled', true);
        $('#quantityNumber_flag').prop('disabled', false);
      }else{
        $('#selectQuantityBtn').show();
        $('#quantity input').prop('disabled', false);
        $('#quantityNumber_flag').prop('disabled', true);
      }
   });
  };

  var exchangeContent = function() {
    var service_id = $('#service_id').val();
    $('#plan_id_name').children().remove();
    $('#plan_id_name').append('<option value="0">選択してください</option>');
    getPlanJson(service_id).done(function (data) {
      for (var i = 0; i < data.length; i++) {
        if ('0' === data[i].plan_id) {
          break;
        };
        $('#plan_id_name').append('<option value="' + data[i].plan_id + '">'+ data[i].plan_name + '</option>');
      }
      $('#plan_id_name').prop('disabled', false);
      $('#plan_id_name').next().remove();
      if (!data || '0' === data[0].plan_id) {
        $('#plan_id_name').prop('disabled', true);
        $('#plan_id_name').after('<input name="plan_id" value="0" hidden>');
      }
  });
  resetServiceSelect();//service選択リセット
  changeServiceSelect();//service選択分岐
  counter = 1;
}

  var makeAgreementField = function() {
    var service_num = $('#service_id').val();
    if (0 >= service_num) {
      $('#service_content_consent').hide();
      return ;
    }
    $('#service_content_consent').show();
    $('#agreement_pdf p').hide();
    $('#agreement_' + service_num).show();
  }

  getGoods(true);
  getGoodsQuantitySwitch();
  getGoodsInstallmentSwitch(true);
  makeAgreementField();

  //初期値からプラン名のdisabled処理
  if (1 >= $('select#plan_id_name option').length) {
    $('#plan_id_name').prop('disabled', true);
    $('#plan_id_name').after('<input name="plan_id" value="0" hidden>');
  };

  //サービス名切り替え時の処理
  var counter = 1;
  $('#service_id').on('change', function() {
    getGoods();
    getGoodsQuantitySwitch();//申込件数　入力可否スイッチ
    exchangeContent();
    makeAgreementField();
  });
  //プラン名切り替え時の処理
  $('#plan_id_name').on('change', function () {
    getGoods();
    getGoodsQuantitySwitch();//申込件数　入力可否スイッチ
    changePlanSelect();//plan選択分岐
    getGoodsQuantitySwitch();
    getGoodsInstallmentSwitch(true);//割賦　トグルスイッチ
  });
  //サービス、プランより固定値取得
//  $('#service_id, #plan_id_name').on('change', function () {
//    getGoods();
//    getGoodsQuantitySwitch();//申込件数　入力可否スイッチ
//  });
  //加入料金 月額利用料　可変
  $('div#subscription_fee input,div#monthly_fee input').on('change', function () {
    getGoodsVariable();
  });
  //申込件数　可変
  $('div#quantity input').on('change', function () {
    getGoodsVariable();
    changePlanSelect();
  });
  $('#selectQuantity li').on('click', function() {
    getGoodsVariable();
    changePlanSelect();
  });
  //申込件数
  $('#selectQuantity li a').on('click',function () {
      $('#quantity input').focus();
  });
  $('#quantity input').blur(function(){
    bizCompassUnit();
    bizCompassFree();
    bizCompassPenalty();
    installmentCalculation();
  });
  //ウェブフリコム書面確認
  $('#corporation_account_copy input, #corporation_document_copy input, #corporation_confirmation input').on('change', function () {
    if ($("#corporation_account_copy input").prop('checked')
        && ($("#corporation_document_copy input").prop('checked')
            || $("#corporation_confirmation input").prop('checked'))
    ) {
      $('#checked_attachment_corporation').prop('checked', true);
    } else {
      $('#checked_attachment_corporation').prop('checked', false);
    }
  });
  $('#trade_name_account_copy input, #trade_name_document_copy input, #trade_name_confirmation input').on('change', function () {
    if ($("#trade_name_account_copy input").prop('checked')
        && $("#trade_name_document_copy input").prop('checked')
        && $("#trade_name_confirmation input").prop('checked')
    ) {
      $('#checked_attachment_trade_name').prop('checked', true);
    } else {
      $('#checked_attachment_trade_name').prop('checked', false);
    }
  });

  //ダントツ
  $('#diversion_info, #switching_info, #petition_info, #plan_info, #cancellation_info').on('change', function () {
    if ($("#diversion_info").prop('checked')
        && $("#switching_info").prop('checked')
        && $("#petition_info").prop('checked')
        && $("#plan_info").prop('checked')
        && $("#cancellation_info").prop('checked')
    ) {
      $('#agreement_application').prop('checked', true);
    } else {
      $('#agreement_application').prop('checked', false);
    }
  })

  //クラウドカメラ　追加
  $('#addDestination').click(function(){
      var colNum = $('#camera').children().length / 2;
      if (colNum >= 5) {
        return false;
      }
      var newCol = ++colNum;
      var cameraBlock ='<table class="table camera_table"><thead><th>NO</th><th>納品先名称</th><th>受取担当者</th><th>郵便番号</th><th>住所</th><th>電話番号</th><th>台数</th></thead><tbody><tr><td rowspan="2">' + newCol + '</td><td class="camera_table_destination"><input class="form-control" id="careraDelivery' + newCol + '" name="cloud_anshin_camera[' + newCol + '][name]" placeholder="納品先名称" type="text" value=""></td><td class="camera_table_recipient"><input class="form-control" id="cameraAcceptance' + newCol + '" name="cloud_anshin_camera[' + newCol + '][person_in_charge_name]" placeholder="受取担当者" type="text" value=""></td><td class="camera_table_postal" rowspan="2"><input class="form-control" id="postcode' + newCol + '" name="cloud_anshin_camera[' + newCol + '][postal_code]" placeholder="郵便番号" type="text" value=""></td><td class="camera_table_address"> <input class="form-control camera_addres_input" id="prefectures' + newCol + '" name="cloud_anshin_camera[' + newCol + '][prefectures]" placeholder="都道府県" type="text" value=""> <input class="form-control camera_addres_input" id="city' + newCol + '" name="cloud_anshin_camera[' + newCol + '][city]" placeholder="市区町村" type="text" value=""> <input class="form-control camera_addres_input" id="town' + newCol + '" name="cloud_anshin_camera[' + newCol + '][neighbourhood]" placeholder="町域" type="text" value=""> <input class="form-control camera_addres_input" name="cloud_anshin_camera[' + newCol + '][block]" placeholder="番地" type="text" value=""> <input class="form-control camera_addres_input" name="cloud_anshin_camera[' + newCol + '][building]" placeholder="建物" type="text" value=""> </td><td class="camera_table_phoneNumber" rowspan="2"><input class="form-control" name="cloud_anshin_camera[' + newCol + '][tel]" placeholder="電話番号" type="text" value=""></td><td class="camera_table_someDelivery" rowspan="2"><input class="form-control" name="cloud_anshin_camera[' + newCol + '][unit_number]" placeholder="台数" type="text" value=""></td></tr><tr><td class="camera_table_destination"><input class="form-control" id="careraDelivery_kana' + newCol + '" name="cloud_anshin_camera[' + newCol + '][name_kana]" placeholder="納品先名称カナ" type="text" value=""></td><td class="camera_table_recipient"><input class="form-control" id="cameraAcceptance_kana' + newCol + '" name="cloud_anshin_camera[' + newCol + '][person_in_charge_name_kana]" placeholder="受取担当者カナ" type="text" value=""></td><td class="camera_table_address"> <input class="form-control camera_addres_input" id="prefectures_kana' + newCol + '" name="cloud_anshin_camera[' + newCol + '][prefectures_kana]" placeholder="都道府県カナ" type="text" value=""> <input class="form-control camera_addres_input" id="city_kana' + newCol + '" name="cloud_anshin_camera[' + newCol + '][city_kana]" placeholder="市区町村カナ" type="text" value=""> <input class="form-control camera_addres_input" id="town_kana' + newCol + '" name="cloud_anshin_camera[' + newCol + '][neighbourhood_kana]" placeholder="町域カナ" type="text" value=""> </td></tr></tbody></table><span class="alert_caution">※姓と名の間(法人/屋号の方は会社の種類と会社名の間)は、半角スペースを入れてください。</span>';
      $(cameraBlock).appendTo('#camera');
      $.fn.autoKana('#careraDelivery' + newCol + '', '#careraDelivery_kana' + newCol + '', {
        katakana : true
      });
      $.fn.autoKana('#cameraAcceptance' + newCol + '', '#cameraAcceptance_kana' + newCol + '', {
        katakana : true
      });

      // var postcode = '#postcode' + newCol + '';
      // var prefectures = '#prefectures' + newCol + '';
      // var city = '#city' + newCol + '';
      // var town = '#town' + newCol + '';
      // var postalkana = '#postalkana' + newCol + '';
      // var prefectures_kana = '#prefectures_kana' + newCol + '';
      // var city_kana = '#city_kana' + newCol + '';
      // var town_kana = '#town_kana' + newCol + '';

      $('#postcode').jpostal({
        postcode : [
          '#postcode'
        ],
        address : {
          '#prefectures'  : '%3',
          '#city'  : '%4',
          '#town'  : '%5',
          '#postalkana'  : '%8%9%10',
          '#prefectures_kana'  : '%8',
          '#city_kana'  : '%9',
          '#town_kana'  : '%10',
        }
      });
      $('#postcode2').jpostal({
        postcode : [
          '#postcode2'
        ],
        address : {
          '#prefectures2'  : '%3',
          '#city2'  : '%4',
          '#town2'  : '%5',
          '#postalkana2'  : '%8%9%10',
          '#prefectures_kana2'  : '%8',
          '#city_kana2'  : '%9',
          '#town_kana2'  : '%10',
        }
      });
      $('#postcode3').jpostal({
        postcode : [
          '#postcode3'
        ],
        address : {
          '#prefectures3'  : '%3',
          '#city3'  : '%4',
          '#town3'  : '%5',
          '#postalkana3'  : '%8%9%10',
          '#prefectures_kana3'  : '%8',
          '#city_kana3'  : '%9',
          '#town_kana3'  : '%10',
        }
      });
      $('#postcode4').jpostal({
        postcode : [
          '#postcode4'
        ],
        address : {
          '#prefectures4'  : '%3',
          '#city4'  : '%4',
          '#town4'  : '%5',
          '#postalkana4'  : '%8%9%10',
          '#prefectures_kana4'  : '%8',
          '#city_kana4'  : '%9',
          '#town_kana4'  : '%10',
        }
      });
      $('#postcode5').jpostal({
        postcode : [
          '#postcode5'
        ],
        address : {
          '#prefectures5'  : '%3',
          '#city5'  : '%4',
          '#town5'  : '%5',
          '#postalkana5'  : '%8%9%10',
          '#prefectures_kana5'  : '%8',
          '#city_kana5'  : '%9',
          '#town_kana5'  : '%10',
        }
      });
  });
});

//bizCompass同意事項自動入力
function bizCompassUnit() {
  var quantityNam = $('#quantityNumber').val(),
      unitNum = $('#unitNum');
  unitNum.empty();
  unitNum.append(quantityNam);
}
function bizCompassFree() {
  var planTxt = $('#plan_id_name option:selected').text(),
      freeNum = $('#freeNum');
  freeNum.empty();
  freeNum.append(planTxt);
}
function bizCompassPenalty() {
  var penaltyTxt = $('#cancellation_penalty p').text(),
      penaltyNum = $('#penaltyNum');
  penaltyNum.empty();
  penaltyNum.append(penaltyTxt);
}

//割賦自動入力
function installmentCalculation(){
  var quantityNam = $('#quantity input').val(),
      divisionPayMoney = $("#monthly_fee_flag").val(),
      payTimesTxt = $("#pay_times p").text(),
      payTimesNum = parseFloat(payTimesTxt);
  if (!quantityNam) {
    quantityNam = 1;
  }
  totalPayMoney = quantityNam * divisionPayMoney * payTimesNum;

  $('#installment_quantity p').text(quantityNam);
  $('#division_pay_money p').text(quantityNam * divisionPayMoney);
  $('#total_pay_money p').text(totalPayMoney);
}

//service選択リセット
function resetServiceSelect() {
  var allcontents =  $('#service_content_web_furikomu,#service_content_dantotsuhikari_pak,#service_content_installment,#service_content_bizcompass,#service_content_web_trasfer,#service_content_security_support,#service_content_camera,#service_content_marutoku_consent'); 　
  allcontents.hide();
  $('fieldset').prop('disabled', true);
  $('#commonFooter,#default_btn').show();
  $('#webFurikomu_hearing_btn,#dantotsu_hearing_btn').hide();
  $("#security_support_table #add").empty();
  //申込件数クリア
  $('#quantity input').val("");
  //BizCompass同意事項クリア
  $('#unitNum').text("");
  $('#freeNum').text("");
  $('#penaltyNum').text("");
  //割賦　数量、支払総額クリア
  $('#installment_quantity p').text("");
  $('#total_pay_money p').text("");
}
//service選択分岐
function changeServiceSelect() {
  if($('#service_id').val() == 10){
     $('#service_content_web_furikomu').show();
     $('#service_content_web_furikomu fieldset').prop('disabled', false);
  }else if($('#service_id').val() == 17
   || $('#service_id').val() == 18){
     $('#service_content_dantotsuhikari_pak').show();
     $('#service_content_dantotsuhikari_pak fieldset').prop('disabled', false);
  } else if($('#service_id').val() == 9){//クラウド安心カメラ
    // $('#creditLimit_Number').show();
    $('#service_content_camera fieldset').prop('disabled', false);
    $('#service_content_camera').show();
      var setArea = $('#addCameraArea');
      setArea.empty();
  }
}


//plan選択分岐
function changePlanSelect() {
  if($('#service_id').val() == 1){//bizcompass
    $('#service_content_bizcompass fieldset').prop('disabled', false);
    $('#service_content_bizcompass').show();
  }else if($('#service_id').val() == 2//おまかせ安心サポート各種　＆　まるトクセレクション
        || $('#service_id').val() == 3
        || $('#service_id').val() == 4
        || $('#service_id').val() == 5
        || $('#service_id').val() == 6
        || $('#service_id').val() == 7
        || $('#service_id').val() == 13
  ){
    if($('#service_id').val() == 4){
      $("#buyDateHead,#buyDateData").show();
      $("#buyDateData input").prop('disabled', false);
    }else{
      $("#buyDateHead,#buyDateData").hide();
      $("#buyDateData input").prop('disabled', true);
    }
    $('#service_content_security_support fieldset').prop('disabled', false);
    $('#service_content_security_support').show();
    $('#quantity input').blur(function(){
      var quantityNam = $('#quantity input').val(),
          colNum = $('#security_support_table tbody').children().length,
          maxNum = 100,
          setArea = $('#security_support_table tbody'),
          additionalNum = quantityNam - colNum;
      if (0 < additionalNum) {
        for (var i = 1; i <= additionalNum; i++){
          if(i== maxNum){
            break;
          }
          var elementNam = i + colNum;
          if($('#service_id').val() == 4){
            var securitySupportBlock ='<tr><td>'+elementNam+'</td><td><input class="form-control" name="omakase[' + elementNam + '][msn]" placeholder="MSN" type="text" value=""></td><td><input class="form-control" name="omakase[' + elementNam + '][imei]" placeholder="IMEI" type="text" value=""></td><td><input class="form-control" name="omakase[' + elementNam + '][model_name]" placeholder="機種名" type="text" value=""></td><td><input name="omakase[' + elementNam + '][mobile_purchase_date]" type="text" class="form-control datepicker datepicker_input" placeholder="書類開示日" value=""></td></tr>';
          }else{
            var securitySupportBlock ='<tr><td>'+elementNam+'</td><td><input class="form-control" name="omakase[' + elementNam + '][msn]" placeholder="MSN" type="text" value=""></td><td><input class="form-control" name="omakase[' + elementNam + '][imei]" placeholder="IMEI" type="text" value=""></td><td><input class="form-control" name="omakase[' + elementNam + '][model_name]" placeholder="機種名" type="text" value=""></td></tr>';
          }
          setArea.append(securitySupportBlock);
        }
      } else if (0 > additionalNum){
        for (var i = 1; i <= -additionalNum; i++) {
          $("#security_support_table tbody tr:last-child").remove();
        }
      }
      setDatepicker();
    });
  }else if($('#service_id').val() == 15
   || $('#service_id').val() == 16){//ダントツひかりパック
    $('#service_content_dantotsuhikari_pak').show();
    $('#service_content_dantotsuhikari_pak fieldset').prop('disabled', false);
  }
}
