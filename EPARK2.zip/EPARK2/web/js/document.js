//var update_block_no = 0;
//var append_block = 0;
//function addblock(){
//  default_block_no = $('#documentTable tbody tr').length;
//  append_no = default_block_no + update_block_no;
//  append_no++;
//  append_block++;
//  element = '<tr><td>No.'+ append_no +'</td><td>その他</td><td class="text-center"><input id="upl" class="uploadBtn" type="file" name="document_file[]" accept="image/*, application/pdf"></td></tr>';
//  if(append_block < 6){
//    $('#documentTable tbody').append(element);
//  }
//}
