function monthdisplay()
{
	var x = document.getElementById('month').value;
	console.log(x);
	document.getElementById('form_month').value=x;
	window.document.form.submit();
	document.getElementById('hidden_selected_month').value=x;
}


function HolidayCheck(aa) {

  var x = document.getElementById('holiday'+aa).value;

  if(x==1)
  {
   document.getElementById('Time'+aa).disabled= true;
   document.getElementById('Time'+aa).value= 0;

   document.getElementById('Holiday'+aa).value='休';
  }
  else if (x==0)
  {
    document.getElementById('Time'+aa).disabled= false;
    document.getElementById('Holiday1').value='';
  }


}

var st=0;

function add(aa) {

  var t = document.getElementById('Time'+aa).value;


  st = st+ parseInt(t);
  console.log(st);
  document.getElementById('SubTime').value=parseInt(st);
  document.getElementById('subtime').value=st;

}


function AddP(){
		// var nam= "AddUserProjectform"+aa;
		// console.log(nam);
    window.document.AddUserProjectform.submit();
  }


// function OnsubmitForm(url,aa) {
// 	    var d = "AddUserProjectform"+aa;
// 			console.log(d);
// 	    $('form[name=d]').attr("action", url).submit();
// 	};


function projectcord() {
  var x = document.getElementById('Pjtcrd').value;
  var str = x.split("/");
  var projectcord = str[str.length-2];
  var projectname = str[str.length-1];

  console.log(projectcord);
  console.log(projectname);

  document.getElementById('ProjectCord').value =projectcord;
  document.getElementById('ProjectName').value= projectname;

}


function process() {
  var x = document.getElementById('proc1').value;
  var str = x.split("/");
  var process1 = str[str.length-2];
  var process2 = str[str.length-1];

  console.log(process1);
  console.log(process2);

  document.getElementById('Process1').value = process1;
  document.getElementById('Process2').value = process2;

}


//function addrow()
//{
//
//	var table = document.getElementById('table');
//
//					var rowCount = table.rows.length;
//
//					var row = table.insertRow(rowCount);
//
//					var cell1 = row.insertCell(0);
//
//
//}

var index =0; 

$('#adduserproject').click(function(){
    index++;
    console.log(index);
    var $template  = $('#AddPorjecttemplate');
    
     
    var $clone = $template.clone().removeClass('hide').removeAttr('id').insertBefore($template);
    
    
    
});

