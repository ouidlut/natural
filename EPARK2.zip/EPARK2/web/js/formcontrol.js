$(function(){
  //郵便番号自動反映
  $('#postcode1').jpostal({
    postcode : [
      '#postcode'
    ],
    address : {
      '#prefectures'  : '%3',
      '#city'  : '%4',
      '#town'  : '%5',
      '#postalkana'  : '%8%9%10',
      '#prefectures_kana'  : '%8',
      '#city_kana'  : '%9',
      '#town_kana'  : '%10',
    }
  });
  $('#postcode2').jpostal({
    postcode : [
      '#postcode2'
    ],
    address : {
      '#prefectures2'  : '%3',
      '#city2'  : '%4',
      '#town2'  : '%5',
      '#postalkana2'  : '%8%9%10',
      '#prefectures_kana2'  : '%8',
      '#city_kana2'  : '%9',
      '#town_kana2'  : '%10',
    }
  });
  $('#postcode3').jpostal({
    postcode : [
      '#postcode3'
    ],
    address : {
      '#prefectures3'  : '%3',
      '#city3'  : '%4',
      '#town3'  : '%5',
      '#postalkana3'  : '%8%9%10',
      '#prefectures_kana3'  : '%8',
      '#city_kana3'  : '%9',
      '#town_kana3'  : '%10',
    }
  });
  //振り仮名自動反映
  //基本情報
  $.fn.autoKana('#basicInformation_contractorName', '#basicInformation_contractorName_kana', {
      katakana : true  //true：カタカナ、false：ひらがな（デフォルト）
  });
  $.fn.autoKana('#basicInformation_representativeName', '#basicInformation_representativeName_kana', {
      katakana : true
  });
  $.fn.autoKana('#basicInformation_contactPersonName', '#basicInformation_contactPersonName_kana', {
      katakana : true
  });
  $.fn.autoKana('#basicInformation_agree', '#basicInformation_agree_kana', {
      katakana : true
  });
  //請求書送付先
  $.fn.autoKana('#payment_destinationName', '#payment_destinationName_kana', {
      katakana : true
  });
  $.fn.autoKana('#payment_accountHolder_companyName', '#payment_accountHolder_companyName_kana', {
      katakana : true
  });
  $.fn.autoKana('#payment_accountHolder_degree', '#payment_accountHolder_degree_kana', {
      katakana : true
  });
  $.fn.autoKana('#payment_accountHolder_name', '#payment_accountHolder_name_kana', {
      katakana : true
  });
  //申込　クラウドカメラ
  $.fn.autoKana('#cameraAcceptance', '#cameraAcceptance_kana', {
      katakana : true
  });
  $.fn.autoKana('#careraDelivery', '#careraDelivery_kana', {
      katakana : true
  });
  //申込 ウェブフリコム
  $.fn.autoKana('#webFurikomu_accountName', '#webFurikomu_accountName_kana', {
      katakana : true
  });
  $.fn.autoKana('#webFurikomu_managerName', '#webFurikomu_managerName_kana', {
      katakana : true
  });
  $.fn.autoKana('#webFurikomu_emergencyName', '#webFurikomu_emergencyName_kana', {
      katakana : true
  });
  //申込　ダントツヒカリ
  $.fn.autoKana('#dantotsu_contractorName', '#dantotsu_contractorName_kana', {
      katakana : true
  });
  $.fn.autoKana('#dantotsu_applicantName', '#dantotsu_applicantName_kana', {
      katakana : true
  });

  //ラジオボタンチェンジイベント
  //ご契約者様 基本情報 & 基本情報 申込者区分による、必須表示
  $("#app_type").change(function() {
    app_typeDisable()
    contractorRequirede_appType()
  }).trigger('change');

  $("#app_class").change(function() {
    appClassDisable();
    paymentBankDisable();
  }).trigger('change');

  //請求書送付先
  $("#destination").change(function() {
    destinationDisable()
  }).trigger('change');

  // お支払方法 口座振替
  $("#paymentMethods").change(function() {
    paymentMethodsToggle();
  }).trigger('change');

  //お支払方法 金融機関情報
  $("#payment_bank").change(function() {
    paymentBankToggle();
  }).trigger('change');

  //お支払方法 ご契約住所以外の場合、必須表示
  $("#destination").change(function() {
    paymentRequirede();
  }).trigger('change');

  //基本情報 申込種別による、必須表示
  $("#applierType").change(function() {
    contractorRequirede();
  }).trigger('change');


});

function app_typeDisable(){
var app_typeVal = $("#app_type input:checked").val();
  if (app_typeVal == "0"){
    $("#customer_num input").prop("disabled", true);
  }else if (app_typeVal == "1") {
    $("#customer_num input").prop("disabled", false);
  }
}
function destinationDisable(){
var destinationVal = $("#destination input:checked").val();
  if (destinationVal == "1"){
    $("#contract_address_forms input").prop("disabled", true);
  }else if(destinationVal == "2"){
    $("#contract_address_forms input").prop("disabled", false);
  }
}
function paymentMethodsToggle(){
  var paymentMethodVal = $("#paymentMethods input:checked").val();
  if(paymentMethodVal == "2"){
    $('#creditCard').hide();
    $('#creditCard input').prop("disabled", true);
    $('#account_info').show();
    $('#account_info input, #account_info select').prop("disabled", false);
  } else if(paymentMethodVal == "1"){
    $('#account_info').hide();
    $('#account_info input, #account_info select').prop("disabled", true);
    $("#creditCard").show();
    $('#creditCard input').prop("disabled", false);
    $('#postoffice_bank input,#other_bank_form input, #account_info input').prop("disabled", true);
  } else{
    $('#account_info,#creditCard').hide();
    $('#account_info input,#creditCard input').prop("disabled", true);
  }
}
function paymentBankToggle(){
  var paymentBankVal = $("#payment_bank input:checked").val();
  if(paymentBankVal == "1"){
    $("#other_bank_form").hide();
    $("#postoffice_bank").show();
    $('#other_bank_form input, #other_bank_form select').prop("disabled", true);
    $('#postoffice_bank input').prop("disabled", false);
  } else if(paymentBankVal == "2"){
    $("#other_bank_form").show();
    $("#postoffice_bank").hide();
    $('#other_bank_form input, #other_bank_form select').prop("disabled", false);
    $('#postoffice_bank input').prop("disabled", true);

  }
}

function appClassDisable(){
  var appClassVal = $("#app_class input:checked").val();
  if (appClassVal == "0") {
    $("#customer_num input").prop("disabled", true);
  } else if(appClassVal == "1") {
    $("#customer_num input").prop("disabled", false);
  }
}

function paymentBankDisable(){
  var appClassVal = $("#payment_bank input:checked").val();
  if (appClassVal == "1") {
    $("#other_bank_form input").prop("disabled", true);
    $("#postoffice_bank input").prop("disabled", false);
  } else if(appClassVal == "2") {
    $("#postoffice_bank input").prop("disabled", true);
    $("#other_bank_form input").prop("disabled", false);
  }
}

function contractorRequirede_appType(){
  var contractorRequirede_appTypeVal = $("#app_type input:checked").val();
  if(contractorRequirede_appTypeVal == "0"){
    $("#appType_Required").hide();
  } else if(contractorRequirede_appTypeVal == "1"){
    $("#appType_Required").show();
  }
}

function contractorRequirede(){
  var contractorRequiredeVal = $("#applierType input:checked").val();
  if(contractorRequiredeVal == "0"){
    $("#contractorRequirede_1").show();
    $("#contractorRequirede_2").show();
    $("#contractorRequirede_3").show();
    $("#contractorRequirede_4").show();
    $("#contractorRandomly_1").hide();
    $("#contractorRandomly_2").hide();
    $("#contractorUnRequirede_1").hide();
    $("#contractorUnRequirede_2").hide();
    $("#contractorUnRequirede_3").hide();
    $("#contractorUnRequirede_4").hide();
  } else if(contractorRequiredeVal == "1"){
    $("#contractorRequirede_1").show();
    $("#contractorRequirede_2").show();
    $("#contractorRequirede_3").hide();
    $("#contractorRequirede_4").hide();
    $("#contractorRandomly_1").show();
    $("#contractorRandomly_2").show();
    $("#contractorUnRequirede_1").hide();
    $("#contractorUnRequirede_2").hide();
    $("#contractorUnRequirede_3").hide();
    $("#contractorUnRequirede_4").hide();
  } else if(contractorRequiredeVal == "2"){
    $("#contractorRequirede_1").hide();
    $("#contractorRequirede_2").hide();
    $("#contractorRequirede_3").hide();
    $("#contractorRequirede_4").hide();
    $("#contractorRandomly_1").hide();
    $("#contractorRandomly_2").hide();
    $("#contractorUnRequirede_1").show();
    $("#contractorUnRequirede_2").show();
    $("#contractorUnRequirede_3").show();
    $("#contractorUnRequirede_4").show();
  }
}

function paymentRequirede(){
  var paymentRequiredeVal = $("#destination input:checked").val();
  if(paymentRequiredeVal == "1"){
    $("#paymentRequired_1").hide();
    $("#paymentRequired_2").hide();
    $("#paymentRequired_3").hide();
    $("#paymentRequired_4").hide();
    $("#paymentRequired_5").hide();
    $("#paymentRequired_6").hide();
  } else if(paymentRequiredeVal == "2"){
    $("#paymentRequired_1").show();
    $("#paymentRequired_2").show();
    $("#paymentRequired_3").show();
    $("#paymentRequired_4").show();
    $("#paymentRequired_5").show();
    $("#paymentRequired_6").show();
  }
}
