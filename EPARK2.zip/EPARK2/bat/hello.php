<?php
$i = 31221;
if ($i !== 0) {
	exit(1);
} else {
	exit(0);
}
