<?php
try {

    mb_language("Japanese");
        mb_internal_encoding("UTF-8");

        //$to = 'epark_gyoumusystem@po.hikari.co.jp';
	$to = 'kento_karatsu@po.hikari.co.jp';
        $subject = '【日報管理システム】テスト送信_顧客情報取込実行結果【'.date("Ymd").'】';
        $message = '本文';
       // $headers = 'From: epark_gyoumusystem@po.hikari.co.jp' . "\r\n";
        $headers = 'From: kento_karatsu@po.hikari.co.jp' . "\r\n";
        //mb_send_mail($to, $subject, $message, $headers);
       //exit;

    $pdo = new PDO(
    'mysql:dbname=epark_report_manage_test;host=localhost;charset=utf8mb4',
    'root',
    'tAbI=6Vw43',
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]
    );

    if (!$pdo) {
        throw new Exception("Database connect error!");
    }

    $filepath = "csv/sozai.csv";
    if (!file_exists($filepath)) {
        //$filepathで指定したファイルが存在しない場合
        throw new Exception("file not exist!");
    }

    //文字コードを変換してファイルを置換
    $detect_oder = 'ASCII,JIS,UTF-8,CP51932,SJIS-win';
    setlocale(LC_ALL, 'ja_JP.UTF-8');
    $buffer = file_get_contents($filepath);
    if (!$encoding = mb_detect_encoding($buffer, $detect_oder, true)) {
        //文字コード自動判定失敗
        unset($buffer);
        throw new Exception("mb convert error!");
    }
    file_put_contents($filepath, mb_convert_encoding($buffer, 'UTF-8', $encoding));
    unset($buffer);

    $importCount = 0;
    $pdo->beginTransaction();
    try {
        $fp = fopen($filepath, "r");
        while ($row = fgetcsv($fp)) {
            if ($row === array(null)) {
                //空行はスキップ
                continue;
            }
        array_unshift ($row, date('YmdHis').rand(10000, 99999));

         $stmt = $pdo->prepare('INSERT INTO ProjectData (
			No, 
			OPNo, 
			ProjectY, 
			ProjectCord, 
			ArticleNo, 
			Project, 
			Status, 
			BusinessType, 
			Custodian, 
			CloseDate, 
			CancelDate,  
			AddDate, 
			AddTime, 
			AddName, 
			OP_ArticleNo 
		      )
                            	      VALUES (
			"'.$row[0].'",  
			"'.$row[1].'", 
			"'.$row[2].'", 
			"'.$row[3].'", 
			"'.$row[4].'", 
			"'.$row[5].'", 
			"'.$row[6].'", 
			"'.$row[7].'", 
			"'.$row[8].'", 
			"'.$row[9].'", 
			"'.$row[10].'", 
			"'.date('Y-m-d').'", 
			"'.date('H:i:s').'", 
			"バッチ処理", 
			"'.$row[1].$row[4].'" 
		      )
		     ON DUPLICATE KEY UPDATE
			No = "'.$row[0].'", 
			OPNo = "'.$row[1].'", 
			ProjectY = "'.$row[2].'", 
			ProjectCord = "'.$row[3].'", 
			Project = "'.$row[5].'", 
			Status = "'.$row[6].'", 
			BusinessType = "'.$row[7].'", 
			Custodian = "'.$row[8].'", 
			CloseDate = "'.$row[9].'", 
			CancelDate = "'.$row[10].'", 
			EditDate = "'.date('Y-m-d').'", 
			EditTime = "'.date('H:i:s').'", 
			EditName = "バッチ処理", 
			OP_ArticleNo = "'.$row[1].$row[4].'"'
		);
            foreach ($row as $value) {
                echo $value."\n";
            }
            echo count($row)."\n";

            $stmt->execute();
            $importCount++;
        }
        if(!feof($fp)) {
            throw new PDOException('csv read error!');
        }
        $pdo->commit();
    } catch (PDOException $e){
        $pdo->rollback();
        throw $e;
    }

} catch (Exception $e) {
     $message = "テスト送信です\nエラーが発生しましたので取込を行えませんでした\n▽エラー内容\n". $e;
     mb_send_mail($to, $subject, $message, $headers);
    exit(1);
}
$message = "テスト送信です\n取込実行成功\n取込件数: ".$importCount;
mb_send_mail($to, $subject, $message, $headers);
