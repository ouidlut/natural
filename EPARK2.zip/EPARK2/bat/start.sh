#!/bin/sh
cd //
cd var/www/html/DailyReport/EPARK_TEST/bat/
php upload.php
if [ $? != 0 ]; then
	echo "error!"
else
	echo "OK"
fi
