<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;

class NewUserEntity implements EntityInterface
{

    /**
     * user_name
     * @var string
     */
    protected $id;


    /**
     * user_passowrd
     * @var string
     */
    protected $name1;

    protected $name2;
    protected $class;
    protected $company;
    protected $email;
    protected $email2;




    public function getId()
    {
      return $this->id;
    }

    public function getName1()
    {
      return $this->name1;
    }

    public function getName2()
    {
      return $this->name2;
    }

    public function getClass()
    {
      return $this->class;
    }

    public function getCompany()
    {
      return $this->company;
    }

    public function getEmail()
    {
      return $this->email;
    }

    public function getEmail2()
    {
      return $this->email2;
    }



    public function setProperties(Array $paramaters = array())
    {
        foreach ($paramaters as $key => $value) {

            if (property_exists($this, $key)) {

                $this->$key = $value;
            }
        }
    }
}
