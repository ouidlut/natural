<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;


/**
 *
 */
class AddProjectEntity  implements EntityInterface
{

  protected $Name;
  protected $Accounting;
  protected $BusinessType;
  protected $Product;



  public function getbudget()
  {
      return $this->Accounting;
  }

  public function getbusinesstype()
  {
      return $this->BusinessType;
  }

  public function getnames()
  {
      return $this->Name;
  }

  public function getProduct()
  {
      return $this->Product;
  }


  public function setProperties(Array $paramaters = array())
  {
      foreach ($paramaters as $key => $value) {
          if (property_exists($this, $key)) {
              $this->$key = $value;
          }
      }
  }



}
