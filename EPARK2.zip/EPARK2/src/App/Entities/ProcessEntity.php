<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;

class ProcessEntity implements EntityInterface
{

    protected $Process1;
    protected $Process2;


    public function getProcess1()
    {
      return $this->Process1;
    }

    public function getProcess2()
    {
      return $this->Process2;
    }

	public function setProperties(Array $paramaters = array())
    {
        foreach ($paramaters as $key => $value) {
            if (property_exists($this, $key)) {
                $this->$key = $value;
            }
        }
    }
}