<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;


/**
 *
 */
class MemberAddEntity  implements EntityInterface
{

  protected $No;
  protected $AccountId;
  protected $Name;
  protected $MemberY;
  protected $YM1;
  protected $YM2;
  protected $YM3;
  protected $YM4;
  protected $YM5;
  protected $YM6;
  protected $YM7;
  protected $YM8;
  protected $YM9;
  protected $YM10;
  protected $YM11;
  protected $YM12;
  protected $ProjectCord;
  protected $ProjectNo;
  protected $Project;
  protected $ProcessF;

  protected $Time;
  protected $PTime;
  protected $Money;
  protected $PMoney;

  protected $Time1;
  protected $Time2;
  protected $Time3;
  protected $Time4;
  protected $Time5;
  protected $Time6;
  protected $Time7;
  protected $Time8;
  protected $Time9;
  protected $Time10;
  protected $Time11;
  protected $Time12;

  protected $PTime1;
  protected $PTime2;
  protected $PTime3;
  protected $PTime4;
  protected $PTime5;
  protected $PTime6;
  protected $PTime7;
  protected $PTime8;
  protected $PTime9;
  protected $PTime10;
  protected $PTime11;
  protected $PTime12;

  protected $Money1;
  protected $Money2;
  protected $Money3;
  protected $Money4;
  protected $Money5;
  protected $Money6;
  protected $Money7;
  protected $Money8;
  protected $Money9;
  protected $Money10;
  protected $Money11;
  protected $Money12;

  protected $PMoney1;
  protected $PMoney2;
  protected $PMoney3;
  protected $PMoney4;
  protected $PMoney5;
  protected $PMoney6;
  protected $PMoney7;
  protected $PMoney8;
  protected $PMoney9;
  protected $PMoney10;
  protected $PMoney11;
  protected $PMoney12;

  protected $UploadF;
  protected $PriceGroup;



  public function getNumber()
  {
      return $this->No;
  }

  public function setNumber($No)
  {
      $this->No = $No;
  }

  public function getMemberY()
  {
      return $this->MemberY;
  }


  public function getTime()
  {
      return $this->Time;
  }

  public function getPTime()
  {
      return $this->PTime;
  }

  public function getMoney()
  {
      return $this->Money;
  }

  public function getPMoney()
  {
      return $this->PMoney;
  }

    public function getAccountId()
  {
      return $this->AccountId;
  }
    public function getName()
  {
      return $this->Name;
  }

  public function getYM1()
  {
      return $this->YM1;
  }

    public function getYM2()
  {
      return $this->YM2;
  }

    public function getYM3()
  {
      return $this->YM3;
  }

    public function getYM4()
  {
      return $this->YM4;
  }

    public function getYM5()
  {
      return $this->YM5;
  }

    public function getYM6()
  {
      return $this->YM6;
  }

    public function getYM7()
  {
      return $this->YM7;
  }

    public function getYM8()
  {
      return $this->YM8;
  }

    public function getYM9()
  {
      return $this->YM9;
  }

    public function getYM10()
  {
      return $this->YM10;
  }

    public function getYM11()
  {
      return $this->YM11;
  }

    public function getYM12()
  {
      return $this->YM12;
  }
    public function getProjectCord()
  {
      return $this->ProjectCord;
  }

  public function getProjectNo()
  {
      return $this->ProjectNo;
  }
    public function getProject()
  {
      return $this->Project;
  }
    public function getProcessF()
  {
      return $this->ProcessF;
  }
  public function getPTime1()
  {
      return $this->PTime1;
  }

  public function getPTime2()
  {
      return $this->PTime2;
  }

  public function getPTime3()
  {
      return $this->PTime3;
  }

  public function getPTime4()
  {
      return $this->PTime4;
  }

  public function getPTime5()
  {
      return $this->PTime5;
  }

  public function getPTime6()
  {
      return $this->PTime6;
  }

  public function getPTime7()
  {
      return $this->PTime7;
  }

  public function getPTime8()
  {
      return $this->PTime8;
  }

  public function getPTime9()
  {
      return $this->PTime9;
  }

  public function getPTime10()
  {
      return $this->PTime10;
  }

  public function getPTime11()
  {
      return $this->PTime11;
  }

  public function getPTime12()
  {
      return $this->PTime12;
  }
  public function getTime1()
  {
      return $this->Time1;
  }

  public function getTime2()
  {
      return $this->Time2;
  }

  public function getTime3()
  {
      return $this->Time3;
  }

  public function getTime4()
  {
      return $this->Time4;
  }

  public function getTime5()
  {
      return $this->Time5;
  }

  public function getTime6()
  {
      return $this->Time6;
  }

  public function getTime7()
  {
      return $this->Time7;
  }

  public function getTime8()
  {
      return $this->Time8;
  }

  public function getTime9()
  {
      return $this->Time9;
  }

  public function getTime10()
  {
      return $this->Time10;
  }

  public function getTime11()
  {
      return $this->Time11;
  }

  public function getTime12()
  {
      return $this->Time12;
  }

  public function getMoney1()
  {
      return $this->Money1;
  }

  public function getMoney2()
  {
      return $this->Money2;
  }

  public function getMoney3()
  {
      return $this->Money3;
  }

  public function getMoney4()
  {
      return $this->Money4;
  }

  public function getMoney5()
  {
      return $this->Money5;
  }

  public function getMoney6()
  {
      return $this->Money6;
  }

  public function getMoney7()
  {
      return $this->Money7;
  }

  public function getMoney8()
  {
      return $this->Money8;
  }

  public function getMoney9()
  {
      return $this->Money9;
  }

  public function getMoney10()
  {
      return $this->Money10;
  }

  public function getMoney11()
  {
      return $this->Money11;
  }
  public function getMoney12()
  {
      return $this->Money12;
  }

  public function getPMoney1()
  {
      return $this->PMoney1;
  }

  public function getPMoney2()
  {
      return $this->PMoney2;
  }

  public function getPMoney3()
  {
      return $this->PMoney3;
  }

  public function getPMoney4()
  {
      return $this->PMoney4;
  }

  public function getPMoney5()
  {
      return $this->PMoney5;
  }

  public function getPMoney6()
  {
      return $this->PMoney6;
  }

  public function getPMoney7()
  {
      return $this->PMoney7;
  }

  public function getPMoney8()
  {
      return $this->PMoney8;
  }

  public function getPMoney9()
  {
      return $this->PMoney9;
  }

  public function getPMoney10()
  {
      return $this->PMoney10;
  }

  public function getPMoney11()
  {
      return $this->PMoney11;
  }
  public function getPMoney12()
  {
      return $this->PMoney12;
  }
    public function getUploadF()
  {
      return $this->UploadF;
  }
    public function getPriceGroup()
  {
      return $this->PriceGroup;
  }

  public function setPTime1($PTime1)
  {
      $this->PTime1 = $PTime1;
  }

  public function setPTime2($PTime2)
  {
      $this->PTime2 = $PTime2;
  }

  public function setPTime3($PTime3)
  {
      $this->PTime3 = $PTime3;
  }

  public function setPTime4($PTime4)
  {
      $this->PTime4 = $PTime4;
  }

  public function setPTime5($PTime5)
  {
      $this->PTime5 = $PTime5;
  }

  public function setPTime6($PTime6)
  {
      $this->PTime6 = $PTime6;
  }

  public function setPTime7($PTime7)
  {
      $this->PTime7 = $PTime7;
  }

  public function setPTime8($PTime8)
  {
      $this->PTime8 = $PTime8;
  }

  public function setPTime9($PTime9)
  {
      $this->PTime9 = $PTime9;
  }

  public function setPTime10($PTime10)
  {
      $this->PTime10 = $PTime10;
  }

  public function setPTime11($PTime11)
  {
      $this->PTime11 = $PTime11;
  }

  public function setPTime12($PTime12)
  {
      $this->PTime12 = $PTime12;
  }


  public function setProperties(Array $paramaters = array())
  {
      foreach ($paramaters as $key => $value) {
          if (property_exists($this, $key)) {
              $this->$key = $value;
          }
      }
  }



}
