<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;


class AllMembersEntity implements EntityInterface
{
    protected $No;
    protected $AccountId;
    protected $WinPass;
    protected $Pass;
    protected $Name;
    protected $Class;
    protected $Level;
    protected $Company;
    protected $PriceGroup;
    protected $Price1;
    protected $Price2;
    protected $Price3;
    protected $Price4;
    protected $Price5;
    protected $Price6;
    protected $Price7;
    protected $Price8;
    protected $Price9;
    protected $Price10;
    protected $Price11;
    protected $Price12;
    protected $ResetDate;
    protected $LoginDate;
    protected $LoginTime;
    protected $NGFlg;
    protected $CommonFlg;
    protected $Note;
    protected $EditDate;
    protected $EditTime;
    protected $EditName;
    protected $EditSort;
    protected $AddDate;
    protected $AddTime;
    protected $AddName;
    protected $Area;
    protected $MailingList;
    protected $EMail;
    protected $authority;
    protected $PMO;
    protected $search;

    protected $sort;





    public function setNo($No)
    {
        $this->No = $No;
    }
    public function getNumber()
    {
        $no = $this->No;
        return $this->No;
    }

    public function getMemberPriceGroup()
    {
        return $this->sort;
    }


    public function getPriceGroup()
    {
        return $this->PriceGroup;
    }

        public function getSearch()
    {
        return $this->search;
    }

    public function getMailingList()
    {
        return $this->MailingList;
    }

    public function getEMail()
    {
        return $this->EMail;
    }

    public function getCompany()
    {
        return $this->Company;
    }

    public function getAccountId()
    {
        return $this->AccountId;
    }

    public function getWinnPass()
    {
        return $this->WinPass;
    }

    public function getPass()
    {
        return $this->Pass;
    }

    public function getName()
    {
        return $this->Name;
    }

    public function getClass()
    {
        return $this->Class;
    }

    public function getLevel()
    {
        return $this->Level;
    }

    public function getPrice1()
    {
        return $this->Price1;
    }

    public function getPrice2()
    {
        return $this->Price2;
    }

    public function getPrice3()
    {
        return $this->Price3;
    }

    public function getPrice4()
    {
        return $this->Price4;
    }

    public function getPrice5()
    {
        return $this->Price5;
    }

    public function getPrice6()
    {
        return $this->Price6;
    }

    public function getPrice7()
    {
        return $this->Price7;
    }

    public function getPrice8()
    {
        return $this->Price8;
    }

    public function getPrice9()
    {
        return $this->Price9;
    }

    public function getPrice10()
    {
        return $this->Price10;
    }

    public function getPrice11()
    {
        return $this->Price11;
    }

    public function getPrice12()
    {
        return $this->Price12;
    }

    public function getArea()
    {
        return $this->Area;
    }

    public function getNote()
    {
        return $this->Note;
    }

    public function getPMO()
    {
        return $this->PMO;
    }

    public function getNGFlg()
    {
        return $this->NGFlg;
    }







  public function setProperties($paramaters = array())
  {
      foreach ($paramaters as $key => $value) {
          if (property_exists($this, $key)) {
              $this->$key = $value;
          }
      }
  }


}
