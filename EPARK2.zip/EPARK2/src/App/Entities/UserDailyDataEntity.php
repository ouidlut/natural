<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;


/**
 *
 */
class UserDailyDataEntity implements EntityInterface
{

    protected $No;
    protected $Name;
    protected $YM;
    protected $AccountId;
    protected $Price;
    protected $ProjectCord;
    protected $Project;
    protected $Process1;
    protected $Process2;
    protected $Status;
    protected $PriceGroup;
    protected $Company;
    protected $Time1;
    protected $HouseName;
    protected $Time2;
    protected $Time3;
    protected $Time4;
    protected $Time5;
    protected $Time6;
    protected $Time7;
    protected $Time8;
    protected $Time9;
    protected $Time10;
    protected $Time11;
    protected $Time12;
    protected $Time13;
    protected $Time14;
    protected $Time15;
    protected $Time16;
    protected $Time17;
    protected $Time18;
    protected $Time19;
    protected $Time20;
    protected $Time21;
    protected $Time22;
    protected $Time23;
    protected $Time24;
    protected $Time25;
    protected $Time26;
    protected $Time27;
    protected $Time28;
    protected $Time29;
    protected $Time30;
    protected $Time31;
    protected $TotalTime;
    protected $SubTime;
    protected $SubMoney;
    protected $lock_day;
    protected $authority;
    protected $ArticleNo;
    protected $StartDate;
    protected $CloseDate;
    protected $CancelDate;
    protected $OPNo;
    protected $Note;
    protected $OP_ArticleNo;

    public function getNo()
    {
      return $this->No;
    }
    public function getName()
    {
      return $this->Name;
    }

    public function getYM()
    {
      return $this->YM;
    }

    public function getAccountId()
    {
      return $this->AccountId;
    }

    public function getPrice()
    {
      return $this->Price;
    }

    public function getProjectcord()
    {
      return $this->ProjectCord;
    }

    public function getHouseName()
    {
      return $this->HouseName;
    }

    public function getProject()
    {
      return $this->Project;
    }

    public function getProcess1()
    {
      return $this->Process1;
    }

    public function getProcess2()
    {
      return $this->Process2;
    }

    public function getPriceGroup()
    {
      return $this->PriceGroup;
    }

    public function getCompany()
    {
      return $this->Company;
    }

    public function getStatus() {
      return $this->Status;
    }

    public function getNote() {
      return $this->Note;
    }

    public function getOP_ArticleNo() {
      return $this->OP_ArticleNo;
    }

    public function getTime1()
    {
      return $this->Time1;
    }

    public function getTime2()
    {
      return $this->Time2;
    }

    public function getTime3()
    {
      return $this->Time3;
    }

    public function getTime4()
    {
      return $this->Time4;
    }

    public function getTime5()
    {
      return $this->Time5;
    }

    public function getTime6()
    {
      return $this->Time6;
    }

    public function getTime7()
    {
      return $this->Time7;
    }

    public function getTime8()
    {
      return $this->Time8;
    }

    public function getTime9()
    {
      return $this->Time9;
    }

    public function getTime10()
    {
      return $this->Time10;
    }

    public function getTime11()
    {
      return $this->Time11;
    }

    public function getTime12()
    {
      return $this->Time12;
    }

    public function getTime13()
    {
      return $this->Time13;
    }

    public function getTime14()
    {
      return $this->Time14;
    }

    public function getTime15()
    {
      return $this->Time15;
    }

    public function getTime16()
    {
      return $this->Time16;
    }

    public function getTime17()
    {
      return $this->Time17;
    }

    public function getTime18()
    {
      return $this->Time18;
    }

    public function getTime19()
    {
      return $this->Time19;
    }

    public function getTime20()
    {
      return $this->Time20;
    }

    public function getTime21()
    {
      return $this->Time21;
    }

    public function getTime22()
    {
      return $this->Time22;
    }

    public function getTime23()
    {
      return $this->Time23;
    }

    public function getTime24()
    {
      return $this->Time24;
    }

    public function getTime25()
    {
      return $this->Time25;
    }

    public function getTime26()
    {
      return $this->Time26;
    }

    public function getTime27()
    {
      return $this->Time27;
    }

    public function getTime28()
    {
      return $this->Time28;
    }

    public function getTime29()
    {
      return $this->Time29;
    }

    public function getTime30()
    {
      return $this->Time30;
    }

    public function getTime31()
    {
      return $this->Time31;
    }

    public function getTotalTime()
    {
	return $this->TotalTime;
    }

    public function getSubTime()
    {
      return $this->SubTime;
    }

    public function getSubMoney()
    {
      return $this->SubMoney;
    }
    
    public function getlockDay()
    {
      return $this->lock_day;
    }

    public function getAuthority()
    {
      return $this->authority;
    }

    public function getArticleNo()
    {
	return $this->ArticleNo;
    }

    public function getStartDate()
    {
	return $this->StartDate;
    }

    public function getCloseDate()
    {
	return $this->CloseDate;
    }

    public function getCancelDate()
    {
	return $this->CancelDate;
    }

    public function getOPNo()
    {
	return $this->OPNo;
    }

    public function setProperties(Array $paramaters = array())
    {
        foreach ($paramaters as $key => $value) {

            if (property_exists($this, $key)) {

                $this->$key = $value;
            }
        }
    }

}
