<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;

class UserEntity implements EntityInterface
{

    /**
     * user_id
     * @var string
     */
    protected $user_id;

        /**
     * user_id
     * @var string
     */
    protected $user_name;

    /**
     * user_passowrd
     * @var string
     */
    protected $password;
    protected $EMail;
    protected $Level;
    protected $authority;
    protected $opno;

    public function setUserName($user_id)
    {
        $this->user_name = $user_id;
    }

    public function setUserPassword($password)
    {
        $this->password = $password;
    }

    public function setEMail($EMail)
    {
        $this->EMail = $EMail;
    }

    public function setLevel($Level)
    {
        $this->Level = $Level;
    }

    public function setAuthority($authority)
    {
        $this->authority = $authority;
    }

    public function setOpno($opno)
    {
	$this->opno = $opno;
    }

    public function getLoginId()
    {
      return $this->user_id;
    }

    public function getUserName()
    {
      return $this->user_name;
    }

    public function getPassword()
    {
      return $this->password;
    }

     public function getEMail()
    {
      return $this->EMail;
    }

    public function getLevel()
    {
      return $this->Level;
    }

    public function getAuthority()
    {
      return $this->authority;
    }

    public function getOpno()
    {
      return $this->opno;
    }

    public function setProperties(Array $paramaters = array())
    {
        foreach ($paramaters as $key => $value) {

            if (property_exists($this, $key)) {

                $this->$key = $value;
            }
        }
    }
}
