<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;

class LockEntity implements EntityInterface
{

    protected $lock_day;
    protected $lock_flag;

    public function getLockDay()
    {
      return $this->lock_day;
    }

    public function getLockFlag()
    {
      return $this->lock_flag;
    }

    
	public function setProperties(Array $paramaters = array())
    {
        foreach ($paramaters as $key => $value) {
            if (property_exists($this, $key)) {
                $this->$key = $value;
            }
        }
    }
}