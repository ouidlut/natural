<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;

class LoginInfoEntity implements EntityInterface
{
  

     /**
     * login_id
     * @var string
     */
    protected $login_id = null;

     /**
     * password
     * @var string
     */
    protected $password = null;

    protected $user_name = null;
   
    public function getLoginId()
    {
        return $this->login_id;
    }
    
    public function getPassword()
    {
        return $this->password;
    }

    public function getUserName()
    {
	return $this->user_name;    
    }

    public function setLoginId($login_id)
    {
        $this->login_id = $login_id;
    }
    
    public function setPassword($user_password)
    {
        $this->password = $password;
    }

    public function setUserName($user_name)
    {
	$this->user_name = $user_name;
    }

   /* public function isSwiftmailerSending()
    {
        return \Swift_Validate::email($this->getContractorEmail());
    }
    */
    public function setProperties(Array $paramaters = array())
    {
        foreach ($paramaters as $key => $value) {
            if (property_exists($this, $key)) {
                $this->$key = $value;
            }
        }
    }
}
