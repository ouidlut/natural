<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;

class PmoEntity implements EntityInterface
{

    protected $No;
    protected $PMO;
    protected $Accounting;
    protected $BusinessType;


    public function getNo()
    {
      return $this->No;
    }

    public function getPMO()
    {
      return $this->PMO;
    }

    public function getAccounting()
    {
      return $this->Accounting;
    }

    public function getBusinessType()
    {
      return $this->BusinessType;
    }
	public function setProperties(Array $paramaters = array())
    {
        foreach ($paramaters as $key => $value) {
            if (property_exists($this, $key)) {
                $this->$key = $value;
            }
        }
    }
}