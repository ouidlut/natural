<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;

class UserProjectsEntity implements EntityInterface
{

    /**
     * user_name
     * @var string
     */
    protected $YM;
    protected $Name;
    protected $ProjectCord;
    protected $Project;
    protected $Month;



    public function getselectedmonth()
    {
      return $this->Month;
    }

    public function setselectedmonth($Month)
    {
      return $this->Month=$Month;
    }

    public function getYm()
    {
      return $this->YM;
    }

    public function getName()
    {
      return $this->Name;
    }

    public function getProjectcord()
    {
      return $this->ProjectCord;
    }

    public function getProject()
    {
      return $this->Project;
    }


    public function setProperties(Array $paramaters = array())
    {
        foreach ($paramaters as $key => $value) {

            if (property_exists($this, $key)) {

                $this->$key = $value;
            }
        }
    }
}
