<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;


/**
 *
 */
class MonthDataEntity  implements EntityInterface
{

  protected $No;
  protected $AccountId;
  protected $Name;
  protected $YM;
  protected $ProjectCord;
  protected $Project;
  protected $ArticleNo;
  protected $ProcessF;
  protected $PTime;
  protected $PMoney;
  protected $Time;
  protected $Money;
  protected $UploadF;
  protected $PriceGroup;
  protected $OPNo;

  public function getOPNo()
  {
	return $this->OPNo;
  }

  public function getbudget()
  {
      return $this->No;
  }

    public function getAccountId()
  {
      return $this->AccountId;
  }
    public function getName()
  {
      return $this->Name;
  }

    public function getYM()
  {
      return $this->YM;
  }
    public function getProjectCord()
  {
      return $this->ProjectCord;
  }
    public function getProject()
  {
      return $this->Project;
  }

  public function getArticleNo()
  {
	return $this->ArticleNo;
  }

    public function getProcessF()
  {
      return $this->ProcessF;
  }
    public function getPTime()
  {
      return $this->PTime;
  }
    public function getPMoney()
  {
      return $this->PMoney;
  }
    public function getTime()
  {
      return $this->Time;
  }
    public function getMoney()
  {
      return $this->Money;
  }
    public function getUploadF()
  {
      return $this->UploadF;
  }
    public function getPriceGroup()
  {
      return $this->PriceGroup;
  }

  public function setProperties(Array $paramaters = array())
  {
      foreach ($paramaters as $key => $value) {
          if (property_exists($this, $key)) {
              $this->$key = $value;
          }
      }
  }



}
