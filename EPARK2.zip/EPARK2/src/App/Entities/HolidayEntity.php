<?php

namespace App\Entities;

use PHPMentors\DomainKata\Entity\EntityInterface;

class HolidayEntity implements EntityInterface
{

  protected $AccountId;
  protected $No;
  protected $HolidayYM;
  protected $Holiday1;
  protected $Holiday2;
  protected $Holiday3;
  protected $Holiday4;
  protected $Holiday5;
  protected $Holiday6;
  protected $Holiday7;
  protected $Holiday8;
  protected $Holiday9;
  protected $Holiday10;
  protected $Holiday11;
  protected $Holiday12;
  protected $Holiday13;
  protected $Holiday14;
  protected $Holiday15;
  protected $Holiday16;
  protected $Holiday17;
  protected $Holiday18;
  protected $Holiday19;
  protected $Holiday20;
  protected $Holiday21;
  protected $Holiday22;
  protected $Holiday23;
  protected $Holiday24;
  protected $Holiday25;
  protected $Holiday26;
  protected $Holiday27;
  protected $Holiday28;
  protected $Holiday29;
  protected $Holiday30;
  protected $Holiday31;


    public function getAccountId()
    {
      return $this->AccountId;
    }

    public function getNo()
    {
      return $this->No;
    }

    public function getHolidayYM()
    {
      return $this->HolidayYM;
    }

    public function getHoliday1()
    {
      return $this->Holiday1;
    }

    public function getHoliday2()
    {
      return $this->Holiday2;
    }

    public function getHoliday3()
    {
      return $this->Holiday3;
    }

    public function getHoliday4()
    {
      return $this->Holiday4;
    }

    public function getHoliday5()
    {
      return $this->Holiday5;
    }

    public function getHoliday6()
    {
      return $this->Holiday6;
    }

    public function getHoliday7()
    {
      return $this->Holiday7;
    }


    public function getHoliday8()
    {
      return $this->Holiday8;
    }

    public function getHoliday9()
    {
      return $this->Holiday9;
    }

    public function getHoliday10()
    {
      return $this->Holiday10;
    }

    public function getHoliday11()
    {
      return $this->Holiday11;
    }

    public function getHoliday12()
    {
      return $this->Holiday12;
    }

    public function getHoliday13()
    {
      return $this->Holiday13;
    }

    public function getHoliday14()
    {
      return $this->Holiday14;
    }

    public function getHoliday15()
    {
      return $this->Holiday15;
    }

    public function getHoliday16()
    {
      return $this->Holiday16;
    }

    public function getHoliday17()
    {
      return $this->Holiday17;
    }

    public function getHoliday18()
    {
      return $this->Holiday18;
    }

    public function getHoliday19()
    {
      return $this->Holiday19;
    }

    public function getHoliday20()
    {
      return $this->Holiday20;
    }

    public function getHoliday21()
    {
      return $this->Holiday21;
    }

    public function getHoliday22()
    {
      return $this->Holiday22;
    }

    public function getHoliday23()
    {
      return $this->Holiday23;
    }

    public function getHoliday24()
    {
      return $this->Holiday24;
    }

    public function getHoliday25()
    {
      return $this->Holiday25;
    }

    public function getHoliday26()
    {
      return $this->Holiday26;
    }

    public function getHoliday27()
    {
      return $this->Holiday27;
    }

    public function getHoliday28()
    {
      return $this->Holiday28;
    }

    public function getHoliday29()
    {
      return $this->Holiday29;
    }

    public function getHoliday30()
    {
      return $this->Holiday30;
    }

    public function getHoliday31()
    {
      return $this->Holiday31;
    }



    public function setProperties(Array $paramaters = array())
    {
        foreach ($paramaters as $key => $value) {

            if (property_exists($this, $key)) {

                $this->$key = $value;
            }
        }
    }
}
