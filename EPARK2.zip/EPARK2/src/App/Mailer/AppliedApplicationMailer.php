<?php
namespace App\Mailer;

use \Swift_Mailer;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use PHPMentors\DomainKata\Entity\EntityInterface;
use Symfony\Bridge\Twig\TwigEngine;

//Request

class AppliedApplicationMailer
{
    protected $mailer;
    protected $twig;

    public function __construct(Swift_Mailer $mailer,\Twig_Environment $twig)
    {
      $this->mailer = $mailer;
      $this->twig = $twig;
    }

    public function sendMailToPMO($result, $pmo_mail)
    {
      $No = number_format($result->getNo(),0,'.','');
    $subject = "プロジェクト承認依頼";
    $message = \Swift_Message::newInstance()
    ->setSubject($subject)
    ->setFrom( array("eparkkaihatsunippou@po.hikari.co.jp" => "EPARK開発日報")) // your own
    ->setTo( array($pmo_mail->getEMail()))  // email recipient
    ->setBody($this->twig->render('email/project_pmo_confirm_mail.html.twig',   // email template
          array('No' => $No,          ),
           'text/html'));
    $this->mailer->send($message);
    }

    public function sendMailToApplicant(EntityInterface $user_info, EntityInterface $result)
    {
    $No = (int)$result->getNo();
    $subject = "件名: "."add entity reference here"."【保存完了】";
    $message = \Swift_Message::newInstance()
    ->setSubject($subject)
    ->setFrom( array("NIKHIL_NAGPAL@po.hikari.co.jp")) // your own
    ->setTo( array("NIKHIL_NAGPAL@po.hikari.co.jp"))  // email recipient
    // ->setTo( array($user_info->getEMail()))  // email recipient
    ->setBody($this->twig->render('email/project_applicant_mail.html.twig',   // email template
          array(
            'user_info' => $user_info,
            'No' => $No,
                    ),
           'text/html'));
    $this->mailer->send($message);
    }

        public function sendMailToApplicantAfterConfirmOrDeny()
    {
    $subject = "件名: "."add entity reference here"."【保存完了】";
    $message = \Swift_Message::newInstance()
    ->setSubject($subject)
    ->setFrom( array("NIKHIL_NAGPAL@po.hikari.co.jp")) // your own
    ->setTo( array("NIKHIL_NAGPAL@po.hikari.co.jp"))  // email recipient
    ->setBody($this->twig->render('email/project_confirm_deny_mail_applicant.html.twig',   // email template
          array(
                    ),
           'text/html'));
    $this->mailer->send($message);
    }

    public function sendDraftMail($val, $user, $planner)
    {
      $subject = "件名: ".$val->getApplicationId()."【保存完了】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      // ->setContentType("text/html")
      ->setFrom( array($user->getEmail()) ) // your own
      ->setTo( array($user->getEmail()) )   // email recipient

      ->setBody($this->twig->render('email/project_confirm.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
          ), 'text/html'));

      $this->mailer->send($message);
    }

    public function sendAppliedMail($val, $user, $planner)
    {
      $subject = "件名: ".$val->getApplicationId()."【申請完了】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      ->setFrom( array($user->getEmail()) ) // your own
      ->setTo(array('P2eva_sys@hikari.local'))   // email recipient
      ->setBody($this->twig->render('email/applied_application.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
          )));

      $this->mailer->send($message);
    }

    public function sendDenialMail($val, $applicant, $planner, $denial_reason)
    {
      $subject = "件名: ".$val->getApplicationId()."【受付NG】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      ->setFrom( array('P2eva_sys@hikari.local') ) // your own
      ->setTo(array($applicant->getEmail(), 'P2eva_sys@hikari.local'))   // email recipient
      ->setBody($this->twig->render('email/denial_application.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
                'reason' => $denial_reason
          )));

      $this->mailer->send($message);
    }

    public function sendApprovalMail($val, $applicant, $planner)
    {
      $subject = "件名: ".$val->getApplicationId()."【審査依頼】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      ->setFrom( array('P2eva_sys@hikari.local') ) // your own
      ->setTo(array($applicant->getEmail(), 'P2eva_sys@hikari.local'))   // email recipient
      ->setBody($this->twig->render('email/approval_application.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
          )));

      $this->mailer->send($message);
    }

    public function sendKickOffMail($val, $applicant, $planner)
    {
      $subject = "件名: ".$val->getApplicationId()."【案件承認】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      ->setFrom( array('P2eva_sys@hikari.local') ) // your own
      ->setTo(array($applicant->getEmail(), 'P2eva_sys@hikari.local'))   // email recipient
      ->setBody($this->twig->render('email/kickOff_application.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
          )));

      $this->mailer->send($message);
    }

    public function sendReleaseMail($val, $applicant, $planner)
    {
      $subject = "件名: ".$val->getApplicationId()."【リリースOK】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      ->setFrom( array('P2eva_sys@hikari.local') ) // your own
      ->setTo(array($applicant->getEmail(), 'P2eva_sys@hikari.local'))   // email recipient
      ->setBody($this->twig->render('email/release_application.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
          )));

      $this->mailer->send($message);
    }

    //Mail to selected Judge before kickOff
    public function mailToSelectedJudgebeforeKickoff($val, $judge, $planner)
    {
        if($judge !== false) {

          $subject = "件名: ".$val->getApplicationId()."【審査依頼】".$val->getCaseName();
          $message = \Swift_Message::newInstance()
          ->setSubject($subject)
          ->setFrom( array('P2eva_sys@hikari.local')) // Mail Being Sent From Judge's Own Email ID
          ->setTo(array($judge->getEmail(), 'P2eva_sys@hikari.local'))   // email recipient
          ->setBody($this->twig->render('email/judge_select_before_kickoff.html.twig',   // email template
              array('data' => $val,
                    'planner' => $planner,
              )));

          $this->mailer->send($message);

        }

    }

    //Mail to selected Judge after kickOff
    public function mailToSelectedJudgeafterKickoff($val, $judge, $planner)
    {
        if($judge !== false) {

          $subject = "件名: ".$val->getApplicationId()."【案件承認】".$val->getCaseName();
          $message = \Swift_Message::newInstance()
          ->setSubject($subject)
          ->setFrom( array('P2eva_sys@hikari.local')) // Mail Being Sent From Judge's Own Email ID
          ->setTo(array($judge->getEmail(), 'P2eva_sys@hikari.local'))   // email recipient
          ->setBody($this->twig->render('email/judge_select_after_kickoff.html.twig',   // email template
              array('data' => $val,
                    'planner' => $planner,
              )));

          $this->mailer->send($message);

        }

    }

    //Judge Mail Functions
    public function sendJudgeOkAfterKickoff($val, $applicant, $planner,$user)
    {
      $subject = "件名: ".$val->getApplicationId()."【建付け審査完了】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      ->setFrom(array('P2eva_sys@hikari.local'))
    // ->setFrom( array($user->getEmail()) )// Mail Being Sent From Judge's Own Email ID
      ->setTo(array('P2eva_sys@hikari.local'))   // email recipient
      ->setBody($this->twig->render('email/judge_OK_afterKickOff.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
          )));

      $this->mailer->send($message);
    }

    public function sendJudgeNGAfterKickoff($val, $applicant, $planner, $user, $reason)
    {
      $subject = "件名: ".$val->getApplicationId()."【審査NG】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      ->setFrom( array($user->getEmail() )) // your own
      ->setTo(array($applicant->getEmail(), 'P2eva_sys@hikari.local'))   // email recipient
      ->setBody($this->twig->render('email/judge_NG_afterKickOff.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
                'reason' => $reason
          )));

      $this->mailer->send($message);
    }

    public function sendJudgeOkBeforeKickoff($val, $applicant, $planner,$user)
    {
      $subject = "件名: ".$val->getApplicationId()."【建付け審査完了】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      ->setFrom( array($user->getEmail() )) // your own
      ->setTo(array('P2eva_sys@hikari.local'))   // email recipient
      ->setBody($this->twig->render('email/judge_OK_beforeKickOff.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
          )));

      $this->mailer->send($message);
    }

    public function sendJudgeNGBeforeKickoff($val, $applicant, $planner, $user, $reason)
    {
      $subject = "件名: ".$val->getApplicationId()."【審査NG】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      ->setFrom( array($user->getEmail() )) // your own
      ->setTo(array($applicant->getEmail(), 'P2eva_sys@hikari.local'))   // email recipient
      ->setBody($this->twig->render('email/judge_NG_beforeKickOff.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
                'reason' => $reason
          )));

      $this->mailer->send($message);
    }

    /*-- emailToSelectedDecider --*/
    public function mailToSelectedDecider($val, $planner, $decider)
    {
      $subject ="件名: ".$val->getApplicationId()."【決裁者審査依頼】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      ->setFrom( array('P2eva_sys@hikari.local'))
      ->setTo(array($decider->getEmail(), 'P2eva_sys@hikari.local')) // Email Recipient
      ->setBody($this->twig->render('email/decider_select.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
          )));
      $this->mailer->send($message);
    }

    // Decider OK
    public function sendDeciderOk($val, $applicant, $planner, $user)
    {
      $subject ="件名: ".$val->getApplicationId()."【決済完了】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      ->setFrom( array($user->getEmail()))
      ->setTo(array($applicant->getEmail(), 'P2eva_sys@hikari.local')) // Email Recipient
      ->setBody($this->twig->render('email/decider_OK.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
          )));
      $this->mailer->send($message);
    }
    // End Decider OK

    // Decider NG
    public function sendDeciderNG($val, $applicant, $planner, $user, $reason)
    {
      $subject ="件名: ".$val->getApplicationId()."【審査NG】".$val->getCaseName();
      $message = \Swift_Message::newInstance()
      ->setSubject($subject)
      ->setFrom( array($user->getEmail()))
      ->setTo(array($applicant->getEmail(), 'P2eva_sys@hikari.local')) // Email Recipient
      ->setBody($this->twig->render('email/decider_NG.html.twig',   // email template
          array('data' => $val,
                'planner' => $planner,
                'reason' => $reason,
                'name' => $user->getName()
          )));
      $this->mailer->send($message);
    }
    

}
