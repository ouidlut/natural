<?php

namespace App\Providers;

use Silex\Application;
use Silex\ServiceProviderInterface;
use App\Usecases;
use App\Repositories;
use App\Validators;
use Hikaritsushin\Service\Password;

class HomeServiceProvider implements ServiceProviderInterface
{
    public function register(Application $app)
    {
        $app['monthly_data.usecase'] = $app->share(function () use ($app) {
            $home_repository = new Repositories\HomeRepository($app['db']);

            return new Usecases\MonthlyDataUsecase($home_repository);
        });
    }
    public function boot(Application $app)
    {
    }
}
