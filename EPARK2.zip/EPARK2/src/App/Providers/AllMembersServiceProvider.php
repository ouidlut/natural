<?php

namespace App\Providers;

use Silex\Application;
use Silex\ServiceProviderInterface;
use App\Usecases;
use App\Repositories;
use App\Validators;
use Hikaritsushin\Service\Password;

class AllMembersServiceProvider implements ServiceProviderInterface
{
    public function register(Application $app)
    {
        $app['all_members.usecase'] = $app->share(function () use ($app) {
            $allmembers = new Repositories\AllMembersRepository($app['db']);

            return new Usecases\AllMembersUsecase($allmembers);
        });
    }
    public function boot(Application $app)
    {


    }
}
