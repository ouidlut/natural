<?php
namespace App\Providers;

use Silex\Application;
use App\Validators;
use Silex\ServiceProviderInterface;

class AgreementServiceProvider implements ServiceProviderInterface
{
    public function register(Application $app)
    {
        $app['agreement.validator'] = $app->share(function () use ($app) {
            $metadata = new Validators\Agreement\Metadata(
                $app['validator'],
                $app['validator.mapping.class_metadata_factory']
            );
            return new Validators\AgreementValidator($metadata);
        });
    }

    public function boot(Application $app)
    {
    }
}
