<?php
namespace App\Providers;

use Silex\Application;
use App\Validators;
use App\Repositories\UserRepository;
use App\Usecases\SendLoginInfoUsecase;
use Silex\ServiceProviderInterface;
use App\Transfers\SendLoginInfoMail;

class LoginInfoServiceProvider implements ServiceProviderInterface
{
    public function register(Application $app)
    {
       
        $app['login_info.usecase'] = $app->share(function () use ($app) {
            $user_registration_repository= new UserRepository($app['db'] );
            
            return new SendLoginInfoUsecase($user_registration_repository);
        });
       
        
        $app['send_login_info_mail.usecase'] = $app->share(function () use ($app) {
            return new SendLoginInfoMail(
                $app['mailer'],
                $app['twig']
                
            );
        });
        
    }

    public function boot(Application $app)
    {
    }
}
