<?php
namespace App\Providers;

use Silex\Application;
use Silex\ServiceProviderInterface;
use App\Usecases;
use App\Repositories;
use App\Validators;

class UserAdditionServiceProvider implements ServiceProviderInterface
{
    public function register(Application $app)
    {
        $app['user_addition.usecase'] = $app->share(function () use ($app) {
            $repository = new Repositories\UserRepository($app['db']);
            $metadata = new Validators\UserAddition\Metadata(
                $app['validator'],
                $app['validator.mapping.class_metadata_factory']
            );
            $validator = new Validators\UserAdditionValidator($metadata);

            return new Usecases\UserAdditionUsecase($repository, $validator);
        });
    }
    public function boot(Application $app)
    {
    }
}
