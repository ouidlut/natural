<?php

namespace App\Providers;

use Silex\Application;
use Silex\ServiceProviderInterface;
use App\Usecases;
use App\Repositories;
use App\Validators;
use Hikaritsushin\Service\Password;

class AllProjectServiceProvider implements ServiceProviderInterface
{
    public function register(Application $app)
    {
        $app['all_projects.usecase'] = $app->share(function () use ($app) {
            $allprojects_repository = new Repositories\AllProjectsRepository($app['db']);

            return new Usecases\AllProjectsUsecase($allprojects_repository);
        });
    }
    public function boot(Application $app)
    {
    }
}
