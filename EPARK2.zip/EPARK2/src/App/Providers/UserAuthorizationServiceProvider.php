<?php

namespace App\Providers;

use Silex\Application;
use Silex\ServiceProviderInterface;
use App\Usecases;
use App\Repositories;
use App\Validators;
use Hikaritsushin\Service\Password;

class UserAuthorizationServiceProvider implements ServiceProviderInterface
{
    public function register(Application $app)
    {
        $app['user_authorization.usecase'] = $app->share(function () use ($app) {
            $repository = new Repositories\UserRepository($app['db']);
            $metadata = new Validators\UserAuthorization\Metadata(
                $app['validator'],
                $app['validator.mapping.class_metadata_factory']
            );
            $validator = new Validators\UserAuthorizationValidator($metadata);
            $password  = new Password();

            return new Usecases\UserAuthorizationUsecase($repository, $validator, $password);
        });
    }
    public function boot(Application $app)
    {
    }
}
