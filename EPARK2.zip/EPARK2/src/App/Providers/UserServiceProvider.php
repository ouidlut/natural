<?php
namespace App\Providers;

use Silex\Application;
use App\Validators;
use App\Repositories\UserRepository;
use Silex\ServiceProviderInterface;
use App\Transfers\SendURLMail;

class UserServiceProvider implements ServiceProviderInterface
{
    public function register(Application $app)
    {
        $app['user.validator'] = $app->share(function () use ($app) {
            $metadata = new Validators\User\Metadata(
                $app['validator'],
                $app['validator.mapping.class_metadata_factory']
            );
            return new Validators\UserValidator($metadata);
        });


        $app['user_registration.usecase'] = $app->share(function () use ($app) {
            return new UserRepository(
                $app['db']
            );
        });

        

        $app['send_url_mail.usecase'] = $app->share(function () use ($app) {
            return new SendURLMail(
                $app['mailer'],
                $app['twig'],
                $app['url_generator']
            );
        });

    }

    public function boot(Application $app)
    {
    }
}
