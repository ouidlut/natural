<?php

namespace App\Providers;

use Silex\Application;
use Silex\ServiceProviderInterface;
use App\Usecases;
use App\Repositories;
use App\Validators;
use Hikaritsushin\Service\Password;



class AddProjectServiceProvider implements ServiceProviderInterface
{
    public function register(Application $app)
    {
        $app['add_project.usecase'] = $app->share(function () use ($app) {
            $addproject= new Repositories\AddProjectRepository($app['db']);

            return new Usecases\AddProjectUsecase($addproject);
        });
    }

    public function boot(Application $app)
    {


    }
}
