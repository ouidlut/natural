<?php

namespace App\Providers;

use Silex\Application;
use Silex\ServiceProviderInterface;
use App\Usecases;
use App\Repositories;
use App\Validators;
use Hikaritsushin\Service\Password;

class CsvDownloadServiceProvider implements ServiceProviderInterface
{
    public function register(Application $app)
    {
        $app['csvdownload.usecase'] = $app->share(function () use ($app) {
            $csvdownload_repository = new Repositories\CsvDownloadRepository($app['db']);

            return new Usecases\CsvDownloadUsecase($csvdownload_repository);
        });
    }
    public function boot(Application $app)
    {
    }
}
