<?php

namespace App\Providers;

use Silex\Application;
use Silex\ServiceProviderInterface;
use Symfony\Bridge\Twig\TwigEngine;

use App\Mailer;

class MailServiceProvider implements ServiceProviderInterface
{
  public function register(Application $app)
  {
    $app['Mailer'] = $app->share(function () use ($app) {
      return new Mailer\AppliedApplicationMailer($app['mailer'],$app['twig']);
    });
  }

  public function boot(Application $app)
  {

  }
}
