<?php

namespace App\Usecases;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use Hikaritsushin\Service\Password;
use App\Validators\UserAuthorizationValidator;
use Symfony\Component\HttpFoundation\ParameterBag;

class UserAuthorizationUsecase
{
  protected $repository;
  protected $validator;
  protected $password;
  private $errors = array();

  public function __construct(RepositoryInterface $repository, UserAuthorizationValidator $validator, $password)
    {
        $this->repository = $repository;
        $this->validator = $validator;
        $this->password = $password;
    }

    public function auth(ParameterBag $request)
    {
      $user_data = $this->loginData($request);
      if ($user_data) {
        return true;
      }
      $entity = $this->repository->buildUserInfo($request->all());
      $errors = $this->validator->loginValidations($entity);
      if (0 !== count($errors)) {
        $this->addErrors(array(
            'auth_error' => 'IDまたはパスワードが違います。'
          ));
        }
        $this->addErrors($errors);
        return false;
    }

    public function loginData(ParameterBag $request)
    {
      $user_id = $request->get('user_id');
      $password = $request->get('password');
      if (!$user_id || !$password) {
              return false;
        }
      $parameter = array('user_id' => $user_id , 'password' => $password);
      $user_entity = $this->repository->buildUserInfo($parameter);
      $user_data = $this->repository->findByIdAndPassword($user_entity);
      if($user_data)
      {
        return true;
      }
      return false;
    }

    public function getUserData(ParameterBag $request)
    {
        $user_id = $request->get('user_id');
        $password = $request->get('password');

        if (!$user_id || !$password) {
            return false;
        }
        //$hash_password = $this->password->getStretchedPassword($id, $password);
        $parameter = array('user_id' => $user_id , 'password' => $password);
        $user_entity = $this->repository->buildUserInfo($parameter);
        $user_data = $this->repository->findByIdAndPassword($user_entity);
        return $user_data;
    }

    private function addErrors(Array $errors = array())
      {
          $this->errors = array_merge($this->errors, $errors);
      }

      /**
       *Function to get all the errors(if any).
       *
       *@return $error - an array of errors
       */
      public function getErrors()
      {
          return $this->errors;
      }
}
