<?php

namespace App\Usecases;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use Hikaritsushin\Service\Password;
use App\Validators\UserAdditionValidator;
use Symfony\Component\HttpFoundation\ParameterBag;

class UserAdditionUsecase
{
  protected $repository;
  protected $validator;
  private $errors = array();

  public function __construct(RepositoryInterface $repository, UserAdditionValidator $validator)
    {
        $this->repository = $repository;
        $this->validator = $validator;
    }

    public function saveUser(ParameterBag $request)
    {
      $new_user_entity = $this->repository->buildNewUserInfo($request->all());
      $errors = $this->validator->entryValidations($new_user_entity);
      if ($errors != NULL) {
        return false;
      }
      $result = $this->repository->saveNewUser($new_user_entity);
      return $result;
    }

    private function addErrors(Array $errors = array())
      {
          $this->errors = array_merge($this->errors, $errors);
      }

      /**
       *Function to get all the errors(if any).
       *
       *@return $error - an array of errors
       */
      public function getErrors()
      {
          return $this->errors;
      }
}
