<?php

namespace App\Usecases;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use Hikaritsushin\Service\Password;
use App\Validators\UserAdditionValidator;
use Symfony\Component\HttpFoundation\ParameterBag;
use App\Repositories\HomeRepository;
use App\Entities\AllMembersEntity;
// use Marutoku\Repositories\ApplicationRepository;


class MonthlyDataUsecase
{
  protected $home_repository;
  private $errors = array();
  // protected $repository;

  public function __construct(RepositoryInterface $home_repository)
        {
           $this->home_repository = $home_repository;
        }

  public function GetAllUserProjects(EntityInterface $user_info)
  {
    $userprojects = $this->home_repository->FindUserProjectsByAccountId($user_info);
    return $userprojects;
  }

  public function GetUserHours(EntityInterface $user_info,ParameterBag $request)
  {
    $selectedmonth = $this->selectedmonth($request);
    $sorting = $request->get('display');
    $UserHours = $this->home_repository->FindUserHoursByAccountId($user_info, $selectedmonth, $sorting);
    return $UserHours;
  }

  public function GetTotalHours(EntityInterface $user_info,ParameterBag $request)
  {
    $selectedmonth = $this->selectedmonth($request);
    $sorting = $request->get('display');
    $TotalHours = $this->home_repository->FindTotalUserHoursByAccountId($user_info, $selectedmonth, $sorting);
    return $TotalHours;
  }

  public function GetHolidayData(EntityInterface $user_info,ParameterBag $request)
  {
    $selectedmonth = $this->selectedmonth($request);
    $holiday_data = $this->home_repository->FindUserHolidayByAccountId($user_info, $selectedmonth);
    return $holiday_data;
  }

  public function GetProject(EntityInterface $user_info, ParameterBag $request)
  {
    $selectedmonth = $this->selectedmonth($request);
    $pj = $this->home_repository->GetProjectCord2($user_info, $selectedmonth);
    return $pj;
    return $this->home_repository->GetProjectCord($user_info, $selectedmonth);
  }

  public function GetAllProject()
  {
    return $this->home_repository->GetAllProjectCord();
  }

  public function GetProcess()
  {
    return $this->home_repository->GetAllProcess();
  }

  public function GetLockDay()
  {
    return $this->home_repository->GeManualLockDay();
  }

  public function selectedmonth(ParameterBag $request)
  {
    $month = $request->get('month');
    $year = $request->get('year');
    $selectedmonth = ($year.$month);
    $user_month = $this->home_repository->buildmonthInfo($selectedmonth);
    return $user_month;
  }

    public function Userproject(ParameterBag $request, EntityInterface $user_info, $connection)
    {
      $daily_report = $this->home_repository->buildDailyReport($request->all());
      $randnum = rand(100000,999999);
      $date= date("YmdHis");
      $no = $date*100000+$randnum;
      $random_number = array('No' => $no );
      $numberentity = $this->home_repository->builAddMember($random_number);
      $price = $this->home_repository->getCurrentPrice($user_info);
      $daily_report_update = $this->home_repository->AddNewUserProject($daily_report, $user_info, $numberentity, $price, $connection);
    }

    public function deleteUserProjectById(ParameterBag $request, EntityInterface $user_info)
    {
      $deletedata = $this->home_repository->buildDailyReport($request->all());
      if ($request->get('update')) {
        return "update";
      }
      elseif ($request->get('delete')) {
        $deleteflag = $this->home_repository->deleteUserProject($deletedata, $user_info);
        return "delete";
      }
      $deleteflag = $this->home_repository->deleteUserProject($deletedata, $user_info);
      return $deleteflag;

    }
    
    public function getTotalDataFromDailyData(ParameterBag $request, EntityInterface $user_info, $connection, $projectcode)
    {
      $project_data = $this->home_repository->buildDailyReport($request->all());
      $project_sum = $this->home_repository->getTotalDataFromDailyData($project_data, $user_info);
      $update_project_data = $this->home_repository->updateProjectDataTimeAndMoney($project_data, $project_sum, $user_info, $connection);
      $update_total_project_data = $this->home_repository->updateProjectDataTotalTimeAndMoney($project_data, $project_sum, $user_info, $connection);
      return $project_sum;
    }

    public function UpdateProjectById(ParameterBag $request, EntityInterface $user_info, $connection)
    {
      $update_data = $this->home_repository->buildDailyReport($request->all());
      $price = $this->home_repository->getCurrentPrice($user_info);
      $update_flag = $this->home_repository->UpdateUserProject($update_data, $user_info, $price, $connection);
      return $update_data->getNo();
    }

    public function AddNewProject(ParameterBag $request, EntityInterface $user_info, $connection)
    {
      $add_data = $this->home_repository->buildDailyReport($request->all());
      $randnum = rand(100000,999999);
      $date= date("YmdHis");
      $no = $date*100000+$randnum;
      $random_number = array('No' => $no );
      $numberentity = $this->home_repository->builAddMember($random_number);
      $price = $this->home_repository->getCurrentPrice($user_info);
      $add_flag = $this->home_repository->AddNewUserProject($add_data, $user_info, $numberentity, $price, $connection);
      return $no;
    }

    public function UpdateHolidayData(ParameterBag $request, EntityInterface $user_info, $connection)
    {

      $user_flag = $this->home_repository->CheckIfHolidayDataExists($user_info);
      $holiday_data = $this->home_repository->buildHolidayEntity($request->all());
      if (!$user_flag) {
        $holiday_flag = $this->home_repository->AddHolidayData($holiday_data, $user_info, $connection);
        
      } else {
        $holiday_flag = $this->home_repository->UpdateHolidayData($holiday_data, $user_info, $connection);
      }
      $price = $this->home_repository->getCurrentPrice($user_info);
      $update_flag = $this->home_repository->UpdateUserProject($update_data, $user_info, $price, $connection);
      return $update_data->getNo();
    }

    public function CopyProjectForUser(ParameterBag $request, EntityInterface $user_info, $connection)
    {
      $selectedmonth = $request->get('CopyFlg');
      $projects_data = $this->home_repository->FindUserProjectsForCopying($user_info, $selectedmonth);
      foreach ($projects_data as $project) {
      $project_flag[] = $this->home_repository->AddUserProjectAfterCopying($user_info, $project, $connection);
      }
      return $project_flag;
    }

    public function SearchUserNippouById(ParameterBag $request)
    {
      $user_data = $this->home_repository->buildUserEntity($request->all());
      $selectedmonth = $this->selectedmonth($request);
      $sorting = "ProjectCords";
      $daily_data = $this->home_repository->FindUserHoursByAccountId($user_data, $selectedmonth, $sorting);
      return $daily_data;
    }

    public function MakeUserEntity(ParameterBag $request)
    {
      $user_data = $this->home_repository->buildUserEntity($request->all());
      return $user_data;
    }

    public function SearchUserEntity(ParameterBag $request)
    {

      $user_id = $this->home_repository->buildUserEntity($request->all());
      $user_data = $this->home_repository->SearchUserData($user_id);
      return $user_data;
    }


    public function LockbyAdmin(ParameterBag $request, $connection)
    {
      if (!($request->get('lock_day'))) {
        // $this->addErrors(array(
        //     'lock_day' => 'please enter lock day'
        // ));
        return false;
      }
      $lock_flag = 1;
      $locknumber = $this->home_repository->buildUserDailydata($request->all());
      $lock_result = $this->home_repository->insertLockDay($locknumber, $lock_flag, $connection);
      return $lock_result;
    }

    public function releaseLock($connection)
    {
      $lock_result = $this->home_repository->releaseLockDay($connection);
      return $lock_result;
    }

    public function SearchIfUserProjectExists($ProjectCord, $AccountId, $YM)
    {
      $project_exist = $this->home_repository->SearchIfUserProjectExists($ProjectCord, $AccountId, $YM);
      $project_status = $this->home_repository->SearchProjectStatus($ProjectCord, $AccountId, $YM);

      if ($project_exist) {
      // return "exist";
      $data['project'] = 'exist';
      }
      else{
        // return 'not_exist';
      $data['project'] = 'not_exist';  
      }
      
      if ($project_status) {
        $data['status'] = 'ok_status';
      }
      else{
      $data['status'] = 'ng_status';  
      }

      
      return $data;
  }

  private function addErrors(Array $errors = array())
    {
        $this->errors = array_merge($this->errors, $errors);
    }

    /**
     * @return array
     */
    public function getErrors()
    {
        return $this->errors;
    }



}
