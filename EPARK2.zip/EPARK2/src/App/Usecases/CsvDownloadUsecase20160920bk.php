<?php

namespace App\Usecases;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use Hikaritsushin\Service\Password;
use App\Validators\UserAdditionValidator;
use Symfony\Component\HttpFoundation\ParameterBag;
use App\Repositories\DownloadRepository;
// use Marutoku\Repositories\ApplicationReposit

class CsvDownloadUsecase
{
  protected $csvdownload_repository;

  public function __construct(RepositoryInterface $csvdownload_repository)
        {
           $this->csvdownload_repository = $csvdownload_repository;
        }

 public function GetAllProjects($request)
 {
   $YM = $request;
   $allprojects = $this->csvdownload_repository->FindAllProjects($YM);
   return $allprojects;
 }

   public function GetAllProjects2($request)
 {
   $YM = $request;
   $allprojects = $this->csvdownload_repository->FindAllProjects2($YM);
   return $allprojects;
 }

     public function GetAllProjects3($request=null)
 {
   $YM = $request;
   $allprojects = $this->csvdownload_repository->FindAllProjects3($YM);
   return $allprojects;
 }
  public function GetData3($request)
 {
   $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData3($YM);
   return $allprojects;
 }
     public function GetData7($request)
 {
   $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData7($YM);
   return $allprojects;
 }

 public function GetData8($request)
 {
   $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData8($YM);
   return $allprojects;
 }
  public function GetData9($request)
 {
   $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData9($YM);
   return $allprojects;
 }
   public function GetData10($between1, $between2, $status)
 {
//    $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData10($between1,$between2,$status);
   return $allprojects;
 }
 public function GetData11($edit_no = null)
 {
//    $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData11($edit_no);
   return $allprojects;
 }
 public function GetData12($edit_no = null)
 {
//    $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData12($edit_no);
   return $allprojects;
 }
 public function GetData13($edit_no = null)
 {
//    $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData13($edit_no);
   return $allprojects;
 }
 public function GetData14()
 {
//    $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData14();
   return $allprojects;
 }
 public function GetData15()
 {
//    $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData15();
   return $allprojects;
 }
  public function GetProjectData($status, $YM = null)
  {
//    $YM = $request;
    $allprojects = $this->csvdownload_repository->FindProjectData($status,$YM);
    return $allprojects;
  }
  public function GetData1_1($YM = null)
  {

    $all_types = $this->csvdownload_repository->FindCSVData1($YM);
    return $all_types;
  }
  public function GetData1_2($YM = null)
  {
    $all_types = $this->csvdownload_repository->FindCSVData2($YM);
    return $all_types;
  }
  public function GetData2_1($YM = null)
  {
    $all_types = $this->csvdownload_repository->FindCSVData3($YM);
    return $all_types;
  }

}
