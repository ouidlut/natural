<?php

namespace App\Usecases;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use Hikaritsushin\Service\Password;
use App\Validators\UserAdditionValidator;
use Symfony\Component\HttpFoundation\ParameterBag;
use App\Repositories\DownloadRepository;
// use Marutoku\Repositories\ApplicationReposit

class CsvDownloadUsecase
{
    protected $csvdownload_repository;

    public function __construct(RepositoryInterface $csvdownload_repository)
    {
        $this->csvdownload_repository = $csvdownload_repository;
    }

    public function GetAllProjects($request)
    {
        $YM = $request;

        if(empty($YM)){
            $YM =  date('Ym');
        }
        $month = $this->getMonthSplit($YM);
        $year = $this->getYearSplit($YM);
        $allprojects = $this->csvdownload_repository->FindAllProjects($YM, $month, $year);
        return $allprojects;
    }
     public function getShuKeiMoto($YM, $sort)
    {
        $allprojects = $this->csvdownload_repository->getShuKeiMoto($YM, $sort);
        return $allprojects;
    }
    public function getHitoBetsuJisseki($request, $sort)
    {
        $YM = $request;
        if(empty($YM)){
            $YM =  date('Ym');
        }
        $month = $this->getMonthSplit($YM);
        $year = $this->getYearSplit($YM);
        $allprojects = $this->csvdownload_repository->findHitoBetsuJisseki($YM, $month, $year, $sort);
        return $allprojects;
    }
    public function getHitoBetsuNippou($request=null, $sort)
    {
        $YM = $request;
        $allprojects = $this->csvdownload_repository->getHitoBetsuNippou($YM, $sort);
        return $allprojects;
    }
    public function getProjectBetsuNippou($request=null, $sort)
    {
        $YM = $request;
        $allprojects = $this->csvdownload_repository->getProjectBetsuNippou($YM, $sort);
        return $allprojects;
    }
    public function getHitoBetsu($request=null, $sort)
    {
        $YM = $request;
        $allprojects = $this->csvdownload_repository->getHitoBetsu($YM, $sort);
        return $allprojects;
    }
    public function getDeveloper($between1, $between2, $status, $YM2)
    {
        $allprojects = $this->csvdownload_repository->getDeveloper($between1,$between2,$status, $YM2);
        return $allprojects;
    }
    public function getProjectCodeMaster()
    {
        $allprojects = $this->csvdownload_repository->getProjectCodeMaster();
        return $allprojects;
    }
    public function getGyoshuBestuCF($YM = null, $sort)
    {
        $all_types = $this->csvdownload_repository->findGyoshuBestuCF($YM, $sort);
        return $all_types;
    }
    public function getGyoshuBestuPL($YM = null)
    {
    $all_types = $this->csvdownload_repository->findGyoshuBestuPL($YM);
    return $all_types;
  }
  public function getAllPJ($YM = null)//AllProject
  {
    $all_types = $this->csvdownload_repository->getAllPJ($YM);
    return $all_types;
  }
  public function getProductBetsuCF($YM = null)
  {
    $all_types = $this->csvdownload_repository->findProductBetsuCF($YM);
    return $all_types;
  }

  public function getProductBetsuPL($YM = null)
  {
    $all_types = $this->csvdownload_repository->findProductBetsuPL($YM);
    return $all_types;
  }

  public function getAllUserHours(ParameterBag $request , $YM, $showYear, $showMonth, $user_info)
  {
    $user_hours = $this->csvdownload_repository->getAllUserHours($YM, $showYear, $showMonth, $user_info);
    return $user_hours;
  }

    public function getAllUserHoursForCostInfo(ParameterBag $request , $YM, $showYear, $showMonth, $user_info)
  {
    $user_hours = $this->csvdownload_repository->getAllUserHoursForCostInfo($YM, $showYear, $showMonth, $user_info);
    return $user_hours;
  }

       public function getCloseClients(ParameterBag $request, $showYear, $showMonth, $showDay, $showYear_last, $showMonth_last, $showDay_last, $showStatus, $user_info)
    {
        $user_hours = $this->csvdownload_repository->getCloseClients($showYear, $showMonth, $showDay, $showYear_last, $showMonth_last, $showDay_last, $showStatus, $user_info);
        return $user_hours;
    }

    public function getAllUserHoursForClientHours(ParameterBag $request , $YM, $showYear, $user_info)
  {
    $user_hours = $this->csvdownload_repository->getAllUserHoursForClientHours($YM, $showYear, $user_info);
    return $user_hours;
  }

  public function getMonthSplit($YM)
  {
    $month = str_split($YM,2);    //to just get the month of the date request
    if ($month[2] > 9) {
      return $month[2];
    }
    else{
    $month = str_split($month[2], 1);
    return $month[1];
    }
  }
  public function getYearSplit($YM)       //function to get year according to financial year
  {
    $month = str_split($YM,2);
    $year = str_split($YM,4);
    if ($month[2] > 3) {
      return $year[0];
    }
    else{
    return $year[0] -1;;
    }
  }

  public function getSelectedYear($year_type){

    $year = date('Y');
    if ($year_type == 'Date1') {
        $selected_year = $year + 1;
    }
    if ($year_type == 'Date2') {
        $selected_year = $year;
    }
    if ($year_type == 'Date3') {
        $selected_year = $year -1;
    }
  }

  public function getUserProjects($account_id, $year){
    $user_projects = $this->csvdownload_repository->getUserProjects($account_id, $year);
        if (!$user_projects) {
            return false;
        }
        foreach ($user_projects as $projects) {
            $attribute[] = array(
                'project' => $projects['ProjectCord'],
                'status' => $projects['Status'],
                );
        }
    return $attribute;

  }

}
