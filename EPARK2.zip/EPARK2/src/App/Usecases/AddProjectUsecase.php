<?php

namespace App\Usecases;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use Hikaritsushin\Service\Password;
use App\Validators\UserAdditionValidator;
use Symfony\Component\HttpFoundation\ParameterBag;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use App\Repositories\HomeRepository;



/**
 *
 */
class AddProjectUsecase{

  function __construct(RepositoryInterface $addproject)
  {
      $this->addproject = $addproject;
  }

  public function GetName()
  {
      $name = $this->addproject->getnames();

      return $name;
  }

   public function my_json_encode($arr)
    {
        //convmap since 0x80 char codes so it takes all multibyte codes (above ASCII 127). So such characters are being "hidden" from normal json_encoding
        array_walk_recursive($arr, function (&$item, $key) { if (is_string($item)) $item = mb_encode_numericentity($item, array (0x80, 0xffff, 0, 0xffff), 'UTF-8'); });
        return mb_decode_numericentity(json_encode($arr), array (0x80, 0xffff, 0, 0xffff), 'UTF-8');
}

  public function GetBudgetoffice()
  {

    $budgetofficer = $this->addproject->GetBudget();
    return $budgetofficer;
  }

  public function GetBusinessType()
  {
    $business =$this->addproject->GetBusiness();

    return $business;
  }

  public function saveNewProject(ParameterBag $request, EntityInterface $user_info,  $connection)
  {
    $project_data =$this->addproject->BuildNewProject($request->all());
    $randnum = rand(100000,999999);
    $date= date("YmdHis");
    $no = $date*100000+rand(100000,999999);
    $No = number_format($no,0,'.','');
    $random_number = array('No' => $no );
    $numberentity = $this->addproject->builAddMember($random_number);
    $project_insert = $this->addproject->registerNewProject($project_data, $user_info, $numberentity, $connection);
    if ($project_insert) {
      $project_data->setNo($numberentity->getNumber());
      return $project_data;
    }
    return $false;
  }

  public function SearchIfProjectExists($ProjectCord){
    $project_exist = $this->addproject->SearchIfProjectExists($ProjectCord);
    if ($project_exist) {
    return "exist";
    }
    return "not_exist";
  }

  public function getUserDataBySelection(ParameterBag $request)
  {

    $user_name = $this->addproject->BuildUser($request->all());
    $user_data =$this->addproject->GetUserData($user_name);
     if ($user_data) {
       foreach ($user_data as $user) {
            $attribute[] = array('name' => $user->getName(),
                                'AccountId' => $user->getAccountId(),);
        }
    return $attribute;
        }
  if (!$user_data) {
    return $attribute[] = array('name' => '',
                              'AccountId' =>'', );
  }

  }

  public function getBusinessDataBySelection(ParameterBag $request)
  {

    $business_selected = $this->addproject->BuildProject($request->all());
    $business_data =$this->addproject->GetBusinessData($business_selected);
     if ($business_data) {
       foreach ($business_data as $business) {
            $attribute[] = array('product' => $business->getProduct(),);
        }
    return $attribute;
        }
  return false;
  }

  public function getPmoDataBySelection(ParameterBag $request)
  {
    $business_selected = $this->addproject->BuildPmo($request->all());

    $pmo_data =$this->addproject->GetPmoData($business_selected);
     if ($pmo_data) {
       foreach ($pmo_data as $pmo) {
            $attribute[] = array('pmo' => $pmo->getPMO(),);
        }
    return $attribute;
        }
  return false;
  }

  public function getAccountDataBySelection(ParameterBag $request)
  {
    $account_id = $this->addproject->BuildUser($request->all());

    $account_data =$this->addproject->GetAccountData($account_id);
     if ($account_data) {
       foreach ($account_data as $account) {
            $attribute[] = array('Name' => $account->getName(),
                                 'AccountId'=>$account->getAccountId(),
                                 'PriceGroup'=>$account->getPriceGroup(),);
        }
    return $attribute;
        }
  return false;
  }

    public function getMonthDataBySelection(ParameterBag $request)
  {

    $account_id = $this->addproject->BuildUser($request->all());
    $month_data =$this->addproject->GetMonthData($account_id);
     if ($month_data) {
       foreach ($month_data as $month) {
            $attribute[] = array('No'          => $month->getNumber(),
                                 'AccountId'   =>$month->getAccountId(),
                                 'Name'        =>$month->getName(),
                                 'YM'          =>$month->getYM(),
                                 'ProjectCord' =>$month->getProjectCord(),
                                 'Project'     =>$month->getProject(),
                                 'ProcessF'    =>$month->getProcessF(),
                                 'PTime'       =>$month->getPTime(),
                                 'PMoney'      =>$month->getPMoney(),
                                 'Time'        =>$month->getTime(),
                                 'Money'       =>$month->getMoney(),
                                 'UploadF'     =>$month->getUploadF(),
                                 'PriceGroup'  =>$month->getPriceGroup(),);
        }
    return $attribute;
        }
  return false;
  }

  /* 2017/06/27 Add 案件一覧をJSONで返す */
    public function getClientDataBySelection(ParameterBag $request, $user_opno, $user_id, $date)
  {
//echo 'requestAll'.PHP_EOL;
//var_dump($request->all());
	$client_number = $this->addproject->BuildProject($request->all());
//echo 'client_numbar'.PHP_EOL;
//var_dump($client_number);
	/* ---------------------------------------- */
	$user_opno2 = $this->addproject->GetOPNoByClientID($user_id);
	//var_dump($user_opno2);
	//exit;
	/* ---------------------------------------- */
	$client_data = $this->addproject->GetClientData($request->all(), $user_opno2, $user_id, $date);
//echo 'client_data'.PHP_EOL;

	if ($client_data) {
	  foreach ($client_data as $client) {
		$attribute[] = array(
			'ProjectCord' => $client['ProjectCord'],
			'Project' => $client['Project'],
			'ArticleNo' => $client['ArticleNo'],
			'StartDate' => $client['StartDate'],
			'CloseDate' => $client['CloseDate'],
			'OPNo' => $client['OPNo'],
			'Status' => $client['Status'],
			'HouseName' => $client['HouseName'],
			);
	  }
	  return $attribute;
	}
	return false;
  }

  /* 2017/06/27 Add */

  public function InsertNewMemberForProject(ParameterBag $request, $connection)
  {
    $account_id = $this->addproject->BuildUser($request->all());
    $account_data =$this->addproject->GetAccountData($account_id);
    $member_data = $this->addproject->BuildMemberAdd($request->all());
    $member_flag = $this->addproject->InsertIntoMonthlyData($member_data, $account_data[0], $connection);
    return $member_flag;
  }

  public function FindIfUserExists(ParameterBag $request)
  {

    $account_id = $this->addproject->BuildUser($request->all());

    $account_data =$this->addproject->GetAccountData($account_id);
    $member_data = $this->addproject->BuildMemberAdd($request->all());
    $member = $this->addproject->SearchFromMonthlyData($member_data, $account_data[0]);
    return $member;
  }

  public function findPMOMailId(EntityInterface $result)
  {
    $pmo_mail = $this->addproject->FindPMOMail($result);
    return $pmo_mail;
  }

  public function FindProjectDatatoConfirm()
  {
    $project_data = $this->addproject->FindAllProjectListForConfirmation();
    return $project_data;
  }

  public function DeleteMemberFromProject(ParameterBag $request)
  {
    $member_data = $this->addproject->BuildMemberAdd($request->all());
    $member_delete_flag = $this->addproject->DeleteMemberFromMonthlyData($member_data);
    return $member_delete_flag;
  }

  public function getProjectSelectedForConfirmation(ParameterBag $request)
  {
    $project_id = $this->addproject->BuildNewProject($request->all());
    $project_data = $this->addproject->FindProjectDataSelectedForConfirmation($project_id);
    return $project_data;
  }

  public function getGetMemberSeleectedForConfirmation(EntityInterface $project_data)
  {
    $member_data = $this->addproject->FindMemberDataSelectedForConfirmation($project_data);
    return $member_data;
  }

  public function UpdateProjectStatus(ParameterBag $request, $connection)
  {
    $project_status = $this->addproject->BuildNewProject($request->all());
    $project_flag = $this->addproject->UpdateProjectStatusForConfirmation($project_status, $connection);
    return $project_flag;
  }

  public function UpdateMemberFromProject(ParameterBag $request, $connection)
  {
    $member_data = $this->addproject->BuildMemberAdd($request->all());
    $account_id = $this->addproject->BuildUser($request->all());
    $account_data =$this->addproject->GetAccountData($account_id);
    $project_flag = $this->addproject->UpdateMemberDataInProject($member_data, $account_data[0], $connection);
    return $member_data;
  }

  public function UpdateBudgetForProject(ParameterBag $request, $connection)
  {
    $project_code = $this->addproject->BuildMemberData($request->all());
    $project_budget = $this->addproject->FindProjectBudget($project_code);
    $project_flag = $this->addproject->UpdateProjectBudget($project_budget, $project_code, $connection);
  }

  public function CopyAllProjectData(ParameterBag $request, EntityInterface $user_info, $connection)
  {
    $old_project = $this->addproject->BuildNewProject($request->all());
    $new_project_code = $this->addproject->BuildNewProject($request->all());
    $old_project_data = $this->addproject->FindOldProjectData($old_project);
    $old_member_data = $this->addproject->FindMonthTimeSumByProjectId($old_project_data);
    $transfer_project_data = $this->addproject->FindTransferProjectData($new_project_code);
    if(empty($transfer_project_data)){
        return array(
            'result' => 'false',
            'message' => '振替先のProjectCodeが見つかりません'
        );
    }
    elseif ($old_project_data->getProjectCord() === $transfer_project_data->getProjectCord() ) {
        return array(
            'result' => 'false',
            'message' => '振替元と振替先のProjectCodeが同一です'
        );
}
    $date= date("YmdHis");
    $no = $date*100000+rand(100000,999999);
    $No = number_format($no,0,'.','');
    $random_number = array('No' => $no);
    $numberentity = $this->addproject->builAddMember($random_number);
//    $project_insert = $this->addproject->CopyOldProject($old_project_data, $new_project_code, $user_info, $numberentity, $connection);
    if ($old_member_data) {
      foreach ($old_member_data as $member) {
        $this->addproject->CopyOldMember($old_project_data, $transfer_project_data, $member, $numberentity, $connection);             
      }
    }
    return array(
        'result' => 'true',
        'message' =>''
    );
    
  }

  public function DeleteProject(ParameterBag $request, $connection)
  {

    $delete_project = $this->addproject->BuildNewProject($request->all());
    $project = $this->addproject->DeleteProjectEntryFromDatabase($delete_project, $connection);
    return $project;
  }

}
