<?php

namespace App\Usecases;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use Hikaritsushin\Service\Password;
use App\Validators\UserAdditionValidator;
use Symfony\Component\HttpFoundation\ParameterBag;
use App\Repositories\DownloadRepository;
// use Marutoku\Repositories\ApplicationReposit

class CsvDownloadUsecase
{
  protected $csvdownload_repository;

  public function __construct(RepositoryInterface $csvdownload_repository)
        {
           $this->csvdownload_repository = $csvdownload_repository;
        }

 public function GetAllProjects($request)
 {
   $YM = $request;

   if(empty($YM)){
        $YM =  date('Ym');
    }
    $month = $this->getMonthSplit($YM);
    $year = $this->getYearSplit($YM);
   $allprojects = $this->csvdownload_repository->FindAllProjects($YM, $month, $year);
   return $allprojects;
 }

   public function GetAllProjects2($request, $sort)
 {
   $YM = $request;
   if(empty($YM)){
        $YM =  date('Ym');
    }
    $month = $this->getMonthSplit($YM);
    $year = $this->getYearSplit($YM);
   $allprojects = $this->csvdownload_repository->FindAllProjects2($YM, $month, $year, $sort);
   return $allprojects;
 }

  public function GetAllProjects3($request=null, $sort)
 {
   $YM = $request;
   $allprojects = $this->csvdownload_repository->FindAllProjects3($YM, $sort);
   return $allprojects;
 }
  public function GetData3($request)
 {
   $YM = $request;
   if(empty($YM)){
        $YM =  date('Ym');
    }
    $month = $this->getMonthSplit($YM);
    $year = $this->getYearSplit($YM);
   $allprojects = $this->csvdownload_repository->FindData3($YM, $month, $year);
   return $allprojects;
 }
     public function GetData7($request)
 {
   $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData7($YM);
   return $allprojects;
 }

 public function GetData8($request, $sort)
 {
   $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData8($YM, $sort);
   return $allprojects;
 }
  public function GetData9($request)
 {
   $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData9($YM);
   return $allprojects;
 }
   public function GetData10($between1, $between2, $status, $YM2)
 {
//    $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData10($between1,$between2,$status, $YM2);
   return $allprojects;
 }
 public function GetData11($edit_no = null)
 {
//    $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData11($edit_no);
   return $allprojects;
 }
 public function GetData12($edit_no = null)
 {
//    $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData12($edit_no);
   return $allprojects;
 }
 public function GetData13($edit_no = null)
 {
//    $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData13($edit_no);
   return $allprojects;
 }
 public function GetData14()
 {
//    $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData14();
   return $allprojects;
 }
 public function GetData15()
 {
//    $YM = $request;
   $allprojects = $this->csvdownload_repository->FindData15();
   return $allprojects;
 }
  public function GetProjectData($status, $YM)
  { 
    // var_dump($status);
    // var_dump($year);
    // exit();
//    $YM = $request;
    $allprojects = $this->csvdownload_repository->FindProjectData($status,$YM);
    return $allprojects;
  }
  public function GetData1_1($YM = null, $sort)
  {

    $all_types = $this->csvdownload_repository->FindCSVData1($YM, $sort);
     // var_dump($all_types);
        // exit();
    return $all_types;
  }
  public function GetData1_2($YM = null)
  {
    $all_types = $this->csvdownload_repository->FindCSVData2($YM);
    return $all_types;
  }
  public function GetData2_1($YM = null)//AllProject
  {
    $all_types = $this->csvdownload_repository->FindCSVData3($YM);
    return $all_types;
  }

  public function GetData3_1($YM = null)
  {
    $all_types = $this->csvdownload_repository->FindCSVData3_1($YM);
    // var_dump($all_types);
    //     exit();
    return $all_types;
  }
  public function GetData3_2($YM = null)
  {
    $all_types = $this->csvdownload_repository->FindCSVData3_2($YM);
    return $all_types;
  }

  public function getMonthSplit($YM)
  {
    $month = str_split($YM,2);    //to just get the month of the date request
    if ($month[2] > 9) {
      return $month[2];
    }
    else{
    $month = str_split($month[2], 1);
    return $month[1];
    }
  }

  public function getYearSplit($YM)       //function to get year according to financial year
  {
    $month = str_split($YM,2);
    $year = str_split($YM,4);
    if ($month[2] > 3) {
      return $year[0];
    }
    else{
    return $year[0] -1;;
    }
  }

}
