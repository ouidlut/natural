<?php

namespace App\Usecases;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use Hikaritsushin\Service\Password;
use App\Validators\UserAdditionValidator;
use Symfony\Component\HttpFoundation\ParameterBag;
use App\Repositories\HomeRepository;
use App\Entities\MonthDataEntity;
// use Marutoku\Repositories\ApplicationReposit

class AllProjectsUsecase
{
  protected $allprojects_repository;

  public function __construct(RepositoryInterface $allprojects_repository)
  {
    $this->allprojects_repository = $allprojects_repository;
  }

  public function GetAllProjects(ParameterBag $request, $user_info)
  {
    $year_status = $this->projectdata($request);
    if ($year_status->getSearch()) {
      $allprojects = $this->allprojects_repository->FindAllProjectsbyYearandStatusAndSearch($year_status, $user_info);
    } else {
      $allprojects = $this->allprojects_repository->FindAllProjectsbyYearandStatus($year_status, $user_info);
    }
    
    // $allprojects = $this->allprojects_repository->FindAllProjectsbyYearandStatus($year_status);
    return $allprojects;
  }

  public function UpdateProjectStatus(ParameterBag $request, $user_data, $user_info, $connection)
  {
    $project_entity = $this->allprojects_repository->BuildAllProjects($request->all());
    if ($user_data) {
      foreach ($user_data as $user) {
      $this->allprojects_repository->UpdateMemberData($user, $project_entity, $connection);
    }
    }
    
    $project_approval_status = $this->allprojects_repository->GetProjectApprovalStatus($project_entity);
    $project_edit_status = $this->allprojects_repository->UpdateProjectStatusByProjectCode($project_entity, $project_approval_status, $user_info, $connection);
    return $project_edit_status;
  }  

  public function GetProjectsBudget()
  {
    $project_budget = $this->allprojects_repository->GetProjectCompleteBudget();
    return $project_budget;
  }

  public function GetProjectDataById(ParameterBag $request)
  {
    $project_id = $this->allprojects_repository->BuildAllProjects($request->all());
    $project_data = $this->allprojects_repository->FindProjectDataById($project_id);
    return $project_data;
  }

  public function GetProjectMoneyById(ParameterBag $request, EntityInterface $project_data)
  {
    $project_year = $this->allprojects_repository->BuildAllProjects($request->all());
    $project_data = $this->allprojects_repository->FindProjectMoneyDataById($project_year, $project_data);
    // var_dump($project_data);
    // exit();
    return $project_data;
  }

  public function GetMonthDataByProjectId(EntityInterface $project_data)
  {
    $month_data = $this->allprojects_repository->FindMonthDataByProjectId($project_data);
    return $month_data;
  }

  public function GetMonthTimeSumByProjectId(ParameterBag $request, EntityInterface $project_data)
  {
    $project_year = $this->allprojects_repository->BuildAllProjects($request->all());
    $month_sum = $this->allprojects_repository->FindMonthTimeSumByProjectId($project_year, $project_data);
    return $month_sum;
  }

  public function GetProjectMonthTimeSumByProjectId(ParameterBag $request, EntityInterface $project_data)
  {
    $project_year = $this->allprojects_repository->BuildAllProjects($request->all());
    $month_sum = $this->allprojects_repository->FindProjectMonthTimeSumByProjectId($project_year, $project_data);
    return $month_sum;
  }

    public function GetUserDataByProjectID(EntityInterface $edit_data)
  {
    $user_data = $this->allprojects_repository->FindUserDataByProjectCode($edit_data);
    return $user_data;
  }

  public function projectdata(ParameterBag $request)
  {
    $year = $request->get('year');
    $year_next = $year+1;
    $status = $request->get('status');
    $search = $request->get('search');
    $parameter = array('year'=>$year,'year_next'=>$year_next,'status'=>$status, 'search'=> $search,);
    $project_data=$this->allprojects_repository->Buildyearandstatus($parameter);
    return $project_data;
  }

}
