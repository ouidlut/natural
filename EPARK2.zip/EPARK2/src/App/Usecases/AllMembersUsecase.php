<?php

namespace App\Usecases;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use Hikaritsushin\Service\Password;
use App\Validators\UserAdditionValidator;
use Symfony\Component\HttpFoundation\ParameterBag;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpFoundation\FileBag;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use App\Repositories\HomeRepository;
use App\Entities\AllMembersEntity;

/**
 *
 */
class AllMembersUsecase
{
  public function __construct(RepositoryInterface $allmembers)
        {
           $this->allmembers = $allmembers;
        }


        public function GetAllMembers(ParameterBag $request, $user_info)
        {
          $pricegroup = $this->MemberPriceGroup($request);
          if ($pricegroup->getSearch()) {
              $getallmembers = $this->allmembers->FindAllMembersWithSearch($pricegroup, $user_info);
          }
          else {
                $getallmembers=$this->allmembers->FindAllMembers($pricegroup, $user_info);
          }
          return $getallmembers;
        }


        public function MemberPriceGroup(ParameterBag $request)
        {
          $member_group = $this->allmembers->BuildAllmembers($request->all());
          return $member_group;
        }

        public function GetPMO()
        {
            $pmo = $this->allmembers->GetPMO();
            return $pmo;
        }

        public function AddMember(ParameterBag $request, $connection)
        {
            $member= $this->allmembers->builAddMember($request->all());
            if ($member->getNumber()) {
                $update_member = $this->allmembers->UpdateMember($member, $connection);
                return $update_member ? $member : false;
                // return $update_member;
            }
            $randnum = rand(100000,999999);
            $date= date("YmdHis");
            $no = $date*100000+$randnum;
            $member->setNo($no);
            // $random_number = array('No' => $no );
            // $numberentity = $this->allmembers->builAddMember($random_number);
            // $addmember = $this->allmembers->saveToTest($member, $numberentity, $connection);
            $addmember = $this->allmembers->saveToTest($member, $connection);
            return $addmember ? $member : false;
        }

        public function DeleteByMemberId(ParameterBag $request)
        {
            $member= $this->allmembers->builAddMember($request->all());
            $delete_member = $this->allmembers->RemoveMemberById($member);
        }

        public function GetMemberData(ParameterBag $request)
        {
            $member= $this->allmembers->builAddMember($request->all());
            $member_data = $this->allmembers->GetMemberData($member);
            return $member_data;
        }

        public function SearchIfUserExists($AccountId)
        {
          $user_exist = $this->allmembers->SearchIfUserExists($AccountId);
          if ($user_exist) {
          return "exist";
          }
          return "not_exist";
        }








}
