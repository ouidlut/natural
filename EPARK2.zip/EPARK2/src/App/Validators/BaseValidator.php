<?php

namespace App\Validators;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Validator\ConstraintViolationList;
use PHPMentors\DomainKata\Entity\EntityInterface;

/**
 * Description of BaseValidator
 *
 * @author 8085620
 */
class BaseValidator
{
//    public function valid(EntityInterface $entity)
//    {
//        $violation_list = $this->metadata->valid($entity);
//        $violations = $this->flattenViolations($violation_list);
//        return $violations;
//    }

    /**
    *
    *
    * @param ConstraintViolationList $violation_list
    * @param array $violations
    * @return array
    */
    public function flattenViolations(ConstraintViolationList $violation_list, Array $violations = array())
    {
        if (0 === count($violations)) {
            foreach ($violation_list as $violation) {
                $violations[$violation->getPropertyPath()] = $violation->getMessage();
            }
        }

        return $violations;
    }
}
