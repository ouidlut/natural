<?php
namespace App\Validators;

use App\Validators\UserAuthorization;

class UserAuthorizationValidator extends BaseValidator
{
    protected $metadata;

    public function __construct(UserAuthorization\Metadata $metadata)
    {
        $this->metadata = $metadata;
    }

    public function loginValidations($entity)
    {
        $violation_list = $this->metadata->valid($entity);
        $violations = $this->flattenViolations($violation_list);
        return $violations;
    }
}
