<?php
namespace App\Validators\UserAuthorization;

use Symfony\Component\Validator\Validator\RecursiveValidator as Validator;
use Symfony\Component\Validator\Mapping\Factory\LazyLoadingMetadataFactory;
use Symfony\Component\Validator\Constraints as Assert;
use PHPMentors\DomainKata\Entity\EntityInterface;

class Metadata
{
    private $validator;
    private $class_metadata_factory;

    public function __construct(Validator $validator, LazyLoadingMetadataFactory $class_metadata_factory)
    {
        $this->validator = $validator;
        $this->class_metadata_factory = $class_metadata_factory;
    }

    public function valid(EntityInterface $entity)
    {
        $metadata = $this->class_metadata_factory->getMetadataFor($entity);

        $metadata->addPropertyConstraint('user_name', new Assert\NotBlank(array(
            'message' => 'IDまたはパスワードが違います。',
        )));

        $metadata->addPropertyConstraint('user_name', new Assert\Length(array(
            'max' => 16,
            'charset' => 'utf-8',
            'maxMessage' => 'IDまたはパスワードが違います。',
        )));

        $metadata->addPropertyConstraint('password', new Assert\NotBlank(array(
            'message' => 'IDまたはパスワードが違います。',
        )));

        $metadata->addPropertyConstraint('password', new Assert\Length(array(
            'max' => 16,
            'charset' => 'utf-8',
            'maxMessage' => 'IDまたはパスワードが違います。',
        )));



        $violations = $this->validator->validate($entity);
        return $violations;
    }
}
