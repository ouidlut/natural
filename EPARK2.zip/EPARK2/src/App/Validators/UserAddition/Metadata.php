<?php
namespace App\Validators\UserAddition;

use Symfony\Component\Validator\Validator\RecursiveValidator as Validator;
use Symfony\Component\Validator\Mapping\Factory\LazyLoadingMetadataFactory;
use Symfony\Component\Validator\Constraints as Assert;
use PHPMentors\DomainKata\Entity\EntityInterface;

class Metadata
{
    private $validator;
    private $class_metadata_factory;

    public function __construct(Validator $validator, LazyLoadingMetadataFactory $class_metadata_factory)
    {
        $this->validator = $validator;
        $this->class_metadata_factory = $class_metadata_factory;
    }

    public function valid(EntityInterface $entity)
    {
        $metadata = $this->class_metadata_factory->getMetadataFor($entity);

        $metadata->addPropertyConstraint('id', new Assert\NotBlank(array(
            'message' => 'ID is required',
        )));
        $metadata->addPropertyConstraint('name1', new Assert\NotBlank(array(
            'message' => 'name1 is required',
        )));
        $metadata->addPropertyConstraint('name2', new Assert\NotBlank(array(
            'message' => 'name2 is required',
        )));
        $metadata->addPropertyConstraint('class', new Assert\NotBlank(array(
            'message' => 'class is required',
        )));
        $metadata->addPropertyConstraint('company', new Assert\NotBlank(array(
            'message' => 'company is required',
        )));
        $metadata->addPropertyConstraint('email', new Assert\NotBlank(array(
            'message' => 'email is required',
        )));
        $metadata->addPropertyConstraint('email2', new Assert\NotBlank(array(
            'message' => 'email2 is required',
        )));




        $violations = $this->validator->validate($entity);
        return $violations;
    }
}
