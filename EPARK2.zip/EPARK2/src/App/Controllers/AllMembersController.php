<?php

namespace App\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Silex\ControllerProviderInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;


/**
 *
 */
class AllMembersController implements ControllerProviderInterface
{

  public function connect(Application $app)
  {

    $controllers = $app['controllers_factory'];
    $user_info = $app['session']->get('user_info');

    $controllers->before(function (Request $request, Application $app) {
            $user_info = $app['session']->get('user_info');
            if (!$user_info) {
                return $app->redirect($app['url_generator']->generate('login'));
            }
            switch ($user_info->getLevel()) {
                case '事務局':
                    break;
                case '管理者':
                    break;
                case '一般':
                    return $app->redirect($app['url_generator']->generate('home'));
                    break;
                
            }
        });

    $controllers->match('/AllMembers', function (Request $request, Application $app)
    {
      $user_info = $app['session']->get('user_info');
      $app['session']->set('number',null);
      if (!($request->request->get('sort'))) {
              $request->request->set('sort', "all");
            }
      if ($request->isMethod('POST'))
      {
        $allmembers = $app['all_members.usecase']->GetAllMembers($request->request, $user_info);
      }
      else{
        $allmembers = $app['all_members.usecase']->GetAllMembers($request->request, $user_info);  
      }
      $sort_flag = $request->request->get('sort');
      $data = array(
              'allmembers' => $allmembers,
              'sort_flag' => $sort_flag,
              'user_info'    => $user_info
            );
    return $app['twig']->render('allmembers.twig',$data);
    })
    ->bind('AllMembers')
    ->method('GET|POST');

    $controllers->match('/AddMember/{user_id}', function (Request $request, Application $app)
    {
      $user_info = $app['session']->get('user_info');
      $number = $app['session']->get('number');
      $app['session']->set('number',null);
      $request->request->set('No', $number);
      $edit_data = $app['all_members.usecase']->GetMemberData($request->request);
      $allPMO = $app['all_members.usecase']->GetPMO();
      $data = array(
            'allpmo' => $allPMO,
            'edit_data' => $edit_data,
            'user_info'    => $user_info
          );
      $mydb = $app['dbs'];
      $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
      if ($request->isMethod('POST')){
        if ($request->request->get('Number')) {

          $request->request->set('No', $request->request->get('Number'));
        }
        
        $user_info = $app['all_members.usecase']->AddMember($request->request, $connection);
         if ($app['session']->get('number')!=null) {
            $app['session']->set('number', null);  
          }
          $app['session']->set('number', $user_info->getNumber());
        if ($user_info->getAccountId()) {
          return $app->redirect($app['url_generator']->generate('AddMember', array('user_id' => $user_info->getAccountId())));
        }
        
      }
      return $app['twig']->render('AddMember.twig',$data);
    })
    ->bind('AddMember')
    ->method('GET|POST');


    $controllers->match('/EditandDeleteMember', function (Request $request, Application $app)
    {
      $app['session']->set('number', null);  
      $user_info = $app['session']->get('user_info');
      if ($request->isMethod('POST')){
        if ($request->request->get('delete')) {
          $flag = $app['all_members.usecase']->DeleteByMemberId($request->request);
        }
        if ($request->request->get('edit')) {
          $edit_data = $app['all_members.usecase']->GetMemberData($request->request);
          if ($app['session']->get('number')!=null) {
            $app['session']->set('number', null);  
          }
          $user_id = $edit_data->getAccountId();
          $app['session']->set('number', $edit_data->getNumber());
          return $app->redirect($app['url_generator']->generate('AddMember', array('user_id' => $user_id)));
        }
        return $app->redirect($app['url_generator']->generate('AllMembers'));
      }
    return $app['twig']->render('allmembers.twig');;
    })
    ->bind('EditandDeleteMember');

    $controllers->match('/UserExists', function (Request $request, Application $app)
      {
        $AccountId = $request->query->get('AccountId');
        $data = $app['all_members.usecase']->SearchIfUserExists($AccountId);
        return $data;
      })
    ->bind('UserExists');

      return $controllers;
  }


}
