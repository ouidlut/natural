<?php

namespace App\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ParameterBag;
use Silex\ControllerProviderInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Intl\Exception\RuntimeException;

class UploadCsvController implements ControllerProviderInterface
{
	public function connect(Application $app)
	{
		$controllers = $app['controllers_factory'];
		$user_info = $app['session']->get('user_info');

		$controllers->before(function (Request $request, Application $app) {
			$user_info = $app['session']->get('user_info');
			if (!$user_info) {
				return $app->redirect($app['url_generator']->generate('login'));
			}
			switch ($user_info->getLevel()) {
				case '事務局':
					break;
				case '管理者':
					break;
				case '一般':
					return $app->redirect($app['url_generator']->generate('home'));
					break;
			}
		});
		$controllers->match('/UploadCsvProject', function (Request $request, Application $app) {
			$OPNos = array();
			$projectYs = array();
			$clientNos = array();
			$articleNos = array();
			$clientNames = array();
			$statuses = array();
			$types = array();
			$results = array();

			try {
				$user_info = $app['session']->get('user_info');
				// 未定義である・複数ファイルである・$_FILES Corruption 攻撃を受けた
				// どれかに該当していれば不正なパラメータとして処理する
				if (!isset($_FILES['upfile']['error']) || !is_int($_FILES['upfile']['error'])) {
    					throw new RuntimeException('パラメータが不正です');
				}

				// $_FILES['upfile']['error'] の値を確認
				switch ($_FILES['upfile']['error']) {
					case UPLOAD_ERR_OK: // OK
						break;
					case UPLOAD_ERR_NO_FILE:   // ファイル未選択
						throw new RuntimeException('ファイルが選択されていません');
					case UPLOAD_ERR_INI_SIZE:  // php.ini定義の最大サイズ超過
        					case UPLOAD_ERR_FORM_SIZE: // フォーム定義の最大サイズ超過 (設定した場合のみ)
            						throw new RuntimeException('ファイルサイズが大きすぎます');
        					default:
            						throw new RuntimeException('その他のエラーが発生しました');
    				}

    				// ここで定義するサイズ上限のオーバーチェック
    				// (必要がある場合のみ)
    				if ($_FILES['upfile']['size'] > 1000000) {
        					throw new RuntimeException('ファイルサイズが大きすぎます');
				}
	
				$name = $_FILES['upfile']['name'];
				$tmp_name = $_FILES['upfile']['tmp_name'];
				$detect_order = 'ASCII,JIS,UTF-8,CP51932,SJIS-win';
				setlocale(LC_ALL, 'ja_JP.UTF-8');

				if (!strpos($name , ".csv")) {
					throw new RuntimeException('ファイル形式が不正です');
				}

    				// $_FILES['upfile']['mime']の値はブラウザ側で偽装可能なので
    				// MIMEタイプに対応する拡張子を自前で取得する
    				if (!$ext = array_search(mime_content_type($tmp_name),array('csv' => 'text/plain'),true)) {
        				throw new RuntimeException('ファイル形式が不正です');
    				}
	
				/* 文字コードを変換してファイルを置換 */
				$buffer = file_get_contents($tmp_name);
				if (!$encoding = mb_detect_encoding($buffer, $detect_order, true)) {
					// 文字コードの自動判定に失敗
					unset($buffer);
					throw new RuntimeException('文字コード変換エラー');
				}
				file_put_contents($tmp_name, mb_convert_encoding($buffer, 'UTF-8', $encoding));
				unset($buffer);
	
				//データベース選択
				$link = mysql_connect('localhost', 'root', 'tAbI=6Vw43');
				
				if(!$link) {
					throw new RuntimeException("データベース接続失敗");
				}
				
				$db = mysql_select_db('epark_report_manage', $link);

				if(!$db) {
					throw new RuntimeException("データベース選択失敗");
				}
				
			//	$projectYs = array();
			//	$clientNos = array();
			//	$articleNos = array();
			//	$clientNames = array();
			//	$statuses = array();
			//	$types = array();
			//	$results = array();
				mysql_query("SET AUTOCOMMIT = 0");
				mysql_query("begin");
				try {
					
					$fp = fopen($tmp_name, 'rb');
					fgetcsv($fp);
					while ($row = fgetcsv($fp)) {
						//$count = recCount($pdo);
						$error = "";
						if($row === array(null) or ($row[0] === "" and $row[1] === "" and $row[2] === "" and $row[3] === "" and $row[4] === "" and $row[5] === "" and $row[6] === "" and $row[7] === "" and $row[8] === "" and $row[9] === "" and $row[10] === "") or $row[7] === "" ) {
							//　空行はスキップまたは全項目が空白のとき
							continue;
						}
						array_unshift ($row, date('YmdHis').rand(10000, 99999));

						if (count($row) !== 12) {
							throw new RuntimeException('データ項目数が誤っているデータがあります');
						} else if ($row[1] === "" or $row[2] === "" or $row[3] === "" or $row[4] === "" or $row[6] === "" or $row[7] === "") {
							if ($row[1] === "") {
								throw new RuntimeException('OP番号が反映されていないデータがあります');
							}
							if ($row[2] === "") {
								throw new RuntimeException('作成年が反映されていないデータがあります');
							}
							if ($row[3] === "") {
								throw new RuntimeException('顧客番号が反映されていないデータがあります');
							}
							if (mb_strlen($row[3]) !== 8) {
								throw new RuntimeException('顧客番号の形式が誤っています');
							}
							if ($row[4] === "") {
								throw new RuntimeException('物件番号が反映されていないデータがあります');
							}
							//if (mb_strlen($row[4]) !== 15) {
							//	throw new RuntimeException('物件番号の形式が誤っています');
							//}
							if ($row[6] === "") {
								throw new RuntimeException('顧客名が反映されていないデータがあります');
							}
							//if ($row[7] === "") {
							//	throw new RuntimeException('ステータスが反映されていないデータがあります');
							//}
							if($row[8] === "") {
								throw new RuntimeException('業種が反映されていないデータがあります');
							}
						//	$OPNos[] = $row[1];
                                               // 	$projectYs[] = $row[2];
                                               // 	$clientNos[] = $row[3];
                                                //	$articleNos[] = $row[4];
                                                //	$clientNames[] = $row[5];
                                                //	$statuses[] = $row[6];
                                                //	$types[] = $row[7];
                                                //	$results[] = $error;
						} else {
							if ($row[10] === "") {
								$row[10] = "0000-00-00";
							}
							if ($row[11] === "") {
								$row[11] = "0000-00-00";
							}
							$executed = mysql_query( 'INSERT INTO ProjectData (
											No,
											OPNo,
											ProjectY,
											ProjectCord, 
											ArticleNo, 
											HouseName, 
											Project, 
											Status,
											BusinessType, 
											Custodian, 
											CloseDate,
											CancelDate,
											AddDate,
											AddTime,
											AddName,
											OP_ArticleNo
										)
										VALUES (
											"'.$row[0].'", 
											"'.$row[1].'", 
											"'.$row[2].'", 
											"'.$row[3].'", 
											"'.$row[4].'",
											"'.$row[5].'", 
											"'.$row[6].'", 
											"'.$row[7].'", 
											"'.$row[8].'", 
											"'.$row[9].'", 
											"'.$row[10].'",
											"'.$row[11].'", 
											"'.date("Y-m-d").'",
											"'.date("H:i:s").'",
											"'.$user_info->getUserName().'",
											"'.$row[1].$row[4].'"
										)
										ON DUPLICATE KEY UPDATE
											OPNo = "'.$row[1].'",
											ProjectY = "'.$row[2].'", 
											ProjectCord = "'.$row[3].'",
											HouseName = "'.$row[5].'", 
											Project = "'.$row[6].'", 
											Status = "'.$row[7].'", 
											BusinessType = "'.$row[8].'", 
											Custodian = "'.$row[9].'", 
											CloseDate = "'.$row[10].'", 
											CancelDate = "'.$row[11].'", 
											EditDate = "'.date('Y-m-d').'",
											EditTime = "'.date('H:i:s').'",
											EditName = "'.$user_info->getUserName().'",
											OP_ArticleNo = "'.$row[1].$row[4].'"'
							); 

							if(!$executed) {
								if(strpos(mysql_error($link), 'PRIMARY') !== false) {
									throw new RuntimeException("登録済みの顧客は追加できません");
								} else {
									throw new RuntimeException(mysql_error($link));
								}
							} else {
								$error = 'OK';
							}
						}
						if ($error != 'OK') {
							$OPNos[] = $row[1];
							$projectYs[] = $row[2];
							$clientNos[] = $row[3];
							$articleNos[] = $row[4];
							$clientNames[] = $row[6];
							$statuses[] = $row[7];
							$types[] = $row[8];
							$results[] = $error;
						}
						
					}
					if(!feof($fp)) {
						throw new RuntimeException('読み込みの途中でエラーが発生しました');
					}
					fclose($fp);
					mysql_query("commit");
					} catch (RuntimeException $e) {
						fclose($fp);
						mysql_query("rollback");
						throw $e;
					}
				if (isset($executed)) {
					//一回以上実行された
					$msg = array('green', '新規作成・更新成功');
				} else {
					//一回も実行されていない
					$msg = array('black', '新規作成・更新できるデータはありませんでした');
				}
	
			} catch (RuntimeException $e) {
				$msg = array('red', $e->getMessage());
			}

			$user_info = $app['session']->get('user_info');
			$data = array( 'user_info' => $user_info, 'msg' => $msg, 'OPNos' => $OPNos, 'projectYs' => $projectYs, 'clientNos' => $clientNos, 'articleNos' => $articleNos, 
					'clientNames' => $clientNames, 'statuses' => $statuses, 'types' => $types, 'results' => $results);
			return $app['twig']->render('UploadCsvProject.twig', $data);
		})
		->bind('UploadCsvProject')
		->method('GET|POST');
		return $controllers;

	}
}
