<?php

namespace App\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Silex\ControllerProviderInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;

class Home implements ControllerProviderInterface
{
      public function connect(Application $app)
      {
        $controllers = $app['controllers_factory'];
        $user_info = $app['session']->get('user_info');

        $controllers->match('/', function (Request $request, Application $app)
        {
            $user_info = $app['session']->get('user_info');
            $workingmonth = $app['monthly_data.usecase']->GetAllUserProjects($user_info);
              if ($request->isMethod('POST'))
              {
                  // $workingmonth = $app['monthly_data.usecase']->GetAllUserProjects($user_info);
                  $WorkingHours = $app['monthly_data.usecase']->GetUserHours($user_info,$request->request);
                  $data = array(
                        'workingmonth' => $workingmonth,
                        'WorkingHours' => $WorkingHours
                      );

                  return $app['twig']->render('home.twig',$data);
            }
            $data = array('workingmonth' => $workingmonth);
            return $app['twig']->render('home.twig',$data);

        })
          ->bind('home')
          ->method('GET|POST');


          $controllers->match('/AddProject', function (Request $request, Application $app)
          {
            $workingmonth = $app['monthly_data.usecase']->GetProject();
              return $app['twig']->render('AddProject.twig');
          })
          ->bind('AddProject');


          return $controllers;



      }


}
