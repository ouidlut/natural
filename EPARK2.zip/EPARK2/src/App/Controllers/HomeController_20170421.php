<?php

namespace App\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\ParameterBag;
use Silex\ControllerProviderInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\HttpFoundation\JsonResponse;

class HomeController implements ControllerProviderInterface
{
      public function connect(Application $app)
      {
        $controllers = $app['controllers_factory'];
        $user_info = $app['session']->get('user_info');

        $controllers->before(function (Request $request, Application $app) {
            $user_info = $app['session']->get('user_info');
            if (!$user_info) {
                return $app->redirect($app['url_generator']->generate('login'));
            }


        });

        $controllers->match('/', function (Request $request, Application $app) {
            $user_info = $app['session']->get('user_info');
            if (!($request->request->get('display'))) {
              $request->request->set('display', "ProjectCords");
            }
            if (!($request->request->get('month'))) {
              $request->request->set('month', date('m'));
            }
            if (!($request->request->get('year'))) {
              $request->request->set('year', date('Y'));
            }
            $month = $request->request->get('month');
            $year = $request->request->get('year');

            $display = $request->request->get('display');
            $WorkingHours = $app['monthly_data.usecase']->GetUserHours($user_info, $request->request);
            $TotalHours = $app['monthly_data.usecase']->GetTotalHours($user_info, $request->request);
            $holiday_data = $app['monthly_data.usecase']->GetHolidayData($user_info,$request->request);
            $projectCordAndName = $app['monthly_data.usecase']->GetProject($user_info, $request->request);
            $all_projects = $app['monthly_data.usecase']->GetAllProject();
            // $mydb = $app['dbs'];
            // $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
            // $lock_release = $app['monthly_data.usecase']->releaseLock($connection);
            // var_dump($lock_release);
            // exit();
            $process = $app['monthly_data.usecase']->GetProcess();
            $lock_day = $app['monthly_data.usecase']->GetLockDay();
            if ($request->isMethod('POST')) {
                $WorkingHours = $app['monthly_data.usecase']->GetUserHours($user_info, $request->request);
                $holiday_data = $app['monthly_data.usecase']->GetHolidayData($user_info,$request->request);
                $data = array(
                    // 'workingmonth' => $workingmonth,
                    'WorkingHours' => $WorkingHours,
                    'TotalHours' => $TotalHours,
                    'projectCord' => $projectCordAndName,
                    'holiday_data' => $holiday_data,
                    'month' => $month,
                    'year' => $year,
                    'display' => $display,
                    'process' => $process,
                    'all_projects' => $all_projects,
                    'lock_day' => $lock_day,
                    'user_info'    => $user_info
                  );
                return $app['twig']->render('home.twig', $data);
            }
            $data = array(
                          // 'workingmonth' => $workingmonth ,
                          'WorkingHours' => $WorkingHours,
                          'TotalHours' => $TotalHours,
                          'projectCord' => $projectCordAndName,
                          'holiday_data' => $holiday_data,
                          'month' => $month,
                          'year' => $year,
                          'display' => $display,
                          'process' => $process,
                          'all_projects' => $all_projects,
                          'lock_day' => $lock_day,
                          'user_info'    => $user_info
                          );
            return $app['twig']->render('home.twig', $data);
        })
        ->bind('home')
        ->method('GET|POST');


        $controllers->match('/dropDownData', function (Request $request, Application $app) {
            $user_info = $app['session']->get('user_info');
            if (!($request->request->get('month'))) {
              $request->request->set('month', date('Ym'));
            }
            $projectCordAndName = $app['monthly_data.usecase']->GetProject($user_info, $request->request);
            $data = json_encode($projectCordAndName , JSON_UNESCAPED_UNICODE);
            $response = new Response($data);
            $response->headers->set('Content-Type', 'application/json; charset=UTF-8');
            return $response;
        })
        ->bind('dropDownData');

        $controllers->post('/DeleteProject', function (Request $request, Application $app) {
            $user_info = $app['session']->get('user_info');
              $update_and_delete_flag = $app['monthly_data.usecase']->deleteUserProjectById($request->request, $user_info);
              return json_encode("Done");
          })
          ->bind('DeleteUserProject');

          $controllers->post('/UpdateUserProject', function (Request $request, Application $app) {
              $user_info = $app['session']->get('user_info');
              if ($request->isMethod('POST')) {
              $mydb = $app['dbs'];
              $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
              if ($request->get('No')==true) {
                $change_flag = $app['monthly_data.usecase']->UpdateProjectById($request->request, $user_info, $connection);
              }
              else{
               $change_flag = $app['monthly_data.usecase']->AddNewProject($request->request, $user_info, $connection);
              }
              return json_encode($change_flag);
              }
            })
            ->bind('UpdateUserProject')
            ->method('GET|POST');

          $controllers->post('/CopyProject', function (Request $request, Application $app) {
            $user_info = $app['session']->get('user_info');
            $mydb = $app['dbs'];
            $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
            $app['monthly_data.usecase']->CopyProjectForUser($request->request, $user_info, $connection);
            return $app->redirect($app['url_generator']->generate('home'));
          })
          ->bind('CopyUserProject');

          $controllers->post('/HolidayAdd', function (Request $request, Application $app) {
            $user_info = $app['session']->get('user_info');
            $mydb = $app['dbs'];
            $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
            $holiday_flag = $app['monthly_data.usecase']->UpdateHolidayData($request->request, $user_info, $connection);
          })
          ->bind('HolidayAdd');

          // $controllers->post('/SearchNippou', function (Request $request, Application $app) {
          //   $admin_info = $app['session']->get('user_info');
          //   $user_info1 = $app['monthly_data.usecase']->MakeUserEntity($request->request);
          //   $user_info = $app['monthly_data.usecase']->SearchUserEntity($request->request);
          //   if (!($request->request->get('display'))) {
          //     $request->request->set('display', "ProjectCords");
          //   }
          //   if (!($request->request->get('month'))) {
          //     $request->request->set('month', date('Ym'));
          //   }
          //   $WorkingHours = $app['monthly_data.usecase']->GetUserHours($user_info, $request->request);
          //   $holiday_data = $app['monthly_data.usecase']->GetHolidayData($user_info,$request->request);
          //   $TotalHours = $app['monthly_data.usecase']->GetTotalHours($user_info, $request->request);
          //   $projectCordAndName = $app['monthly_data.usecase']->GetProject($user_info, $request->request);
          //   $process = $app['monthly_data.usecase']->GetProcess();
          //   if ($request->isMethod('POST')) {
          //     $WorkingHours = $app['monthly_data.usecase']->GetUserHours($user_info, $request->request);
          //     $holiday_data = $app['monthly_data.usecase']->GetHolidayData($user_info,$request->request);
          //     $data = array(
          //         // 'workingmonth' => $workingmonth,
          //         'WorkingHours' => $WorkingHours,
          //         'TotalHours' => $TotalHours,
          //         'projectCord' => $projectCordAndName,
          //         'holiday_data' => $holiday_data,
          //         'process' => $process,
          //         'user_info' => $user_info,
          //         'admin_info' => $admin_info
          //       );
          //     return $app['twig']->render('homesearch.twig', $data);
          //   }
          //   $data = array(
          //                 // 'workingmonth' => $workingmonth ,
          //                 'WorkingHours' => $WorkingHours,
          //                 'TotalHours' => $TotalHours,
          //                 'projectCord' => $projectCordAndName,
          //                 'holiday_data' => $holiday_data,
          //                 'process' => $process,
          //                 'user_info' => $user_info,
          //                 'admin_info' => $admin_info
          //                 );
          //   return $app['twig']->render('homesearch.twig', $data);
          // })
          // ->bind('SearchNippou');

    $controllers->post('/SearchNippou/{user_id}', function (Request $request, Application $app, $user_id) {
            $request->request->set('user_id', $user_id);
            $admin_info = $app['session']->get('user_info');
            $user_info1 = $app['monthly_data.usecase']->MakeUserEntity($request->request);
            $user_info = $app['monthly_data.usecase']->SearchUserEntity($request->request);
            if (!($request->request->get('display'))) {
              $request->request->set('display', "ProjectCords");
            }
            if (!($request->request->get('month'))) {
              $request->request->set('month', date('m'));
            }
            if (!($request->request->get('year'))) {
              $request->request->set('year', date('Y'));
            }
            $month = $request->request->get('month');
            $year = $request->request->get('year');
            $WorkingHours = $app['monthly_data.usecase']->GetUserHours($user_info, $request->request);
            $holiday_data = $app['monthly_data.usecase']->GetHolidayData($user_info,$request->request);
            $TotalHours = $app['monthly_data.usecase']->GetTotalHours($user_info, $request->request);
            $projectCordAndName = $app['monthly_data.usecase']->GetProject($user_info, $request->request);
            // var_dump($projectCordAndName);
            $all_projects = $app['monthly_data.usecase']->GetAllProject();
            $lock_day = $app['monthly_data.usecase']->GetLockDay();
            $process = $app['monthly_data.usecase']->GetProcess();
            if ($request->isMethod('POST')) {
              $WorkingHours = $app['monthly_data.usecase']->GetUserHours($user_info, $request->request);
              $holiday_data = $app['monthly_data.usecase']->GetHolidayData($user_info,$request->request);
              $data = array(
                  // 'workingmonth' => $workingmonth,
                  'WorkingHours' => $WorkingHours,
                  'TotalHours' => $TotalHours,
                  'projectCord' => $projectCordAndName,
                  'holiday_data' => $holiday_data,
                  'process' => $process,
                  'all_projects' => $all_projects,
                  'user_info' => $user_info,
                  'month' => $month,
                  'year' => $year,
                  'lock_day' => $lock_day,
                  'admin_info' => $admin_info
                );
              return $app['twig']->render('homesearch.twig', $data);
            }
            $data = array(
                          // 'workingmonth' => $workingmonth ,
                          'WorkingHours' => $WorkingHours,
                          'TotalHours' => $TotalHours,
                          'projectCord' => $projectCordAndName,
                          'holiday_data' => $holiday_data,
                          'process' => $process,
                          'all_projects' => $all_projects,
                          'user_info' => $user_info,
                          'month' => $month,
                          'year' => $year,
                          'lock_day' => $lock_day,
                          'admin_info' => $admin_info
                          );
            return $app['twig']->render('homesearch.twig', $data);
          })
          ->bind('SearchNippou')
          ->method('GET|POST')
          ->assert('user_id', '\d{1,7}');

    $controllers->match('/UpdateUserProjectbyAdmin', function (Request $request, Application $app)
    {
      $user_info = $app['monthly_data.usecase']->MakeUserEntity($request->request);
      $mydb = $app['dbs'];
      $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
      $change_flag = $app['monthly_data.usecase']->UpdateProjectById($request->request, $user_info, $connection);
      return json_encode($change_flag);
    })
    ->bind('UpdateUserProjectByAdmin');

   $controllers->match('/lockday', function (Request $request, Application $app)
      {
         if ($request->isMethod('POST'))
         {
            $mydb = $app['dbs'];
            $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
            $lock = $app['monthly_data.usecase']->LockbyAdmin($request->request, $connection);
            return $app->redirect($app['url_generator']->generate('home'));
            return $lock;
         }
        return $app->redirect($app['url_generator']->generate('home'));
      })
      ->bind('lockday');

      $controllers->match('/releaselock', function (Request $request, Application $app)
      {

         if ($request->isMethod('POST'))
         {
            $mydb = $app['dbs'];
            $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
            $lock = $app['monthly_data.usecase']->releaseLock($connection);
            return $app->redirect($app['url_generator']->generate('home'));
            // return $lock;
         }
        return $app->redirect($app['url_generator']->generate('home'));
      })
      ->bind('releaselock');

      $controllers->match('/UserProjectExists', function (Request $request, Application $app)
      {
        $ProjectData = $request->query->get('ProjectCord');
        $ProjectCode = explode("/", $ProjectData);
        $AccountId = $request->query->get('AccountId');
        $YM = $request->query->get('YM');
        $data = $app['monthly_data.usecase']->SearchIfUserProjectExists($ProjectCode[0], $AccountId, $YM);
        // return json_encode($data);
        return new JsonResponse($data);
        // return $data;
      })
    ->bind('UserProjectExists');

    return $controllers;
        }
}
