<?php

namespace App\Controllers\Login\NewUser;

use Silex\Application;
use Silex\ControllerProviderInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;

class NewUserController implements ControllerProviderInterface
{
      public function connect(Application $app)
      {
        $controllers = $app['controllers_factory'];
        $user_info = $app['session']->get('user_info');


        $controllers->match('/newuser', function (Request $request, Application $app)
        {
          if ($request->isMethod('POST')) {
              $result = $app['user_addition.usecase']->saveUser($request->request);

              if ($result) {
                return $app->redirect($app['url_generator']->generate('login'));
              }
          }

            return $app['twig']->render('newuser.twig');

        })
          ->bind('newuser');
              return $controllers;
      }


}
