<?php

namespace App\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Silex\ControllerProviderInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Goodby\CSV\Export\Standard\Exporter;
use Goodby\CSV\Export\Standard\ExporterConfig;

class CsvDownloadController implements ControllerProviderInterface
{

    public function connect(Application $app)
    {
        $controllers = $app['controllers_factory'];
        $user_info = $app['session']->get('user_info');


        $controllers->before(function (Request $request, Application $app) {
            $user_info = $app['session']->get('user_info');
            if (!$user_info) {
                return $app->redirect($app['url_generator']->generate('login'));
            }
            switch ($user_info->getLevel()) {
                case '事務局':
                    break;
                case '管理者':
                    break;
                case '一般':
                    return $app->redirect($app['url_generator']->generate('home'));
                    break;
            }
            });

        $controllers->match('/', function (Application $app) {
            $user_info = $app['session']->get('user_info');

            $data['month_value']['0'] = date("Y/m/01", strtotime("0 month"));
            $data['month_value']['1'] = date("Y/m/01", strtotime("-1 month"));
            $data['month_value']['2'] = date("Y/m/01", strtotime("-2 month"));
            $data['month_value']['3'] = date("Y/m/01", strtotime("-3 month"));
            $data['month_value']['4'] = date("Y/m/01", strtotime("-4 month"));
            $data['month_value']['5'] = "<".date("Y/m/01", strtotime("-5 month"));
            $data['month_value']['6'] = "<".date("Y/m/01", strtotime("-6 month"));
            $data['month_value']['7'] = "<".date("Y/m/01", strtotime("-7 month"));
            $data['month_value']['8'] = "<".date("Y/m/01", strtotime("-8 month"));
            $data['month_value']['9'] = "<".date("Y/m/01", strtotime("-9 month"));
            $data['month_value']['10'] = "<".date("Y/m/01", strtotime("-10 month"));
            $data['month_value']['11'] = "<".date("Y/m/01", strtotime("-11 month"));

            $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
            $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
            $data['month_label']['2'] = date("Y年m月", strtotime("-2 month"));
            $data['month_label']['3'] = date("Y年m月", strtotime("-3 month"));
            $data['month_label']['4'] = date("Y年m月", strtotime("-4 month"));
            $data['month_label']['5'] = date("Y年m月", strtotime("-5 month"));
            $data['month_label']['6'] = date("Y年m月", strtotime("-6 month"));
            $data['month_label']['7'] = date("Y年m月", strtotime("-7 month"));
            $data['month_label']['8'] = date("Y年m月", strtotime("-8 month"));
            $data['month_label']['9'] = date("Y年m月", strtotime("-9 month"));
            $data['month_label']['10'] = date("Y年m月", strtotime("-10 month"));
            $data['month_label']['11'] = date("Y年m月", strtotime("-11 month"));
            $data2 = array(
                'data' => $data,
                'user_info'    => $user_info
            );
            return $app['twig']->render('csv_download.twig', $data2);
        })
        ->bind('csvdownload')
        ->method('GET|POST');

        //業種別CF(旧data1_1)-----------------------------------------------------------------------------
        $controllers->match('/GyoshuBetsuCF', function (Application $app) {
            $user_info = $app['session']->get('user_info');
            $request = Request::createFromGlobals();
            if (!($request->request->get('sort'))) {
                $request->request->set('sort', "PMO");
            }
            if (!($request->request->get('showYear'))) {
            $request->request->set('showYear', date('Y'));
            }
            if (!($request->request->get('showMonth'))) {
                $request->request->set('showMonth', date('m'));
            }
            $sort = $request->request->get('sort');
            $year = $request->request->get('showYear');
            $month = $request->request->get('showMonth');
            $data['showYear'] = $year;
            $data['showMonth'] = $month;
            $YM = $year.$month;

            // $show_month = $request->request->get('showMonth',0);
            $download_type = $request->request->get('download',0);
            $data['status'] = $request->request->get('status','人件費');

            // $data['month_value']['0'] = date("Ym", strtotime("0 month"));
            // $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
            // $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
            // $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
            // $YM = date("Ym", strtotime("-$show_month month"));
            $data['YM'] = $YM;
            // $data['M'] = date("m", strtotime("-$show_month month"));
            $data['sort'] = $sort;
            // $data['show_month'] = $show_month;
            $type_list = $app['csvdownload.usecase']->getGyoshuBestuCF($YM,$sort);

            if(!empty($type_list)){
                foreach ($type_list as $key => $type) {
                    $total_days =  date('t', mktime(0, 0, 0, $month, 1, $year));

                    if (date('n') == $month && date('Y') == $year) {
                        $current_days = intval(date('d'));
                    }
                    else{
                        $current_days = $total_days;
                    }

                    $data['project_list'][$key] = array(
                        'BusinessType' => $type['BusinessType'], //業種1
                        'Accounting' => $type['Accounting'], //業種2
                        'PMO' => $type['PMO'], //業種2
                        'RowCount' => count($type['toYear']),
                        'Price' => array(),
                    );
                    $data['project_list'][$key]['Price']['px']['toMonth'] = array();
                    $data['project_list'][$key]['Price']['oc']['toMonth'] = array();
                    if(!empty($type['toMonth'])){
                        foreach ($type['toMonth'] as $key2 => $price_group) {
                            if($price_group['PriceGroup'] == '人件費'){
                                // $PMoney = 0;
                                if(!empty($PMoney)){
                                    $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                    // $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                                    $box2 = round((($price_group['Money'] / $current_days * $total_days) / ($PMoney / 12)) *100).'%'; //進捗
                                } else {
                                    $box1 = '-';
                                    $box2 = '-';
                                }
                                $data['project_list'][$key]['Price']['px']['toMonth'] = array(
                                    'PriceGroup' => $price_group['PriceGroup'], //科目
                                    'PMoney' => $PMoney, //予算
                                    'Money' => $price_group['Money'], //実績
                                    'Box1' => $box1, //実績進捗
                                    // 'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                    'Month' => floor($price_group['Money'] / $current_days * $total_days), //月末着地
                                    'Difference' => $PMoney - floor($price_group['Money'] / $current_days * $total_days), //着地差異
                                    'Box2' => $box2 //進捗
                                );
                            } elseif($price_group['PriceGroup'] == '外注費') {
                                // $PMoney = 0;
                                if(!empty($PMoney)){
                                    $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                    $box2 = round((($price_group['Money'] / $current_days * $total_days) / ($PMoney / 12)) *100).'%'; //進捗
                                } else {
                                    $box1 = '-';
                                    $box2 = '-';
                                }
                                $data['project_list'][$key]['Price']['oc']['toMonth'] = array(
                                    'PriceGroup' => $price_group['PriceGroup'], //科目
                                    'PMoney' => $PMoney, //予算
                                    'Money' => $price_group['Money'], //実績
                                    'Box1' => $box1, //実績進捗
                                    'Month' => floor($price_group['Money'] / $current_days * $total_days), //月末着地
                                    'Difference' => $PMoney - floor($price_group['Money'] / $current_days * $total_days), //着地差異
                                    'Box2' => $box2 //進捗
                                );
                            }
                        }
                    }
                    $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array();
                    $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array();
                    if(!empty($type['elapsedMonth'])){
                        foreach ($type['elapsedMonth'] as $key2 => $price_group) {
                            if($price_group['PriceGroup'] == '人件費'){
                                // $PMoney = 0;
                                if(!empty($PMoney)){
                                    $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                } else {
                                    $box1 = '-';
                                }
                                $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array(
                                    'PriceGroup' => $price_group['PriceGroup'], //科目
                                    'PMoney' => $PMoney, //予算
                                    'Money' => $price_group['Money'], //実績
                                    'Box1' => $box1, //実績進捗
                                );
                            } elseif($price_group['PriceGroup'] == '外注費') {
                                // $PMoney = 0;
                                if(!empty($PMoney)) {
                                    $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                } else {
                                    $box1 = '-';
                                    $box2 = '-';
                                }
                                $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                    'PriceGroup' => $price_group['PriceGroup'], //科目
                                    'PMoney' => $PMoney, //予算
                                    'Money' => $price_group['Money'], //実績
                                    'Box1' => $box1, //実績進捗
                                );
                            }
                        }
                    }

                    $data['project_list'][$key]['Price']['px']['toYear'] = array();
                    $data['project_list'][$key]['Price']['oc']['toYear'] = array();

                    if(!empty($type['toYear'])){
                        foreach ($type['toYear'] as $key2 => $price_group) {
                            if($price_group['PriceGroup'] == '人件費'){
                                // $PMoney = 0;
                                if(!empty($PMoney)){
                                    $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                } else {
                                    $box1 = '-';
                                }
                                $data['project_list'][$key]['Price']['px']['toYear'] = array(
                                    'PriceGroup' => $price_group['PriceGroup'], //科目
                                    'PMoney' => $PMoney, //予算
                                    // 'PMoney' => $price_group['PMoney'], //予算
                                    'Money' => $price_group['Money'], //実績
                                    'Box1' => $box1, //実績進捗
                                );
                            } elseif($price_group['PriceGroup'] == '外注費') {
                                // $PMoney = 0;
                                if(!empty($PMoney)){
                                    $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                } else {
                                    $box1 = '-';
                                }
                                $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                    'PriceGroup' => $price_group['PriceGroup'], //科目
                                    'PMoney' => $PMoney, //予算
                                    // 'PMoney' => $price_group['PMoney'], //予算
                                    'Money' => $price_group['Money'], //実績
                                    'Box1' => $box1, //実績進捗
                                );
                            }
                        }
                    }
                }
            }
            if($download_type === 'csv') {
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header("Content-Disposition: attachment; filename=業種別（CF)-$YM.csv");
                $stream = fopen("php://output", "w");
                $csv_header = array(
                    'BusinessType','','row3'
                );
                $csv_label =  array(
                    '業種','科目','請求先責任者','担当PMO',$data['M'].'月度予算',$data['M'].
                    '月実績(資産+費用)',$data['M'].'月実績進捗',$data['M'].'月末着地','着地差異','着地進捗',
                    '経過月予算','経過月実績','経過月進捗','年間予算','年間実績','年間進捗'
                );
                $numeric_label = array();
                foreach ($csv_label as $value) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $value);
                    $numeric_label[] = $value;
                }
                fputcsv($stream, $numeric_label);

                foreach($data['project_list'] as $key => $value) {
                    if((!empty($value['Price']['px']['toMonth'])) 
                        OR (!empty($value['Price']['px']['elapsedMonth'])) 
                        OR (!empty($value['Price']['px']['toYear']))) {

                        if(!empty($value['Price']['px'])){
                            $csv_value[$key]['px']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['px']['row2'] = '人件費';
                            $csv_value[$key]['px']['row3'] = $value['Accounting'];
                            $csv_value[$key]['px']['row4'] = $value['PMO'];

                            if(!empty($value['Price']['px']['toMonth'])){
                                $csv_value[$key]['px']['row5'] = $value['Price']['px']['toMonth']['PMoney'];
                                $csv_value[$key]['px']['row6'] = $value['Price']['px']['toMonth']['Money'];
                                $csv_value[$key]['px']['row7'] = $value['Price']['px']['toMonth']['Box1'];
                                $csv_value[$key]['px']['row8'] = $value['Price']['px']['toMonth']['Month'];
                                $csv_value[$key]['px']['row9'] = $value['Price']['px']['toMonth']['Difference'];
                                $csv_value[$key]['px']['row10'] = $value['Price']['px']['toMonth']['Box2'];
                            } else {
                                $csv_value[$key]['px']['row5'] = '';
                                $csv_value[$key]['px']['row6'] = '';
                                $csv_value[$key]['px']['row7'] = '';
                                $csv_value[$key]['px']['row8'] = '';
                                $csv_value[$key]['px']['row9'] = '';
                                $csv_value[$key]['px']['row10'] = '';
                            }
                            if(!empty($value['Price']['px']['elapsedMonth'])){
                                $csv_value[$key]['px']['row11']=$value['Price']['px']['elapsedMonth']['PMoney'];
                                $csv_value[$key]['px']['row12'] =$value['Price']['px']['elapsedMonth']['Money'];
                                $csv_value[$key]['px']['row13'] =$value['Price']['px']['elapsedMonth']['Box1'];
                            } else {
                                $csv_value[$key]['px']['row11'] = '';
                                $csv_value[$key]['px']['row12'] = '';
                                $csv_value[$key]['px']['row13'] = '';
                            }
                            if(!empty($value['Price']['px']['toYear'])){
                                $csv_value[$key]['px']['row11'] = $value['Price']['px']['toYear']['PMoney'];
                                $csv_value[$key]['px']['row12'] = $value['Price']['px']['toYear']['Money'];
                                $csv_value[$key]['px']['row13'] = $value['Price']['px']['toYear']['Box1'];
                            } else {
                                $csv_value[$key]['px']['row11'] = '';
                                $csv_value[$key]['px']['row12'] = '';
                                $csv_value[$key]['px']['row13'] = '';
                            }
                        }
                        if(!empty($value['Price']['oc'])){
                            $csv_value[$key]['oc']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['oc']['row2'] = '外注費';
                            $csv_value[$key]['oc']['row3'] = $value['Accounting'];
                            $csv_value[$key]['oc']['row4'] = $value['PMO'];
                        if(!empty($value['Price']['oc']['toMonth'])){
                            $csv_value[$key]['oc']['row5'] = $value['Price']['oc']['toMonth']['PMoney'];
                            $csv_value[$key]['oc']['row6'] = $value['Price']['oc']['toMonth']['Money'];
                            $csv_value[$key]['oc']['row7'] = $value['Price']['oc']['toMonth']['Box1'];
                            $csv_value[$key]['oc']['row8'] = $value['Price']['oc']['toMonth']['Month'];
                            $csv_value[$key]['oc']['row9'] = $value['Price']['oc']['toMonth']['Difference'];
                            $csv_value[$key]['oc']['row10'] = $value['Price']['oc']['toMonth']['Box2'];
                        } else {
                            $csv_value[$key]['oc']['row5'] = '';
                            $csv_value[$key]['oc']['row6'] = '';
                            $csv_value[$key]['oc']['row7'] = '';
                            $csv_value[$key]['oc']['row8'] = '';
                            $csv_value[$key]['oc']['row9'] = '';
                            $csv_value[$key]['oc']['row10'] = '';
                        }
                        if(!empty($value['Price']['oc']['elapsedMonth'])){
                            $csv_value[$key]['oc']['row11'] = $value['Price']['oc']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['elapsedMonth']['Money'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['elapsedMonth']['Box1'];
                        } else {
                            $csv_value[$key]['oc']['row11'] = '';
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                        }
                        if(!empty($value['Price']['oc']['toYear'])){
                            $csv_value[$key]['oc']['row11'] = $value['Price']['oc']['toYear']['PMoney'];
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['toYear']['Money'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['toYear']['Box1'];
                        } else {
                            $csv_value[$key]['oc']['row11'] = '';
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                        }
                    }
                }
            }
            foreach($csv_value as  $assoc_rows){
                if(!empty($assoc_rows['px'])){
                    $assoc_row = $assoc_rows['px'];
                    $numeric_row = array();
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                    $numeric_row[] = $assoc_row['row1'];
                    $numeric_row[] = $assoc_row['row2'];
                    $numeric_row[] = $assoc_row['row3'];
                    $numeric_row[] = $assoc_row['row4'];
                    $numeric_row[] = $assoc_row['row5'];
                    $numeric_row[] = $assoc_row['row6'];
                    $numeric_row[] = $assoc_row['row7'];
                    $numeric_row[] = $assoc_row['row8'];
                    $numeric_row[] = $assoc_row['row9'];
                    $numeric_row[] = $assoc_row['row10'];
                    $numeric_row[] = $assoc_row['row11'];
                    $numeric_row[] = $assoc_row['row12'];
                    $numeric_row[] = $assoc_row['row13'];
                    fputcsv($stream, $numeric_row);
                }
                if(!empty($assoc_rows['oc'])){
                    $assoc_row = $assoc_rows['oc'];
                    $numeric_row = array();
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                    $numeric_row[] = $assoc_row['row1'];
                    $numeric_row[] = $assoc_row['row2'];
                    $numeric_row[] = $assoc_row['row3'];
                    $numeric_row[] = $assoc_row['row4'];
                    $numeric_row[] = $assoc_row['row5'];
                    $numeric_row[] = $assoc_row['row6'];
                    $numeric_row[] = $assoc_row['row7'];
                    $numeric_row[] = $assoc_row['row8'];
                    $numeric_row[] = $assoc_row['row9'];
                    $numeric_row[] = $assoc_row['row10'];
                    $numeric_row[] = $assoc_row['row11'];
                    $numeric_row[] = $assoc_row['row12'];
                    $numeric_row[] = $assoc_row['row13'];
                    fputcsv($stream, $numeric_row);
                }
            }
            fclose($stream);
            exit();
        } else {
            return $app['twig']->render('csv/csv_gyo_shu_bestu_cf.twig',$data);
        }
    }
    )
    ->bind('GyoshuBetsuCF')
    ->method('GET|POST');

    //業種別PL(旧data1_2)-----------------------------------------------------------------------------
    $controllers->match('/GyoshuBetsuPL', function (Application $app) {

        $request = Request::createFromGlobals();
        if (!($request->request->get('sort'))) {
            $request->request->set('sort', "PMO");
        }
        if (!($request->request->get('showYear'))) {
            $request->request->set('showYear', date('Y'));
        }
        if (!($request->request->get('showMonth'))) {
            $request->request->set('showMonth', date('m'));
        }

        $sort = $request->request->get('sort');
        $year = $request->request->get('showYear');
        $month = $request->request->get('showMonth');
        $data['showYear'] = $year;
        $data['showMonth'] = $month;
        $YM = $year.$month;
        $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        $data['status'] = $request->request->get('status','人件費');
        // $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        // $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        // $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        // $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        // $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
        $data['sort'] = $sort;
        $data['show_month'] = $show_month;
        $data['M'] = date("m", strtotime("-$show_month month"));
        $type_list = $app['csvdownload.usecase']->getGyoshuBestuPL($YM);

        if(!empty($type_list)) {
            foreach ($type_list as $key => $type) {
                
                $data['project_list'][$key] = array(
                    'BusinessType' => $type['BusinessType'], //業種1
                    'Accounting' => $type['Accounting'], //業種2
                    'PMO' => $type['PMO'], //業種2
                    'RowCount' => count($type['toYear']),
                    'Price' => array(),
                );
                $data['project_list'][$key]['Price']['px']['toMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['toMonth'] = array();
                if(!empty($type['toMonth'])) {
                    foreach ($type['toMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費') {
                            if ($type['elapsedMonth'][0]['PMoney'] != NULL) {
                                $PMoney = ( $type['elapsedMonth'][0]['PMoney'] ) / 12;
                            }
                            else{$PMoney = 0; }
                            
                            if(!empty($PMoney)) {
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            } else {
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        } elseif($price_group['PriceGroup'] == '外注費'){

                            // $PMoney = 0;

                            if ($type['elapsedMonth'][0]['PMoney'] != NULL) {
                                $PMoney = ( $type['elapsedMonth'][0]['PMoney'] ) / 12;
                            }
                            else{$PMoney = 0; }


                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            } else {
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array();
                if(!empty($type['elapsedMonth'])) {
                    foreach ($type['elapsedMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費') {

                            if ($type['elapsedMonth'][0]['PMoney'] != NULL) {
                                $PMoney = ( $type['elapsedMonth'][0]['PMoney'] ) / 12;
                            }
                            else{$PMoney = 0; }


                            // $PMoney = 0;

                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            } else {
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        } elseif($price_group['PriceGroup'] == '外注費') {

                            if ($type['elapsedMonth'][0]['PMoney'] != NULL) {
                                $PMoney = ( $type['elapsedMonth'][0]['PMoney'] ) / 12;
                            }
                            else{$PMoney = 0; }


                            // $PMoney = 0;

                            if(!empty($PMoney)) {
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            } else {
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['toYear'] = array();
                $data['project_list'][$key]['Price']['oc']['toYear'] = array();
                if(!empty($type['toYear'])) {
                    foreach ($type['toYear'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費') {

                            if ($type['elapsedMonth'][0]['PMoney'] != NULL) {
                                $PMoney = ( $type['elapsedMonth'][0]['PMoney'] ) / 12;
                            }
                            else{$PMoney = 0; }



                            // $PMoney = 0;

                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            } else {
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['toYear'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        } elseif($price_group['PriceGroup'] == '外注費') {

                            if ($type['elapsedMonth'][0]['PMoney'] != NULL) {
                                $PMoney = ( $type['elapsedMonth'][0]['PMoney'] ) / 12;
                            }
                            else{$PMoney = 0; }


                            // $PMoney = 0;

                            if(!empty($PMoney)) {
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            } else {
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
            }
        }
        if($download_type === 'csv'){
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header("Content-Disposition: attachment; filename=GyoshuBetsuPL-$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'BusinessType','','row3'
            );
            $csv_label =  array(
                '業種','科目','請求先責任者','担当PMO',$data['M'].'月度予算',$data['M'].
                '月実績(費用)',$data['M'].'月実績進捗',$data['M'].'月末着地','着地差異','着地進捗',
                '経過月予算','経過月実績','経過月進捗','年間予算','年間実績','年間進捗'
            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                mb_convert_variables('SJIS-win', 'UTF-8', $value);
                $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);

            foreach($data['project_list'] as $key => $value) {
                if((!empty($value['Price']['px']['toMonth'])) 
                        OR (!empty($value['Price']['px']['elapsedMonth'])) 
                        OR (!empty($value['Price']['px']['toYear']))) {

                    if(!empty($value['Price']['px'])) {
                            $csv_value[$key]['px']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['px']['row2'] = '人件費';
                            $csv_value[$key]['px']['row3'] = $value['Accounting'];
                            $csv_value[$key]['px']['row4'] = $value['PMO'];

                        if(!empty($value['Price']['px']['toMonth'])) {
                            $csv_value[$key]['px']['row5'] = $value['Price']['px']['toMonth']['PMoney'];
                            $csv_value[$key]['px']['row6'] = $value['Price']['px']['toMonth']['Money'];
                            $csv_value[$key]['px']['row7'] = $value['Price']['px']['toMonth']['Box1'];
                            $csv_value[$key]['px']['row8'] = $value['Price']['px']['toMonth']['Month'];
                            $csv_value[$key]['px']['row9'] = $value['Price']['px']['toMonth']['Difference'];
                            $csv_value[$key]['px']['row10'] = $value['Price']['px']['toMonth']['Box2'];
                        } else {
                            $csv_value[$key]['px']['row5'] = '';
                            $csv_value[$key]['px']['row6'] = '';
                            $csv_value[$key]['px']['row7'] = '';
                            $csv_value[$key]['px']['row8'] = '';
                            $csv_value[$key]['px']['row9'] = '';
                            $csv_value[$key]['px']['row10'] = '';
                        }
                        if(!empty($value['Price']['px']['elapsedMonth'])) {
                            $csv_value[$key]['px']['row11'] = $value['Price']['px']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['elapsedMonth']['Money'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['elapsedMonth']['Box1'];
                        } else {
                            $csv_value[$key]['px']['row11'] = '';
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                        }
                        if(!empty($value['Price']['px']['toYear'])){
                            $csv_value[$key]['px']['row11'] = $value['Price']['px']['toYear']['PMoney'];
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['toYear']['Money'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['toYear']['Box1'];
                        } else {
                            $csv_value[$key]['px']['row11'] = '';
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                        }
                    }
                    if(!empty($value['Price']['oc'])) {
                        $csv_value[$key]['oc']['row1'] = $value['BusinessType'];
                        $csv_value[$key]['oc']['row2'] = '外注費';
                        $csv_value[$key]['oc']['row3'] = $value['Accounting'];
                        $csv_value[$key]['oc']['row4'] = $value['PMO'];
                        
                        if(!empty($value['Price']['oc']['toMonth'])) {
                            $csv_value[$key]['oc']['row5'] = $value['Price']['oc']['toMonth']['PMoney'];
                            $csv_value[$key]['oc']['row6'] = $value['Price']['oc']['toMonth']['Money'];
                            $csv_value[$key]['oc']['row7'] = $value['Price']['oc']['toMonth']['Box1'];
                            $csv_value[$key]['oc']['row8'] = $value['Price']['oc']['toMonth']['Month'];
                            $csv_value[$key]['oc']['row9'] = $value['Price']['oc']['toMonth']['Difference'];
                            $csv_value[$key]['oc']['row10'] = $value['Price']['oc']['toMonth']['Box2'];
                        } else {
                            $csv_value[$key]['oc']['row5'] = '';
                            $csv_value[$key]['oc']['row6'] = '';
                            $csv_value[$key]['oc']['row7'] = '';
                            $csv_value[$key]['oc']['row8'] = '';
                            $csv_value[$key]['oc']['row9'] = '';
                            $csv_value[$key]['oc']['row10'] = '';
                        }
                        if(!empty($value['Price']['oc']['elapsedMonth'])) {
                            $csv_value[$key]['oc']['row11'] = $value['Price']['oc']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['elapsedMonth']['Money'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['elapsedMonth']['Box1'];
                        } else {
                            $csv_value[$key]['oc']['row11'] = '';
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                        }
                        if(!empty($value['Price']['oc']['toYear'])) {
                            $csv_value[$key]['oc']['row11'] = $value['Price']['oc']['toYear']['PMoney'];
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['toYear']['Money'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['toYear']['Box1'];
                        } else {
                            $csv_value[$key]['oc']['row11'] = '';
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                        }
                    }
                }
            }
            foreach($csv_value as  $assoc_rows) {
                if(!empty($assoc_rows['px'])) {
                    $assoc_row = $assoc_rows['px'];
                    $numeric_row = array();
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                    $numeric_row[] = $assoc_row['row1'];
                    $numeric_row[] = $assoc_row['row2'];
                    $numeric_row[] = $assoc_row['row3'];
                    $numeric_row[] = $assoc_row['row4'];
                    $numeric_row[] = $assoc_row['row5'];
                    $numeric_row[] = $assoc_row['row6'];
                    $numeric_row[] = $assoc_row['row7'];
                    $numeric_row[] = $assoc_row['row8'];
                    $numeric_row[] = $assoc_row['row9'];
                    $numeric_row[] = $assoc_row['row10'];
                    $numeric_row[] = $assoc_row['row11'];
                    $numeric_row[] = $assoc_row['row12'];
                    $numeric_row[] = $assoc_row['row13'];
                    fputcsv($stream, $numeric_row);
                }
                if(!empty($assoc_rows['oc'])){
                    $assoc_row = $assoc_rows['oc'];
                    $numeric_row = array();
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                    $numeric_row[] = $assoc_row['row1'];
                    $numeric_row[] = $assoc_row['row2'];
                    $numeric_row[] = $assoc_row['row3'];
                    $numeric_row[] = $assoc_row['row4'];
                    $numeric_row[] = $assoc_row['row5'];
                    $numeric_row[] = $assoc_row['row6'];
                    $numeric_row[] = $assoc_row['row7'];
                    $numeric_row[] = $assoc_row['row8'];
                    $numeric_row[] = $assoc_row['row9'];
                    $numeric_row[] = $assoc_row['row10'];
                    $numeric_row[] = $assoc_row['row11'];
                    $numeric_row[] = $assoc_row['row12'];
                    $numeric_row[] = $assoc_row['row13'];
                    fputcsv($stream, $numeric_row);
                }
            }
            fclose('php://output');
            exit();
        }
        else{
            return $app['twig']->render('csv/csv_gyo_shu_bestu_pl.twig',$data);
        }
    }
    )
    ->bind('GyoshuBetsuPL')
    ->method('GET|POST');


    //ALLPJ(data2_1)-----------------------------------------------------------------------------
    $controllers->match('/ALLPJ', function (Application $app) {


        $request = Request::createFromGlobals();
        if (!($request->request->get('showYear'))) {
            $request->request->set('showYear', date('Y'));
        }
        if (!($request->request->get('showMonth'))) {
            $request->request->set('showMonth', date('m'));
        }
        $year = $request->request->get('showYear');
        $month = $request->request->get('showMonth');
        $data['showYear'] = $year;
        $data['showMonth'] = $month;
        $YM = $year.$month;
        
        // $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        // $data['status'] = $request->request->get('status','人件費');
        // $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        // $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        // $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        // $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        // $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
        // $data['M'] = date("m", strtotime("-$show_month month"));
        $project_list = $app['csvdownload.usecase']->getAllPJ($YM);
        if(!empty($project_list)) {
            foreach ($project_list as $key => $project) {
                $total_days =  date('t', mktime(0, 0, 0, $month, 1, $year));

                if (date('n') == $month && date('Y') == $year) {
                    $current_days = intval(date('d'));
                }
                else{
                    $current_days = $total_days;
                }
                if(!empty($project['Budget'])) {
                    $row_13 = floor($project['Budget'] / 12) ;
                    $row_15 = floor(($project['toMonthCFMoney'] / $current_days) * $total_days);
                    $box2 = floor($row_13 / $row_15);
                    $box1 = round( ($project['emCFMoney'] / $project['Budget']) * 100 ).'%'; //進捗
                    // $box2 = round((($project['toMonthCFMoney'] / 7 * 19) / ($project['toYearCFMoney'])) *100).'%'; //進捗
                } else {
                    $box1 = 0;
                    $box2 = '-';
                }
                if(!empty($project['toYearCFMoney'])) {
                    // $box2 = round((($project['toMonthCFMoney'] / 7 * 19) / ($project['toYearCFMoney'])) *100).'%'; //進捗    
                    $row_13 = floor($project['Budget'] / 12) ;
                    $row_15 = floor(($project['toMonthCFMoney'] / $current_days) * $total_days);
                    $box2 = floor(($row_13 / $row_15));
                }
                    else{
                        $box2 = '-';
                    }
                // $box2 = round((($project['toMonthCFMoney'] / 7 * 19) / ($project['toYearCFMoney'])) *100).'%'; //進捗
                if(!empty($project['toYearCFMoney'])){
                    $box3 = round( ($project['toYearASMoney'] / $project['toYearCFMoney']) * 100 ).'%'; //資産率
                    $box4 = round( ($project['toYearPLMoney'] / $project['toYearCFMoney']) * 100 ).'%'; //費用率
                    $box5 = round(($project['toYearASMoney'] / $project['toYearCFMoney'])*100) +
                            round(($project['toYearPLMoney'] / $project['toYearCFMoney'])*100) .'%';
                } else {
                    $box3 = '-';
                    $box4 = '-';
                    $box5 = '-';
                }
                



                $data['project_list'][$key] = array(
                    'row1' => $project['BusinessType'], //業種1
                    'row2' => $project['Product'], //業種2
                    'row3' => $project['PMO'], //PMO
                    'row4' => $project['ProjectCord'], //PJコード
                    'row5' => $project['Project'], //PJ名
                    'row6' => $project['toYearASMoney'], //資産金額
                    'row7' => $project['toYearPLMoney'], //費用金額
                    'row8' => $project['toYearCFMoney'], //合計
                    'row9' => $project['Budget'], //取得予算合計
                    'row10' => $project['emCFMoney'], //累計（当月着地含む）
                    'row11' => $project['Budget'] - $project['emCFMoney'], //着地差異
                    'row12' => $box1, //進捗
                    'row13' => floor($project['Budget'] / 12), //月度予算計画

                    'row14' => $project['toMonthCFMoney'], //月実績
                    'row15' => floor(($project['toMonthCFMoney'] / $current_days) * $total_days), //月末着地

                    'row16' => (floor($project['Budget'] / 12)) - (floor(($project['toMonthCFMoney'] / $current_days) * $total_days)), //着地差異
                    'row17' => $box2, //進捗
                    'row18' => $box3,
                    'row19' => $box4,
                    'row20' => $box5
                );
            }
        } else {
            $data['project_list'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
                'row6' => '',
                'row7' => '',
                'row8' => '',
                'row9' => '',
                'row10' => '',
                'row11' => '',
                'row12' => '',
                'row13' => '',
                'row14' => '',
                'row15' => '',
                'row16' => '',
                'row17' => '',
                'row18' => '',
                'row19' => '',
                'row20' => ''
            );
        }
        
        if($download_type === 'csv'){
            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=ALLPJ-$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'row1','row2','row3'
            );
            $csv_label =  array(
                '業種1','業種2','担当PMO','PJコード','PJ名','資産金額','費用金額','合計',
                '取得予算合計','累計(当月着地含)','着地差異','進捗',
                '月度予算計画','月実績','月末着地','着地差異','進捗','資産率','費用率','合計'
            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $value);
                    $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);

            foreach($data['project_list'] as $key => $assoc_row){
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row14']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row15']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row16']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row17']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row18']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row19']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row20']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                $numeric_row[] = $assoc_row['row12'];
                $numeric_row[] = $assoc_row['row13'];
                $numeric_row[] = $assoc_row['row14'];
                $numeric_row[] = $assoc_row['row15'];
                $numeric_row[] = $assoc_row['row16'];
                $numeric_row[] = $assoc_row['row17'];
                $numeric_row[] = $assoc_row['row18'];
                $numeric_row[] = $assoc_row['row19'];
                $numeric_row[] = $assoc_row['row20'];
                foreach ($csv_header as $header_name) {
                    if(isset($assoc_row['days'][$header_name]['day'])){
                        mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['days'][$header_name]['day']);
                        $numeric_row[] = $assoc_row['days'][$header_name]['day'];
                    }
                }
                fputcsv($stream, $numeric_row);
            }
            fclose($stream);
            exit();
        } else {
            return $app['twig']->render('csv/csv_all_pj.twig',$data);
        }
    }
    )
    ->bind('ALLPJ')
    ->method('GET|POST');

    //プロダクト別CF(data3_1)-----------------------------------------------------------------------------
    $controllers->match('/ProductBetsuCF', function (Application $app) {
        $user_info = $app['session']->get('user_info');

        $request = Request::createFromGlobals();

        if (!($request->request->get('showYear'))) {
            $request->request->set('showYear', date('Y'));
        }
        if (!($request->request->get('showMonth'))) {
            $request->request->set('showMonth', date('m'));
        }

        $year = $request->request->get('showYear');
        $month = $request->request->get('showMonth');

        $data['showYear'] = $year;
        $data['showMonth'] = $month;
        $YM = $year.$month;
        $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        // $data['status'] = $request->request->get('status','人件費');
        // $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        // $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        // $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        // $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        // $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
        // $data['M'] = date("m", strtotime("-$show_month month"));
        // $data['show_month'] = $show_month;
        $type_list = $app['csvdownload.usecase']->getProductBetsuCF($YM);

        if(!empty($type_list)){
            foreach ($type_list as $key => $type) {
                $data['project_list'][$key] = array(
                    'BusinessType' => $type['BusinessType'], //業種1
                    'Product' => $type['Product'], //業種1
                    'Accounting' => $type['Accounting'], //業種2
                    'PMO' => $type['PMO'], //業種2
                    'RowCount' => count($type['toYear']),
                    'Price' => array(),
                );
                $data['project_list'][$key]['Price']['px']['toMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['toMonth'] = array();
                if(!empty($type['toMonth'])){
                    foreach ($type['toMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費') {
                            $PMoney = 0;
                            if(!empty($PMoney)) {
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            } else {
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        } elseif($price_group['PriceGroup'] == '外注費') {
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array();
                if(!empty($type['elapsedMonth'])){
                    foreach ($type['elapsedMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費') {
                            $PMoney = 0;
                            if(!empty($PMoney)) {
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            } else {
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        } elseif($price_group['PriceGroup'] == '外注費') {
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            } else {
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['toYear'] = array();
                $data['project_list'][$key]['Price']['oc']['toYear'] = array();
                if(!empty($type['toYear'])){
                    foreach ($type['toYear'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            } else {
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['toYear'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        } elseif($price_group['PriceGroup'] == '外注費') {
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            } else {
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
            }
        }

        if($download_type === 'csv'){

            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=ProductBetsuCF-$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'BusinessType','','row3'
            );
            $csv_label =  array(
                '業種','プロダクト','科目','請求先責任者','担当PMO',$data['M'].'月度予算'
                ,$data['M'].'月実績(資産+費用)',$data['M'].'月実績進捗',$data['M'].'月末着地','着地差異','着地進捗',
                '経過月予算','経過月実績','経過月進捗','年間予算','年間実績','年間進捗'
            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $value);
                    $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);

            foreach($data['project_list'] as $key => $value){
                if((!empty($value['Price']['px']['toMonth'])) 
                        OR (!empty($value['Price']['px']['elapsedMonth'])) 
                        OR (!empty($value['Price']['px']['toYear']))){

                    if(!empty($value['Price']['px'])){
                            $csv_value[$key]['px']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['px']['row2'] = $value['Product'];
                            $csv_value[$key]['px']['row3'] = '人件費';
                            $csv_value[$key]['px']['row4'] = $value['Accounting'];
                            $csv_value[$key]['px']['row5'] = $value['PMO'];

                        if(!empty($value['Price']['px']['toMonth'])){
                            $csv_value[$key]['px']['row6'] = $value['Price']['px']['toMonth']['PMoney'];
                            $csv_value[$key]['px']['row7'] = $value['Price']['px']['toMonth']['Money'];
                            $csv_value[$key]['px']['row8'] = $value['Price']['px']['toMonth']['Box1'];
                            $csv_value[$key]['px']['row9'] = $value['Price']['px']['toMonth']['Month'];
                            $csv_value[$key]['px']['row10'] = $value['Price']['px']['toMonth']['Difference'];
                            $csv_value[$key]['px']['row11'] = $value['Price']['px']['toMonth']['Box2'];
                        }
                        else{
                            $csv_value[$key]['px']['row6'] = '';
                            $csv_value[$key]['px']['row7'] = '';
                            $csv_value[$key]['px']['row8'] = '';
                            $csv_value[$key]['px']['row9'] = '';
                            $csv_value[$key]['px']['row10'] = '';
                            $csv_value[$key]['px']['row11'] = '';
                        }
                        if(!empty($value['Price']['px']['elapsedMonth'])){
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['elapsedMonth']['Money'];
                            $csv_value[$key]['px']['row14'] = $value['Price']['px']['elapsedMonth']['Box1'];
                        } else {
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                            $csv_value[$key]['px']['row14'] = '';
                        }
                        if(!empty($value['Price']['px']['toYear'])){
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['toYear']['PMoney'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['toYear']['Money'];
                            $csv_value[$key]['px']['row14'] = $value['Price']['px']['toYear']['Box1'];
                        } else {
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                            $csv_value[$key]['px']['row14'] = '';
                        }
                    }
                    if(!empty($value['Price']['oc'])){
                            $csv_value[$key]['oc']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['oc']['row2'] = $value['Product'];
                            $csv_value[$key]['oc']['row3'] = '外注費';
                            $csv_value[$key]['oc']['row4'] = $value['Accounting'];
                            $csv_value[$key]['oc']['row5'] = $value['PMO'];
                        if(!empty($value['Price']['oc']['toMonth'])){
                            $csv_value[$key]['oc']['row6'] = $value['Price']['oc']['toMonth']['PMoney'];
                            $csv_value[$key]['oc']['row7'] = $value['Price']['oc']['toMonth']['Money'];
                            $csv_value[$key]['oc']['row8'] = $value['Price']['oc']['toMonth']['Box1'];
                            $csv_value[$key]['oc']['row9'] = $value['Price']['oc']['toMonth']['Month'];
                            $csv_value[$key]['oc']['row10'] = $value['Price']['oc']['toMonth']['Difference'];
                            $csv_value[$key]['oc']['row11'] = $value['Price']['oc']['toMonth']['Box2'];
                        } else {
                            $csv_value[$key]['oc']['row6'] = '';
                            $csv_value[$key]['oc']['row7'] = '';
                            $csv_value[$key]['oc']['row8'] = '';
                            $csv_value[$key]['oc']['row9'] = '';
                            $csv_value[$key]['oc']['row10'] = '';
                            $csv_value[$key]['oc']['row11'] = '';
                        }
                        if(!empty($value['Price']['oc']['elapsedMonth'])){
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['elapsedMonth']['Money'];
                            $csv_value[$key]['oc']['row14'] = $value['Price']['oc']['elapsedMonth']['Box1'];
                        } else {
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                            $csv_value[$key]['oc']['row14'] = '';
                        }
                        if(!empty($value['Price']['oc']['toYear'])){
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['toYear']['PMoney'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['toYear']['Money'];
                            $csv_value[$key]['oc']['row14'] = $value['Price']['oc']['toYear']['Box1'];
                        } else {
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                            $csv_value[$key]['oc']['row14'] = '';
                        }
                    }
                }
            }
            foreach($csv_value as  $assoc_rows){
                if(!empty($assoc_rows['px'])){
                    $assoc_row = $assoc_rows['px'];
                    $numeric_row = array();
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row14']);
                    $numeric_row[] = $assoc_row['row1'];
                    $numeric_row[] = $assoc_row['row2'];
                    $numeric_row[] = $assoc_row['row3'];
                    $numeric_row[] = $assoc_row['row4'];
                    $numeric_row[] = $assoc_row['row5'];
                    $numeric_row[] = $assoc_row['row6'];
                    $numeric_row[] = $assoc_row['row7'];
                    $numeric_row[] = $assoc_row['row8'];
                    $numeric_row[] = $assoc_row['row9'];
                    $numeric_row[] = $assoc_row['row10'];
                    $numeric_row[] = $assoc_row['row11'];
                    $numeric_row[] = $assoc_row['row12'];
                    $numeric_row[] = $assoc_row['row13'];
                    $numeric_row[] = $assoc_row['row14'];
                    fputcsv($stream, $numeric_row);
                }
                if(!empty($assoc_rows['oc'])){
                    $assoc_row = $assoc_rows['oc'];
                    $numeric_row = array();
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row14']);
                    $numeric_row[] = $assoc_row['row1'];
                    $numeric_row[] = $assoc_row['row2'];
                    $numeric_row[] = $assoc_row['row3'];
                    $numeric_row[] = $assoc_row['row4'];
                    $numeric_row[] = $assoc_row['row5'];
                    $numeric_row[] = $assoc_row['row6'];
                    $numeric_row[] = $assoc_row['row7'];
                    $numeric_row[] = $assoc_row['row8'];
                    $numeric_row[] = $assoc_row['row9'];
                    $numeric_row[] = $assoc_row['row10'];
                    $numeric_row[] = $assoc_row['row11'];
                    $numeric_row[] = $assoc_row['row12'];
                    $numeric_row[] = $assoc_row['row13'];
                    $numeric_row[] = $assoc_row['row14'];
                    fputcsv($stream, $numeric_row);
                }
            }
            fclose($stream);
            exit();
        }
        else{
            return $app['twig']->render('csv/csv_product_betsu_cf.twig',$data);
        }
    }
    )
    ->bind('ProductBetsuCF')
    ->method('GET|POST');

    //プロダクト別PL(data3_2)-----------------------------------------------------------------------------
    $controllers->match('/ProductBetsuPL', function (Application $app) {

        $request = Request::createFromGlobals();
        if (!($request->request->get('showYear'))) {
            $request->request->set('showYear', date('Y'));
        }
        if (!($request->request->get('showMonth'))) {
            $request->request->set('showMonth', date('m'));
        }
        $year = $request->request->get('showYear');
        $month = $request->request->get('showMonth');

        $data['showYear'] = $year;
        $data['showMonth'] = $month;
        $YM = $year.$month;
        // $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        $data['status'] = $request->request->get('status','人件費');
        // $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        // $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        // $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        // $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        // $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
        // $data['M'] = date("m", strtotime("-$show_month month"));
        // $data['show_month'] = $show_month;

        $type_list = $app['csvdownload.usecase']->getProductBetsuPL($YM);

        if(!empty($type_list)){
            foreach ($type_list as $key => $type) {

                $data['project_list'][$key] = array(
                    'BusinessType' => $type['BusinessType'], //業種1
                    'Product' => $type['Product'], //業種1
                    'Accounting' => $type['Accounting'], //業種2
                    'PMO' => $type['PMO'], //業種2
                    'RowCount' => count($type['toYear']),
                    'Price' => array(),
                );
                $data['project_list'][$key]['Price']['px']['toMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['toMonth'] = array();
                if(!empty($type['toMonth'])){
                    foreach ($type['toMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            } else {
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        } elseif($price_group['PriceGroup'] == '外注費') {
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            } else {
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array();
                if(!empty($type['elapsedMonth'])){
                    foreach ($type['elapsedMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            } else {
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        } elseif($price_group['PriceGroup'] == '外注費') {
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            } else {
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['toYear'] = array();
                $data['project_list'][$key]['Price']['oc']['toYear'] = array();
                if(!empty($type['toYear'])){
                    foreach ($type['toYear'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            } else {
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['toYear'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        } elseif($price_group['PriceGroup'] == '外注費') {
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            } else {
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
            }
        }
        if($download_type === 'csv'){
            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=ProductBetsuPL-$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'BusinessType','','row3'
            );
            $csv_label =  array(
                '業種', 'プロダクト','科目','請求先責任者','担当PMO',$data['M'].'月度予算',$data['M'].
                '月実績(費用)',$data['M'].'月実績進捗',$data['M'].'月末着地','着地差異','着地進捗',
                '経過月予算','経過月実績','経過月進捗','年間予算','年間実績','年間進捗'
            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $value);
                    $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);

            foreach($data['project_list'] as $key => $value) {
                if((!empty($value['Price']['px']['toMonth'])) 
                        OR (!empty($value['Price']['px']['elapsedMonth'])) 
                        OR (!empty($value['Price']['px']['toYear']))) {

                    if(!empty($value['Price']['px'])) {
                            $csv_value[$key]['px']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['px']['row2'] = $value['Product'];
                            $csv_value[$key]['px']['row3'] = '人件費';
                            $csv_value[$key]['px']['row4'] = $value['Accounting'];
                            $csv_value[$key]['px']['row5'] = $value['PMO'];

                        if(!empty($value['Price']['px']['toMonth'])) {
                            $csv_value[$key]['px']['row6'] = $value['Price']['px']['toMonth']['PMoney'];
                            $csv_value[$key]['px']['row7'] = $value['Price']['px']['toMonth']['Money'];
                            $csv_value[$key]['px']['row8'] = $value['Price']['px']['toMonth']['Box1'];
                            $csv_value[$key]['px']['row9'] = $value['Price']['px']['toMonth']['Month'];
                            $csv_value[$key]['px']['row10'] = $value['Price']['px']['toMonth']['Difference'];
                            $csv_value[$key]['px']['row11'] = $value['Price']['px']['toMonth']['Box2'];
                        }
                        else {
                            $csv_value[$key]['px']['row6'] = '';
                            $csv_value[$key]['px']['row7'] = '';
                            $csv_value[$key]['px']['row8'] = '';
                            $csv_value[$key]['px']['row9'] = '';
                            $csv_value[$key]['px']['row10'] = '';
                            $csv_value[$key]['px']['row11'] = '';
                        }
                        if(!empty($value['Price']['px']['elapsedMonth'])) {
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['elapsedMonth']['Money'];
                            $csv_value[$key]['px']['row14'] = $value['Price']['px']['elapsedMonth']['Box1'];
                        }
                        else {
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                            $csv_value[$key]['px']['row14'] = '';
                        }
                        if(!empty($value['Price']['px']['toYear'])) {
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['toYear']['PMoney'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['toYear']['Money'];
                            $csv_value[$key]['px']['row14'] = $value['Price']['px']['toYear']['Box1'];
                        }
                        else {
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                            $csv_value[$key]['px']['row14'] = '';
                        }
                    }
                    if(!empty($value['Price']['oc'])) {
                        $csv_value[$key]['oc']['row1'] = $value['BusinessType'];
                        $csv_value[$key]['oc']['row2'] = $value['Product'];
                        $csv_value[$key]['oc']['row3'] = '外注費';
                        $csv_value[$key]['oc']['row4'] = $value['Accounting'];
                        $csv_value[$key]['oc']['row5'] = $value['PMO'];

                        if(!empty($value['Price']['oc']['toMonth'])){
                            $csv_value[$key]['oc']['row6'] = $value['Price']['oc']['toMonth']['PMoney'];
                            $csv_value[$key]['oc']['row7'] = $value['Price']['oc']['toMonth']['Money'];
                            $csv_value[$key]['oc']['row8'] = $value['Price']['oc']['toMonth']['Box1'];
                            $csv_value[$key]['oc']['row9'] = $value['Price']['oc']['toMonth']['Month'];
                            $csv_value[$key]['oc']['row10'] = $value['Price']['oc']['toMonth']['Difference'];
                            $csv_value[$key]['oc']['row11'] = $value['Price']['oc']['toMonth']['Box2'];
                        } else {
                            $csv_value[$key]['oc']['row6'] = '';
                            $csv_value[$key]['oc']['row7'] = '';
                            $csv_value[$key]['oc']['row8'] = '';
                            $csv_value[$key]['oc']['row9'] = '';
                            $csv_value[$key]['oc']['row10'] = '';
                            $csv_value[$key]['oc']['row11'] = '';
                        }
                        if(!empty($value['Price']['oc']['elapsedMonth'])){
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['elapsedMonth']['Money'];
                            $csv_value[$key]['oc']['row14'] = $value['Price']['oc']['elapsedMonth']['Box1'];
                        } else {
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                            $csv_value[$key]['oc']['row14'] = '';
                        }
                        if(!empty($value['Price']['oc']['toYear'])){
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['toYear']['PMoney'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['toYear']['Money'];
                            $csv_value[$key]['oc']['row14'] = $value['Price']['oc']['toYear']['Box1'];
                        } else {
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                            $csv_value[$key]['oc']['row14'] = '';
                        }
                    }
                }
            }
            foreach($csv_value as  $assoc_rows){
                if(!empty($assoc_rows['px'])){
                    $assoc_row = $assoc_rows['px'];
                    $numeric_row = array();
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row14']);
                    $numeric_row[] = $assoc_row['row1'];
                    $numeric_row[] = $assoc_row['row2'];
                    $numeric_row[] = $assoc_row['row3'];
                    $numeric_row[] = $assoc_row['row4'];
                    $numeric_row[] = $assoc_row['row5'];
                    $numeric_row[] = $assoc_row['row6'];
                    $numeric_row[] = $assoc_row['row7'];
                    $numeric_row[] = $assoc_row['row8'];
                    $numeric_row[] = $assoc_row['row9'];
                    $numeric_row[] = $assoc_row['row10'];
                    $numeric_row[] = $assoc_row['row11'];
                    $numeric_row[] = $assoc_row['row12'];
                    $numeric_row[] = $assoc_row['row13'];
                    $numeric_row[] = $assoc_row['row14'];
                    fputcsv($stream, $numeric_row);
                }
                if(!empty($assoc_rows['oc'])){
                    $assoc_row = $assoc_rows['oc'];
                    $numeric_row = array();
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row14']);
                    $numeric_row[] = $assoc_row['row1'];
                    $numeric_row[] = $assoc_row['row2'];
                    $numeric_row[] = $assoc_row['row3'];
                    $numeric_row[] = $assoc_row['row4'];
                    $numeric_row[] = $assoc_row['row5'];
                    $numeric_row[] = $assoc_row['row6'];
                    $numeric_row[] = $assoc_row['row7'];
                    $numeric_row[] = $assoc_row['row8'];
                    $numeric_row[] = $assoc_row['row9'];
                    $numeric_row[] = $assoc_row['row10'];
                    $numeric_row[] = $assoc_row['row11'];
                    $numeric_row[] = $assoc_row['row12'];
                    $numeric_row[] = $assoc_row['row13'];
                    $numeric_row[] = $assoc_row['row14'];
                    fputcsv($stream, $numeric_row);
                }
            }
            return $app['twig']->render('csv/csv_file.twig');
        } else {
            return $app['twig']->render('csv/csv_product_betsu_pl.twig',$data);
        }
    }
    )
    ->bind('ProductBetsuPL')
    ->method('GET|POST');


    ////AllProjects(data2)-----------------------------------------------------------------------------
    $controllers->match('/data2', function (Application $app) {

        $user_info = $app['session']->get('user_info');
        $request = Request::createFromGlobals();
        $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        $data['month_label']['2'] = date("Y年m月", strtotime("-2 month"));
        $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
        $project_list = $app['csvdownload.usecase']->GetAllProjects($data['YM']);
        if(!empty($project_list)){
            foreach ($project_list as $key => $value) {
                if ($value['Budget']==0) {
                    $row13 = '0%';
                } else {
                    $row13 = round(($value['Money'] / $value['Budget']) * 100).'%';
                }
                //row16, row19
                if ($value['PTime']==0) {
                    $row16 = '0%';
                    $row19 = '0%';
                } else {
                    $row16 = round(($value['Time'] / $value['PTime']) * 100).'%';
                    $row19 = round((round(($value['Time'] / 22) * 22)) / ($value['PTime'])* 100).'%';
                }
                $data['project_list'][$key] = array(
                    'row1' => $value['BusinessType'],
                    'row2' => $value['Product'],
                    'row3' => $value['PMO'],
                    'row4' => $value['ProjectCord'],
                    'row5' => $value['DMoney1_sum'],
                    'row6' => $value['DMoney2_sum'],
                    'row7' => $value['Dtime1_sum'] * 1600,
                    'row8' => $value['DMoney2_sum'] + ($value['Dtime1_sum'] * 1600),
                    'row9' => $value['DMoney1_sum'] + ($value['DMoney2_sum'] + ($value['Dtime1_sum'] * 1600)),
                    'row10' => $value['Budget'],
                    'row11' => $value['Money'],
                    'row12' => $value['Budget'] - $value['Money'],
                    'row13' => $row13,
                    // 'row13' => round(($value['Money'] / $value['Budget']) * 100).'%',
                    'row14' => $value['PTime'],
                    'row15' => $value['Time'],
                    'row16' => $row16,
                    // 'row16' => round(($value['Time'] / $value['PTime']) * 100).'%',
                    'row17' => round(($value['Time'] / 22) * 22),
                    'row18' => $value['PTime'] - round(($value['Time'] / 22) * 22),
                    'row19' => $row19,
                    // 'row19' =>  round((round(($value['Time'] / 22) * 22)) / ($value['PTime'])* 100).'%',
                    'row20' =>  $value['Project']
                );
            }
        } else {
            $data['project_list'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
                'row6' => '',
                'row7' => '',
                'row8' => '',
                'row9' => '',
                'row10' => '',
                'row11' => '',
                'row12' => '',
                'row13' => '',
                'row14' => '',
                'row15' => '',
                'row16' => '',
                'row17' => '',
                'row18' => '',
                'row19' => '',
                'row20' => ''
            );
        }
        if($download_type === 'csv'){
            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=AllProjects$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                 'row1','row2','row3','row4','row5','row6','row7','row8','row9','row10',
                 'row11','row12','row13','row14','row15','row16','row17','row18','row19','row20'
            );
            $csv_label =  array(
                '業種','プロダクト','担当PMO','PJコード','資産実績','費用実績','共通費','費用合計',
                '合計（共通費込）','個別プロジェクト',
                '工数','プロジェクト名','取得予算額','実績合計','着地差異','実績の進捗率','計画','実績',
                '進捗率','月末着地','着地差異','進捗率'
            );
            $numeric_label = array();
         
            foreach ($csv_label as $value) {
                 mb_convert_variables('SJIS-win', 'UTF-8', $value);
                 $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);

            foreach($data['project_list'] as $key => $assoc_row){
                $numeric_row = array();
                foreach ($csv_header as $header_name) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
                    $numeric_row[] = $assoc_row[$header_name];
                }
                fputcsv($stream, $numeric_row);
            }
            return $app['twig']->render('csv/csv_file.twig');
        } else {
            return $app['twig']->render('csv/csv_data2.twig',$data);
        }
    }
    )
    ->bind('csv_data2')
    ->method('GET|POST');

    ////人別実績(data4)-----------------------------------------------------------------------------
    $controllers->match('/HitoBetsuJisseki', function (Application $app) {

        $user_info = $app['session']->get('user_info');
        $request = Request::createFromGlobals();
     
        if (!($request->request->get('sort'))) {
            $request->request->set('sort', "a.PMO");
        }
        if (!($request->request->get('showYear'))) {
            $request->request->set('showYear', date('Y'));
        }
        if (!($request->request->get('showMonth'))) {
            $request->request->set('showMonth', date('m'));
        }
        $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        $sort = $request->request->get('sort');
        $year = $request->request->get('showYear');
        $month = $request->request->get('showMonth');
        $data['showYear'] = $year;
        $data['showMonth'] = $month;
        $YM = $year.$month;
        // $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        // $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        // $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        // $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        // $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
        $data['sort'] = $sort;
        $project_list = $app['csvdownload.usecase']->getHitoBetsuJisseki($data['YM'], $sort);
        $n = date('n');
        if(!empty($project_list)){
            foreach ($project_list as $key => $value) {
                $data['project_list'][$key] = array(
                    'row1' => $value['PMO'],
                    'row2' => '請求先責任者',
                    'row3' => $value['BusinessType'],
                    'row4' => $value['Product'],
                    'row5' => $value['AccountId'],
                    'row6' => $value['Name'],
                    'row7' => $value["Price$n"],
                    'row8' => $value['ProjectCord'],
                    'row9' => $value['Project'],
                    'row10' => $value['DTime1'],
                    'row11' => $value['DTime2'],
                    'row12' => $value['DTime1'] * $value["Price$n"],
                    'row13' => $value['DTime2'] * $value["Price$n"],
                    'row14' => ($value['DTime1'] * $value["Price$n"]) + ($value['DTime2'] * $value["Price$n"] )
                );
            }
        } else {
            $data['project_list'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
                'row6' => '',
                'row7' => '',
                'row8' => '',
                'row9' => '',
                'row10' => '',
                'row11' => '',
                'row12' => '',
                'row13' => '',
                'row14' => ''
            );
        }
        if($download_type === 'csv'){
            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=HitoBetsuJisseki$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                 'row1','row2','row3','row4','row5','row6','row7','row8','row9','row10',
                 'row11','row12','row13','row14'
            );
            $csv_label =  array(
                '担当PMO','請求先責任者','業種','プロダクト','社員番号','氏名','時給単価','PJコード',
                'プロジェクト名','資産/工数',
                '費用/工数','資産実績計','共通費実績計','共通費込実績計'
            );
            $numeric_label = array();

            foreach ($csv_label as $value) {
                mb_convert_variables('SJIS-win', 'UTF-8', $value);
                $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);

            foreach($data['project_list'] as $key => $assoc_row){
                $numeric_row = array();
                foreach ($csv_header as $header_name) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
                     $numeric_row[] = $assoc_row[$header_name];
                 }
                 fputcsv($stream, $numeric_row);
            }
            return $app['twig']->render('csv/csv_file.twig');
        } else {
            return $app['twig']->render('csv/csv_hito_betsu_jisseki.twig',$data);
        }
    }
    )
    ->bind('HitoBetsuJisseki')
    ->method('GET|POST');

////人別資産化率(data5)-----------------------------------------------------------------------------
    $controllers->match('/HitoBetsuSisankaRitsu', function (Application $app) {

        $user_info = $app['session']->get('user_info');
        $request = Request::createFromGlobals();
        if (!($request->request->get('sort'))) {
            $request->request->set('sort', "AccountData.PMO");
        }
        if (!($request->request->get('showYear'))) {
            $request->request->set('showYear', date('Y'));
        }
        if (!($request->request->get('showMonth'))) {
            $request->request->set('showMonth', date('m'));
        }
        // $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        $sort = $request->request->get('sort');
        $year = $request->request->get('showYear');
        $month = $request->request->get('showMonth');
        $data['showYear'] = $year;
        $data['showMonth'] = $month;
        $YM = $year.$month;
        // $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        // $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        // $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        // $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        // $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
        $data['sort'] = $sort;
        $project_list = $app['csvdownload.usecase']->getHitoBetsuNippou($data['YM'], $sort);
        $n = date('n');
        if(!empty($project_list)){
            foreach ($project_list as $key => $value) {
                if((($value['DTime1'] + $value['DTime2'])) !== 0){
                    $row8 = round(($value['DTime1'] / ($value['DTime1'] + $value['DTime2'])) * 100,1);
                    $row9 = round(($value['DTime2'] / ($value['DTime1'] + $value['DTime2'])) * 100,1);
                } else {
                   $row8 = 0;
                   $row9 = 0;
                }
                $data['project_list'][$key] = array(
                    'row1' => $value['PMO'],
                    'row2' => $value['Class'],
                    'row3' => $value['AccountId'],
                    'row4' => $value['Name'],
                    'row5' => $value['DTime1'],
                    'row6' => $value['DTime2'],
                    'row7' => $value['DTime1']  + $value['DTime2'],
                    'row8' => $row8.'%',
                    'row9' => $row9.'%'
                );
            }
        } else {
            $data['project_list'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
                'row6' => '',
                'row7' => '',
                'row8' => '',
                'row9' => ''
            );
        }
        if($download_type === 'csv'){
            header_remove();
            header("Content-Disposition: attachment; filename=HitoBetsuShisankaRitsu$YM.csv");
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; charset=UTF-8');
            header('Vary: User-Agent');
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'row1','row2','row3','row4','row5','row6','row7','row8','row9'
            );
            $csv_label =  array(
                '役職','社員番号','氏名','PMO名','資産/工数','費用/工数','工数総計','資産化率','費用率'
            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                mb_convert_variables('SJIS-win', 'UTF-8', $value);
                $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);
            foreach($data['project_list'] as $key => $assoc_row){
                $numeric_row = array();
                foreach ($csv_header as $header_name) {
                    mb_convert_kana(mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]), "R" ) ;
                    $numeric_row[] = $assoc_row[$header_name];
                }
                fputcsv($stream, $numeric_row);
            }
            fclose($stream);
            exit();
        } else {
            return $app['twig']->render('csv/csv_hito_betsu_sisanka_ritsu.twig',$data);
        }
    }
    )
    ->bind('HitoBetsuSisankaRitsu')
    ->method('GET|POST');


////人別日報入力(data6)-----------------------------------------------------------------------------
    $controllers->match('/HitoBetsuNippou', function (Application $app) {
        $user_info = $app['session']->get('user_info');
        $request = Request::createFromGlobals();
    
        if (!($request->request->get('sort'))) {
            $request->request->set('sort', "AccountData.PMO");
        }
        if (!($request->request->get('showYear'))) {
            $request->request->set('showYear', date('Y'));
        }
        if (!($request->request->get('showMonth'))) {
            $request->request->set('showMonth', date('m'));
        }
        // $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        // $sort = $request->request->get('sort');
        $sort = $request->request->get('sort');
        $year = $request->request->get('showYear');
        $month = $request->request->get('showMonth');
        $data['showYear'] = $year;
        $data['showMonth'] = $month;
        $YM = $year.$month;
        // $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        // $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        // $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        // $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        // $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
        $data['sort'] = $sort;
        $project_list = $app['csvdownload.usecase']->getHitoBetsuNippou($data['YM'], $sort);
        $n = date('n');
        if(!empty($project_list)){
            foreach ($project_list as $key => $value) {
                $data['project_list'][$key] = array(
                    'row1' => $value['PMO'],
                    'row2' => $value['Class'],
                    'row3' => $value['AccountId'],
                    'row4' => $value['Name'],
                    'row5' => $value['DTime1'],
                    'row6' => $value['DTime2'],
                    'row7' => $value['DTime1']  + $value['DTime2'],
//                    'row8' => $value['InputDate'],
                );
            }
        } else {
            $data['project_list'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
                'row6' => '',
                'row7' => '',
//                'row8' => '',
            );
        }
//        echo "<meta charset='UTF-8'/><pre>";
//print_r($data['project_list']);
//echo "</pre>";
//exit;
        if($download_type === 'csv'){
            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=資産化率$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'row1','row2','row3','row4','row5','row6','row7','row8','row9','row10'
            );
            $csv_label =  array(
                '年月','PMO名','役職','社員番号','氏名','資産・工数','費用・工数','工数合計'
            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                mb_convert_variables('SJIS-win', 'UTF-8', $value);
                $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);
         
            foreach($data['project_list'] as $key => $assoc_row){
                $numeric_row = array();
                $numeric_row[] = $YM; 
                foreach ($csv_header as $header_name) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
                    $numeric_row[] = $assoc_row[$header_name];
                }
                fputcsv($stream, $numeric_row);
            }
            fclose($stream);
            exit();
        } else {
            return $app['twig']->render('csv/csv_hito_betsu_nippou.twig',$data);
        }
    }
    )
    ->bind('HitoBetsuNippou')
    ->method('GET|POST');

    ////PJ別日報入力(data6)-----------------------------------------------------------------------------
    $controllers->match('/ProjectBetsuNippou', function (Application $app) {
        $user_info = $app['session']->get('user_info');
        $request = Request::createFromGlobals();
    
        if (!($request->request->get('sort'))) {
            $request->request->set('sort', "AccountData.PMO");
        }
        if (!($request->request->get('showYear'))) {
            $request->request->set('showYear', date('Y'));
        }
        if (!($request->request->get('showMonth'))) {
            $request->request->set('showMonth', date('m'));
        }
        $show_month = $request->request->get('showMonth',0);

        $year = $request->request->get('showYear');
        $month = $request->request->get('showMonth');
        $data['showYear'] = $year;
        $data['showMonth'] = $month;
        $YM = $year.$month;
        $download_type = $request->request->get('download',0);

        $sort = $request->request->get('sort');
        // $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        // $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        // $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        // $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        // $YM = date("Ym", strtotime("-$show_month month"));
        // $data['YM'] = $request->request->get('showMonth',0);
        $data['sort'] = $sort;
        $data['YM'] = $YM;
        $project_list = $app['csvdownload.usecase']->getProjectBetsuNippou($data['YM'], $sort);
        $n = date('n');
        if(!empty($project_list)){
            foreach ($project_list as $key => $value) {
                $data['project_list'][$key] = array(
                    'row1' => $value['BusinessType'],
                    'row2' => $value['ProjectCord'],
                    'row3' => $value['Project'],
                    'row4' => $value['Class'],
                    'row5' => $value['AccountId'],
                    'row6' => $value['Name'],
//                    'row7' => $value['PMO'],
                    'row8' => $value['DTime1'],
                    'row9' => $value['DTime2'],
                    'row10' => $value['DTime1']  + $value['DTime2'],
                );
            }
        } else {
            $data['project_list'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
                'row6' => '',
//                'row7' => '',
                'row8' => '',
                'row9' => '',
                'row10' => ''
            );
        }
        if($download_type === 'csv'){
            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=ProjectBetsuNippouNyuRyouku$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'row1','row2','row3','row4','row5','row6','row8','row9','row10'
            );
            $csv_label =  array(
                '業種','PJコード','プロジェクト名','役職','社員番号','氏名','資産・工数','費用・工数','工数総計'
            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                mb_convert_variables('SJIS-win', 'UTF-8', $value);
                $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);
         
            foreach($data['project_list'] as $key => $assoc_row){
                $numeric_row = array();
                foreach ($csv_header as $header_name) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
                    $numeric_row[] = $assoc_row[$header_name];
                }
                fputcsv($stream, $numeric_row);
            }
            return $app['twig']->render('csv/csv_file.twig');

        } else {
            return $app['twig']->render('csv/csv_project_betsu_nippou.twig',$data);
        }
    }
    )
    ->bind('ProjectBetsuNippou')
    ->method('GET|POST');

////集計moto(data8)-----------------------------------------------------------------------------
    $controllers->match('/ShuKeiMoto', function (Application $app) {
        $user_info = $app['session']->get('user_info');
        $request = Request::createFromGlobals();
     
        if (!($request->request->get('sort'))) {
            $request->request->set('sort', "PMO");
        }
        if (!($request->request->get('showYear'))) {
            $request->request->set('showYear', date('Y'));
        }
        if (!($request->request->get('showMonth'))) {
            $request->request->set('showMonth', date('m'));
        }

        // $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        $sort = $request->request->get('sort');
        $year = $request->request->get('showYear');
        $month = $request->request->get('showMonth');
        $data['showYear'] = $year;
        $data['showMonth'] = $month;
        $YM = $year.$month;

        // $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        // $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        // $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        // $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        // $YM = date("Ym", strtotime("-$show_month month"));

        $data['YM'] = $YM;
        $data['sort'] = $sort;
        $project_list = $app['csvdownload.usecase']->getShuKeiMoto($data['YM'], $sort);
//       echo "<meta charset='UTF-8'/><pre>";
//print_r($project_list);
//echo "</pre>";
//exit;
 
        $n = date('n');
        if(!empty($project_list)){
            foreach ($project_list as $key => $value) {
                $data['project_list'][$key] = array(
                    'row1' => $value['PMO'],
                    'row2' => $value['Custodian'],
                    'row3' => $value['Accounting'],
                    'row4' => $value['BusinessType'],
                    'row5' => $value['Product'],
//                    'row6' => $value["Price$n"],
                    'row7' => $value['Class'],
                    'row8' => $value['AccountId'],
                    'row9' => $value['Name'],
                    'row10' => $value['ProjectCord'],
                    'row11' => $value['Project'],
                    'row12' => $value['Process1'],
                    'row13' => $value['Process2'],
                    'row14' => $value['SubTime'],
                    'row15' => $value['Box1'],
                    // 'row16' => $value['Box2'],
                );
            }
        } else {
            $data['project_list'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
//                'row6' => '',
                'row7' => '',
                'row8' => '',
                'row9' => '',
                'row10' => '',
                'row11' => '',
                'row12' => '',
                'row13' => '',
                'row14' => '',
                'row15' => '',
//                'row16' => '',
            );
        }
        if($download_type === 'csv'){
            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=ShousanseiKakunin$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'row1','row2','row3','row4','row5','row7','row8','row9','row10',
                'row11','row12','row13','row14','row15'
                // ,'row16'
            );
            $csv_label =  array(
                '担当PMO','PJ責任者','請求先責任者','業種','プロダクト','役職','社員番号',
                '氏名','PJコード','PJ名','工程番号','工程','工数','資産or費用'
            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                mb_convert_variables('SJIS-win', 'UTF-8', $value);
                $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);
            foreach($data['project_list'] as $key => $assoc_row){
                $numeric_row = array();
                foreach ($csv_header as $header_name) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
                    $numeric_row[] = $assoc_row[$header_name];
                }
                fputcsv($stream, $numeric_row);
            }
            fclose($stream);
            exit();
        } else {
            return $app['twig']->render('csv/csv_shu_kei_moto.twig',$data);
        }
    }
    )
    ->bind('ShuKeiMoto')
    ->method('GET|POST');

////開発者リスト(data10)-----------------------------------------------------------------------------
    $controllers->match('/Developer', function (Application $app) {

        $user_info = $app['session']->get('user_info');
        $request = Request::createFromGlobals();

        if (!($request->request->get('year'))) {
            $request->request->set('year', 2016);
        }
        if (!($request->request->get('status'))) {
            $request->request->set('status', '人件費');
        }

        $data['year_flag'] = $request->request->get('year');
        $data['status_flag'] = $request->request->get('status');

        if (!($request->request->get('FMenu'))) {
            $request->request->set('FMenu', 'Date2');
        }
        $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);

        $YM = date("Ym", strtotime("-$show_month month"));
        
        
        // if(date("m")<4){
        //     $data['TCheck'] = date("Ym", strtotime((date("Y")-1).'-04-01'));
        //     $data['SY'] = date("Y", strtotime((date("Y")-1).'-04-01'));
        // } else {
        //     $data['TCheck'] = date("Ym", strtotime((date("Y")).'-04-01'));
        //     $data['SY'] = date("Y", strtotime((date("Y")).'-04-01'));
        // }

        $YM2 = $data['year_flag'];
        $data['YM'] = $YM;
        $data['YM2'] = $YM2;
        $data['status'] = $request->request->get('status');

        if(date("m", strtotime($YM))<4){
            $data['between1'] = date("Ym", strtotime((date("Y", strtotime($YM))-1).'-04-01'));
            $data['between2'] = date("Ym", strtotime(date("Y", strtotime($YM)).'-03-01'));
            $data['Y'] = date("Y", strtotime($YM))-1;
            $dl = (date("Y", strtotime($YM))-1).'-04-01';
        } else {
            $data['between1'] = date("Ym", strtotime(date("Y", strtotime($YM)).'-04-01'));
            $data['between2'] = date("Ym", strtotime((date("Y", strtotime($YM))+1).'-03-01'));
            $data['Y'] = date("Y", strtotime($YM));
            $dl = (date("Y", strtotime($YM))).'-04-01';
        }

        $project_list = $app['csvdownload.usecase']->getDeveloper($data['between1'],$data['between2'],$data['status'], $YM2);
        $n = date('n');
        if(!empty($project_list)) {
            foreach ($project_list as $key => $value) {
                $data['project_list'][$key] = array(
                    'row1' => 'No.'.$key+1,
                    'row2' => $value['AccountId'],
                    'row3' => $value['Name'],
                    'row4' => $value['PMO'],
                    'row5' => $value['ProjectCord'],
                    'row6' => $data['status'],
                    'row7' => '計画',
                    'row8' => $value['Moneys']['PMoney']['sum'],
                    'row9' => $value['Moneys']['PMoney'][4],
                    'row10' => $value['Moneys']['PMoney'][5],
                    'row11' => $value['Moneys']['PMoney'][6],
                    'row12' => $value['Moneys']['PMoney'][7],
                    'row13' => $value['Moneys']['PMoney'][8],
                    'row14' => $value['Moneys']['PMoney'][9],
                    'row15' => $value['Moneys']['PMoney'][10],
                    'row16' => $value['Moneys']['PMoney'][11],
                    'row17' => $value['Moneys']['PMoney'][12],
                    'row18' => $value['Moneys']['PMoney'][1],
                    'row19' => $value['Moneys']['PMoney'][2],
                    'row20' => $value['Moneys']['PMoney'][3],
                    'row21' => $value['row3']['Money'],
                    'row22' => $value['Moneys']['Money'][4],
                    'row23' => $value['Moneys']['Money'][5],
                    'row24' => $value['Moneys']['Money'][6],
                    'row25' => $value['Moneys']['Money'][7],
                    'row26' => $value['Moneys']['Money'][8],
                    'row27' => $value['Moneys']['Money'][9],
                    'row28' => $value['Moneys']['Money'][10],
                    'row29' => $value['Moneys']['Money'][11],
                    'row30' => $value['Moneys']['Money'][12],
                    'row31' => $value['Moneys']['Money'][1],
                    'row32' => $value['Moneys']['Money'][2],
                    'row33' => $value['Moneys']['Money'][3],
                );
            }
        } else {
            $data['project_list'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
                'row6' => '',
                'row7' => '',
                'row8' => '',
                'row9' => '',
                'row10' => '',
                'row11' => '',
                'row12' => '',
                'row13' => '',
                'row14' => '',
                'row15' => '',
                'row16' => '',
                'row17' => '',
                'row18' => '',
                'row19' => '',
                'row20' => '',
                'row21' => '',
                'row22' => '',
                'row23' => '',
                'row24' => '',
                'row25' => '',
                'row26' => '',
                'row27' => '',
                'row28' => '',
                'row29' => '',
                'row30' => '',
                'row31' => '',
                'row32' => '',
                'row33' => '',
            );
        }

            return $app['twig']->render('csv/csv_developer2.twig',$data);
    }
    )
    ->bind('Developer')
    ->method('GET|POST');    





////開発者リスト(data10)-----------------------------------------------------------------------------
    $controllers->match('/Developer2', function (Application $app) {

        $user_info = $app['session']->get('user_info');
        $request = Request::createFromGlobals();

        if (!($request->request->get('year'))) {
            $request->request->set('year', date('Y'));
        }
        if (!($request->request->get('status'))) {
            $request->request->set('status', '人件費');
        }

        if (!($request->request->get('Status1'))) {
            $request->request->set('Status1', '人件費');
        }

        if (!($request->request->get('FMenu'))) {
            $request->request->set('FMenu', 'Date2');
        }
        $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);

        $YM = date("Ym", strtotime("-$show_month month"));
        var_dump($request->request);
        
        if(date("m")<4){
            $data['TCheck'] = date("Ym", strtotime((date("Y")-1).'-04-01'));
            $data['SY'] = date("Y", strtotime((date("Y")-1).'-04-01'));
        } else {
            $data['TCheck'] = date("Ym", strtotime((date("Y")).'-04-01'));
            $data['SY'] = date("Y", strtotime((date("Y")).'-04-01'));
        }

        $YM2 = date("Y");
        $data['YM'] = $YM;
        $data['status'] = $request->request->get('Status1');

        if(date("m", strtotime($YM))<4){
            $data['between1'] = date("Ym", strtotime((date("Y", strtotime($YM))-1).'-04-01'));
            $data['between2'] = date("Ym", strtotime(date("Y", strtotime($YM)).'-03-01'));
            $data['Y'] = date("Y", strtotime($YM))-1;
            $dl = (date("Y", strtotime($YM))-1).'-04-01';
        } else {
            $data['between1'] = date("Ym", strtotime(date("Y", strtotime($YM)).'-04-01'));
            $data['between2'] = date("Ym", strtotime((date("Y", strtotime($YM))+1).'-03-01'));
            $data['Y'] = date("Y", strtotime($YM));
            $dl = (date("Y", strtotime($YM))).'-04-01';
        }

        $project_list = $app['csvdownload.usecase']->getDeveloper($data['between1'],$data['between2'],$data['status'], $YM2);
        $n = date('n');
        if(!empty($project_list)) {
            foreach ($project_list as $key => $value) {
                $data['project_list'][$key] = array(
                    'row1' => 'No.'.$key+1,
                    'row2' => $value['AccountId'],
                    'row3' => $value['Name'],
                    'row4' => $value['PMO'],
                    'row5' => $value['ProjectCord'],
                    'row6' => $data['status'],
                    'row7' => '計画',
                    'row8' => $value['Moneys']['PMoney']['sum'],
                    'row9' => $value['Moneys']['PMoney'][4],
                    'row10' => $value['Moneys']['PMoney'][5],
                    'row11' => $value['Moneys']['PMoney'][6],
                    'row12' => $value['Moneys']['PMoney'][7],
                    'row13' => $value['Moneys']['PMoney'][8],
                    'row14' => $value['Moneys']['PMoney'][9],
                    'row15' => $value['Moneys']['PMoney'][10],
                    'row16' => $value['Moneys']['PMoney'][11],
                    'row17' => $value['Moneys']['PMoney'][12],
                    'row18' => $value['Moneys']['PMoney'][1],
                    'row19' => $value['Moneys']['PMoney'][2],
                    'row20' => $value['Moneys']['PMoney'][3],
                    'row21' => $value['row3']['Money'],
                    'row22' => $value['Moneys']['Money'][4],
                    'row23' => $value['Moneys']['Money'][5],
                    'row24' => $value['Moneys']['Money'][6],
                    'row25' => $value['Moneys']['Money'][7],
                    'row26' => $value['Moneys']['Money'][8],
                    'row27' => $value['Moneys']['Money'][9],
                    'row28' => $value['Moneys']['Money'][10],
                    'row29' => $value['Moneys']['Money'][11],
                    'row30' => $value['Moneys']['Money'][12],
                    'row31' => $value['Moneys']['Money'][1],
                    'row32' => $value['Moneys']['Money'][2],
                    'row33' => $value['Moneys']['Money'][3],
                );
            }
        } else {
            $data['project_list'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
                'row6' => '',
                'row7' => '',
                'row8' => '',
                'row9' => '',
                'row10' => '',
                'row11' => '',
                'row12' => '',
                'row13' => '',
                'row14' => '',
                'row15' => '',
                'row16' => '',
                'row17' => '',
                'row18' => '',
                'row19' => '',
                'row20' => '',
                'row21' => '',
                'row22' => '',
                'row23' => '',
                'row24' => '',
                'row25' => '',
                'row26' => '',
                'row27' => '',
                'row28' => '',
                'row29' => '',
                'row30' => '',
                'row31' => '',
                'row32' => '',
                'row33' => '',
            );
        }

        if($download_type === 'csv'){

            // header('Content-Type: application/octet-stream');
            // header("Content-Disposition: attachment; filenameKaihatsushaRisuto$YM.csv");
            // $stream = fopen('php://output', 'w');
            // $csv_header = array(
            //     'row1','row2','row3'
            // );
            // $csv_label =  array(
            //     '社員番号','氏名','業種'
            // );
            // foreach($data['dayLabel'] as $value){
            //     array_push($csv_header, $value['num']);
            //     array_push($csv_label, $value['day']);
            // }
            // $numeric_label = array();
            // foreach ($csv_label as $value) {
            //     mb_convert_variables('SJIS-win', 'UTF-8', $value);
            //     $numeric_label[] = $value;
            // }
            // fputcsv($stream, $numeric_label);
            // foreach($data['project_list'] as $key => $assoc_row){
            //     $numeric_row = array();
            //     mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
            //     mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
            //     mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
            //     $numeric_row[] = $assoc_row['row1'];
            //     $numeric_row[] = $assoc_row['row2'];
            //     $numeric_row[] = $assoc_row['row3'];
            //     foreach ($csv_header as $header_name) {
            //         if(isset($assoc_row['days'][$header_name]['day'])){
            //             mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['days'][$header_name]['day']);
            //             $numeric_row[] = $assoc_row['days'][$header_name]['day'];
            //         }
            //     }
            //     fputcsv($stream, $numeric_row);
            // }
            // fclose($stream);
            // exit();

        } 
        else {
            return $app['twig']->render('csv/csv_developer.twig',$data);
        }
    }
    )
    ->bind('Developer2')
    ->method('GET|POST');

////PJコードマスタ(data14)-----------------------------------------------------------------------------
    $controllers->match('/ProjectCodeMaster', function (Application $app) {
        $user_info = $app['session']->get('user_info');
        $request = Request::createFromGlobals();
        $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);

        $project_list = $app['csvdownload.usecase']->getProjectCodeMaster();
        
        $data = array(); 
        if(!empty($project_list)){
            foreach ($project_list as $key => $value) {
                $data['project_list'][$key] = array(
                    'row1' => $value['ProjectCord'],
                    'row2' => $value['Project'],
                    'row3' => $value['Status'],
                    'row4' => $value['BusinessType'],
                    'row5' => $value['Product'],
                    'row6' => $value['PMO'],
                    'row7' => $value['Accounting'],
                    'row8' => $value['Custodian'],
                    'row9' => $value['Budget'],
                    'row10' => $value['PlanDate'],
                    'row11' => $value['CloseDate'],
                );
            }
        } else {
            $data['project_list'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
                'row6' => '',
                'row7' => '',
                'row8' => '',
                'row9' => '',
                'row10' => '',
                'row11' => '',
            );
        }
//        echo "<meta charset='UTF-8'/><pre>";
//print_r($data['project_list']);
//echo "</pre>";
//exit;
        if($download_type === 'csv'){
            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=PJCodeMaster.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'row1','row2','row3','row4','row5','row6','row7','row8','row9','row10','row11'
            );
            $csv_label =  array(
                'PJコード','PJ名','ステータス','業種','プロダクト','担当PMO','PJ責任者','請求先責任者',
                '取得予算','開始日','終了予定日'
            );
            foreach ($csv_label as $value) {
                mb_convert_variables('SJIS-win', 'UTF-8', $value);
                $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);
            foreach($data['project_list'] as $key => $assoc_row){
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                fputcsv($stream, $numeric_row);
            }
            fclose($stream);
            exit();
        } else {
            return $app['twig']->render('csv/csv_project_code.twig',$data);
        }
    })
    ->bind('ProjectCodeMaster')
    ->method('GET|POST');


    $controllers->match('/Employee_ID', function (Request $request, Application $app)
    { 
        if (!($request->request->get('sort'))) {
            $request->request->set('sort', "PMO");
        }
        if (!($request->request->get('selected_Year'))) {
            $request->request->set('selected_Year', date('Y'));
        }
        if (!($request->request->get('selected_Month'))) {
            $request->request->set('selected_Month', date('m'));
        }
        $sort = $request->request->get('sort');
        $showYear = $request->request->get('selected_Year');
        $showMonth = $request->request->get('selected_Month');
        $download = $request->request->get('download');
        $YM = ($showYear.$showMonth);
        $user_hours = $app['csvdownload.usecase']->getAllUserHours($request->request, $YM, $showYear, $showMonth);


        $employee = array(); 
        if(!empty($user_hours)){
            $i =0;
            foreach ($user_hours as $user) {
                $employee['employee'][$i] = array(
                    'row1' => $user->getAccountId(),
                    'row2' => $user->getName(),
                    'row3' => $user->getAuthority(),
                    'row4' => $user->getTime1(),
                    'row5' => $user->getTime2(),
                    'row6' => $user->getTime3(),
                    'row7' => $user->getTime4(),
                    'row8' => $user->getTime5(),
                    'row9' => $user->getTime6(),
                    'row10' => $user->getTime7(),
                    'row11' => $user->getTime8(),
                    'row12' => $user->getTime9(),
                    'row13' => $user->getTime10(),
                    'row14' => $user->getTime11(),
                    'row15' => $user->getTime12(),
                    'row16' => $user->getTime13(),
                    'row17' => $user->getTime14(),
                    'row18' => $user->getTime15(),
                    'row19' => $user->getTime16(),
                    'row20' => $user->getTime17(),
                    'row21' => $user->getTime18(),
                    'row22' => $user->getTime19(),
                    'row23' => $user->getTime20(),
                    'row24' => $user->getTime21(),
                    'row25' => $user->getTime22(),
                    'row26' => $user->getTime23(),
                    'row27' => $user->getTime24(),
                    'row28' => $user->getTime25(),
                    'row29' => $user->getTime26(),
                    'row30' => $user->getTime27(),
                    'row31' => $user->getTime28(),
                    'row32' => $user->getTime29(),
                    'row33' => $user->getTime30(),
                    'row34' => $user->getTime31(),
                    'row35' => $user->getSubTime(),
                    'row36' => $user->getSubMoney()
                );
                $i++;
            }
        } else {
            $employee['employee'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
                'row6' => '',
                'row7' => '',
                'row8' => '',
                'row9' => '',
                'row10' => '',
                'row11' => '',
                'row12' => '',
                'row13' => '',
                'row14' => '',
                'row15' => '',
                'row16' => '',
                'row17' => '',
                'row18' => '',
                'row19' => '',
                'row20' => '',
                'row21' => '',
                'row22' => '',
                'row23' => '',
                'row24' => '',
                'row25' => '',
                'row26' => '',
                'row27' => '',
                'row28' => '',
                'row29' => '',
                'row30' => '',
                'row31' => '',
                'row32' => '',
                'row33' => '',
                'row34' => '',
                'row35' => '',
                'row36' => '',

            );
        }

        if($download === 'download'){

            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=Employee.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'row1','row2','row3'
                ,'row4','row5','row6','row7','row8','row9','row10',
                'row11','row12','row13','row14','row15','row16','row17','row18','row19','row20',
                'row21','row22','row23','row24','row25','row26','row27','row28','row29','row30',
                'row31','row32','row33','row34','row35'
            );
            $csv_label =  array(
                '号社員番号','氏名','ブロック責任者'
                ,'1日','2日','3日','4日','5日','6日','7日','8日','9日','10日',
                '11日','12日','13日','14日','15日','16日','17日','18日','19日','20日',
                '21日','22日','23日','24日','25日','26日','27日','28日','29日','30日','31日',
                '合計'
            );

            foreach ($csv_label as $value) {
                mb_convert_variables('SJIS-win', 'UTF-8', $value);
                $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);
            foreach($employee['employee'] as $key => $assoc_row){
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row14']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row15']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row16']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row17']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row18']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row19']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row20']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row21']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row22']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row23']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row24']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row25']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row26']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row27']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row28']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row29']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row30']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row31']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row32']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row33']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row34']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row35']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                $numeric_row[] = $assoc_row['row12'];
                $numeric_row[] = $assoc_row['row13'];
                $numeric_row[] = $assoc_row['row14'];
                $numeric_row[] = $assoc_row['row15'];
                $numeric_row[] = $assoc_row['row16'];
                $numeric_row[] = $assoc_row['row17'];
                $numeric_row[] = $assoc_row['row18'];
                $numeric_row[] = $assoc_row['row19'];
                $numeric_row[] = $assoc_row['row20'];
                $numeric_row[] = $assoc_row['row21'];
                $numeric_row[] = $assoc_row['row22'];
                $numeric_row[] = $assoc_row['row23'];
                $numeric_row[] = $assoc_row['row24'];
                $numeric_row[] = $assoc_row['row25'];
                $numeric_row[] = $assoc_row['row26'];
                $numeric_row[] = $assoc_row['row27'];
                $numeric_row[] = $assoc_row['row28'];
                $numeric_row[] = $assoc_row['row29'];
                $numeric_row[] = $assoc_row['row30'];
                $numeric_row[] = $assoc_row['row31'];
                $numeric_row[] = $assoc_row['row32'];
                $numeric_row[] = $assoc_row['row33'];
                $numeric_row[] = $assoc_row['row34'];
                $numeric_row[] = $assoc_row['row35'];
                fputcsv($stream, $numeric_row);
            }
            fclose($stream);
            exit();
            
        } else {
            $data = array(
            'showYear' => $showYear , 
            'showMonth' => $showMonth,
            'user_hours' => $user_hours,
            );
            return $app['twig']->render('csv/employee.twig', $data);
        }

         $data = array(
            'showYear' => $showYear , 
            'showMonth' => $showMonth,
            'user_hours' => $user_hours,
            );
       return $app['twig']->render('csv/employee.twig', $data);
    })
    ->bind('Employee_ID');

    $controllers->match('/User_Projects', function (Request $request, Application $app)
    {
        $account_id = $request->query->get('account_id');
        $year = $request->query->get('year');
        $data = $app['csvdownload.usecase']->getUserProjects($account_id, $year);
        return new JsonResponse($data);
    })
    ->bind('User_Projects');
    
return $controllers;

}

}
