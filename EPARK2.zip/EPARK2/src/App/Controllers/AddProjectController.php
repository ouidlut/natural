<?php

namespace App\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Silex\ControllerProviderInterface;
use Silex\Provider\SwiftmailerServiceProvider;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;

/**
 *
 */
class AddProjectController implements ControllerProviderInterface
{
  public function connect(Application $app)
  {
      $controllers = $app['controllers_factory'];
      $user_info = $app['session']->get('user_info');

      $controllers->before(function (Request $request, Application $app) {
            $user_info = $app['session']->get('user_info');
            if (!$user_info) {
                return $app->redirect($app['url_generator']->generate('login'));
            }
              switch ($user_info->getLevel()) {
                case '事務局':
                    break;
                case '管理者':
                    break;
                case '一般':
                    return $app->redirect($app['url_generator']->generate('home'));
                    break;
            }

        });

      $controllers->match('/ProjectApplication', function (Request $request, Application $app)
      {
        $user_info = $app['session']->get('user_info');
        $project_officer =$app['add_project.usecase']->GetName();
        $budget_office = $app['add_project.usecase']->GetBudgetoffice();
        $business_type  = $app['add_project.usecase']->GetBusinessType();
        $user_info = $app['session']->get('user_info');
        if ($request->isMethod('POST')) {
          $mydb = $app['dbs'];
          $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
          $result = $app['add_project.usecase']->saveNewProject($request->request, $user_info, $connection);
          $data = array(
          'project_officer' => $project_officer,
          'budget_office'   => $budget_office,
          'business_type'   => $business_type,
          'result'   => $result,
          'user_info'    => $user_info
          );
//          if ($result) {
//            $pmo_mail = $app['add_project.usecase']->findPMOMailId($result);
            // $body = "Sending a mail";
//            $app['Mailer']->sendMailToPMO($result, $pmo_mail);
//          }
          // return $app['twig']->render('ProjectApplication.twig', $data);
          $No = number_format($result->getNo(),0,'.','');
          // $response = new RedirectResponse($app['url_generator']->generate('EditProject', array('No' => $No)));
          $url = $app['url_generator']->generate('EditProject', array('No' => $No));
          // $response = new RedirectResponse($url);
          // $response->setContent('読み込み中です');
          // return $response;

          // $request->getSession()->getFlashBag()->add('success', "読み込み中です");
          return $app->redirect($app['url_generator']->generate('EditProject', array('No' => $No)));
        }
        $data = array(
          'project_officer' => $project_officer,
          'budget_office'   => $budget_office,
          'business_type'   => $business_type
,          'user_info'    => $user_info
          );
        return $app['twig']->render('ProjectApplication.twig', $data);
      })
      ->bind('ProjectApplication');

      $controllers->match('/ApplicationView/{No}', function (Request $request, Application $app, $No)
      {
        $user_info = $app['session']->get('user_info');
        if ($request->isMethod('POST')) {
          $mydb = $app['dbs'];
          $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
          $project_flag = $app['add_project.usecase']->UpdateProjectStatus($request->request, $connection);
          // if ($project_flag) {
          //   $app['Mailer']->sendMailToApplicantAfterConfirmOrDeny();
          // }
          return $app->redirect($app['url_generator']->generate('ProjectApproval'));
        }
       $request->request->set('No', $No);
       $project_data = $app['add_project.usecase']->getProjectSelectedForConfirmation($request->request);
       $member_data = $app['add_project.usecase']->getGetMemberSeleectedForConfirmation($project_data);
       $data = array(
          'project_data' => $project_data,
          'member_data'   => $member_data,
          'user_info'    => $user_info
          );
      return $app['twig']->render('ApplicationDetails.twig', $data);
      })
      ->bind('ApplicationView')
      ->method('GET|POST')
      ->assert('No', '\d{1,20}');

      $controllers->match('/data.json', function (Request $request, Application $app)
      {
        $business_data = $app['add_project.usecase']->getBusinessDataBySelection($request->query);
        return new JsonResponse($business_data);
      })
      ->bind('DataDownload');

      $controllers->match('/ProjectApproval', function (Request $request, Application $app)
      {
        $user_info = $app['session']->get('user_info');
        $project_confirm_data = $app['add_project.usecase']->FindProjectDatatoConfirm();
        // $project_confirm_data = $app['add_project.usecase']->FindProjectDatatoConfirm();
        $user_info = $app['session']->get('user_info');
               $data = array(
          'project_confirm_data' => $project_confirm_data,
          'user_info' => $user_info,
          );
        return $app['twig']->render('ProjectApproval.twig', $data);
      })
      ->bind('ProjectApproval');

      $controllers->match('/pmodata.json', function (Request $request, Application $app)
      {
        $pmo_data = $app['add_project.usecase']->getPmoDataBySelection($request->query);
        return new JsonResponse($pmo_data);
      })
      ->bind('PmoDataDownload');

      $controllers->match('/name/{name}', function (Request $request, Application $app, $name)
      {
        $request->request->set('Name', $name);
        $user_data = $app['add_project.usecase']->getUserDataBySelection($request->request);
        $data = $app['add_project.usecase']->my_json_encode($user_data);
        // $data = json_encode($user_data , 'JSON_UNESCAPED_UNICODE');
        $response = new Response($data);
        $response->headers->set('Content-Type', 'application/json; charset=UTF-8');
        return $response;
      })
      ->bind('NameDownload')
      ->method('GET');

      $controllers->match('/account.json', function (Request $request, Application $app)
      {
        $account_data = $app['add_project.usecase']->getAccountDataBySelection($request->query);
        // $var = new JsonResponse($account_data);
        // $var = json_encode($account_data);
        return $app->json($account_data);
        return new JsonResponse($account_data);
      })
      ->bind('AccountDataDownload')
      ->method('GET');

      $controllers->match('/monthdata.json', function (Request $request, Application $app)
      {
        $month_data = $app['add_project.usecase']->getMonthDataBySelection($request->query);

        return new JsonResponse($month_data);
      })
      ->bind('MonthDataDownload');

      $controllers->match('/Project_exist', function (Request $request, Application $app)
      {
        $ProjectCord = $request->query->get('ProjectCord');
        $data = $app['add_project.usecase']->SearchIfProjectExists($ProjectCord);
        return $data;
      })
    ->bind('Project_exist');

    $controllers->match('/AddProjectMember', function (Request $request, Application $app)
    {
      $user_data = $app['add_project.usecase']->FindIfUserExists($request->request);
      $mydb = $app['dbs'];
      $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
      // if ($request->request->get('MemberY')) {
      if ($user_data) {
        $member_edit_flag = $app['add_project.usecase'] ->UpdateMemberFromProject($request->request, $connection);
      } else {
      $member_edit_flag = $app['add_project.usecase']->InsertNewMemberForProject($request->request, $connection);
      }
      // var_dump($member_edit_flag);
      // exit();
      // $update_budget = $app['add_project.usecase']->UpdateBudgetForProject($request->request, $connection);
      // return new JsonResponse($member_edit_flag);
      return true;

    })
    ->bind('AddProjectMember');

    $controllers->match('/UpdateBudget', function (Request $request, Application $app)
    {

      $mydb = $app['dbs'];
      $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
      $update_budget = $app['add_project.usecase']->UpdateBudgetForProject($request->request, $connection);
      return new JsonResponse($update_budget);
    })
    ->bind('UpdateBudget');

    $controllers->match('/DeleteProject', function (Request $request, Application $app)
    {
      $No = $request->request->get('Number');
      $request->request->set('No', $No);
      $mydb = $app['dbs'];
      $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
      $delete_flag = $app['add_project.usecase']->DeleteProject($request->request, $connection);
      if ($delete_flag) {
        return $app->redirect($app['url_generator']->generate('projectlist'));
      } else {
        return $app->redirect($app['url_generator']->generate('EditProject', array('No' => $No)));
      }
    })
    ->bind('DeleteProject');

    $controllers->match('/DeleteProjectMember', function (Request $request, Application $app)
    {
      $mydb = $app['dbs'];
      $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
      $member_edit_flag = $app['add_project.usecase']->DeleteMemberFromProject($request->request);
      $update_budget = $app['add_project.usecase']->UpdateBudgetForProject($request->request, $connection);
      return new JsonResponse($member_edit_flag);
    })
    ->bind('DeleteProjectMember');

    $controllers->match('/EditProjectMember', function (Request $request, Application $app)
    {
      $mydb = $app['dbs'];
      $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
      $update_member = $app['add_project.usecase'] ->UpdateMemberFromProject($request->request, $connection);
      return new JsonResponse($request->request->get('No'));
    })
    ->bind('EditProjectMember');



    // project approval controller
    $controllers->match('/ProjectAccept', function (Request $request, Application $app)
      {
        // if ($request->isMethod('POST')) {
          $No = $request->request->get('Number');
          $ApprovaFlg = $request->request->get('Pstatus');
          $request->request->set('No', $No);
          $request->request->set('ApprovaFlg', $ApprovaFlg);
          $mydb = $app['dbs'];
          $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
          $project_flag = $app['add_project.usecase']->UpdateProjectStatus($request->request, $connection);
          // if ($project_flag) {
          //   $app['Mailer']->sendMailToApplicantAfterConfirmOrDeny();
          // }
          return $app->redirect($app['url_generator']->generate('projectlist'));
        // }

        return 0;
      })
      ->bind('ProjectAccept');


      $controllers->match('/CopyProject', function (Request $request, Application $app)
      {
        $user_info = $app['session']->get('user_info');
        $No = $request->request->get('Number');
        $request->request->set('No', $No);
        $mydb = $app['dbs'];
        $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
        $copy_project = $app['add_project.usecase']->CopyAllProjectData($request->request, $user_info, $connection);

        if($copy_project['result'] == 'true'){
            return $app->redirect($app['url_generator']->generate('projectlist'));
        }
        elseif($copy_project['result'] == 'false' ){
            $app['session']->set('message',$copy_project['message']);
            return $app->redirect($app['url_generator']->generate('EditProject', array('No' => $No,'message'=>$copy_project['message'])));
        }        
      })
      ->bind('CopyProject');



      return $controllers;
  }


}
