<?php

namespace App\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Silex\ControllerProviderInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;

/**
 *
 */
class CsvDownloadController implements ControllerProviderInterface
{


    public function connect(Application $app)
    {
        $controllers = $app['controllers_factory'];
        $user_info = $app['session']->get('user_info');

        $controllers->match('/', function (Application $app) {
            $user_info = $app['session']->get('user_info');
//            if ($request->isMethod('POST')) {
//                $workingmonth = $app['monthly_data.usecase']->GetAllUserProjects($user_info);
//                $allprojectlist = $app['all_projects.usecase']->GetAllProjects($request->request);
//                $data = array(
//                      'allprojects'=> $allprojectlist,
//                      'workingmonth' => $workingmonth
//                        );
//                return $app['twig']->render('projectlist.twig', $data);
//            }
        $data['month_value']['0'] = date("Y/m/01", strtotime("0 month"));
        $data['month_value']['1'] = date("Y/m/01", strtotime("-1 month"));
        $data['month_value']['2'] = date("Y/m/01", strtotime("-2 month"));
        $data['month_value']['3'] = date("Y/m/01", strtotime("-3 month"));
        $data['month_value']['4'] = date("Y/m/01", strtotime("-4 month"));
        $data['month_value']['5'] = "<".date("Y/m/01", strtotime("-5 month"));
        $data['month_value']['6'] = "<".date("Y/m/01", strtotime("-6 month"));
        $data['month_value']['7'] = "<".date("Y/m/01", strtotime("-7 month"));
        $data['month_value']['8'] = "<".date("Y/m/01", strtotime("-8 month"));
        $data['month_value']['9'] = "<".date("Y/m/01", strtotime("-9 month"));
        $data['month_value']['10'] = "<".date("Y/m/01", strtotime("-10 month"));
        $data['month_value']['11'] = "<".date("Y/m/01", strtotime("-11 month"));

        $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        $data['month_label']['2'] = date("Y年m月", strtotime("-2 month"));
        $data['month_label']['3'] = date("Y年m月", strtotime("-3 month"));
        $data['month_label']['4'] = date("Y年m月", strtotime("-4 month"));
        $data['month_label']['5'] = date("Y年m月", strtotime("-5 month"));
        $data['month_label']['6'] = date("Y年m月", strtotime("-6 month"));
        $data['month_label']['7'] = date("Y年m月", strtotime("-7 month"));
        $data['month_label']['8'] = date("Y年m月", strtotime("-8 month"));
        $data['month_label']['9'] = date("Y年m月", strtotime("-9 month"));
        $data['month_label']['10'] = date("Y年m月", strtotime("-10 month"));
        $data['month_label']['11'] = date("Y年m月", strtotime("-11 month"));
        $data2 = array(
          'data' => $data,
          'user_info'    => $user_info
          );
        return $app['twig']->render('csv_download.twig', $data2);
        })
        ->bind('csvdownload')
        ->method('GET|POST');

//業種別CF(data1_1)-----------------------------------------------------------------------------
    $controllers->match('/data1_1', function (Application $app) {
        $user_info = $app['session']->get('user_info');

        $request = Request::createFromGlobals();
        $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        $data['status'] = $request->request->get('status','人件費');
        $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
//      $data['M'] = date("m", strtotime($YM));
        $data['M'] = date("m", strtotime("-$show_month month"));

        $type_list = $app['csvdownload.usecase']->GetData1_1($YM);

        if(!empty($type_list)){
            foreach ($type_list as $key => $type) {

                $data['project_list'][$key] = array(
                    'BusinessType' => $type['BusinessType'], //業種1
                    'Accounting' => $type['Accounting'], //業種2
                    'PMO' => $type['PMO'], //業種2
                    'RowCount' => count($type['toYear']),
                    'Price' => array(),
                );
                $data['project_list'][$key]['Price']['px']['toMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['toMonth'] = array();
                if(!empty($type['toMonth'])){
                    foreach ($type['toMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                        }
                            $data['project_list'][$key]['Price']['px']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        }
                        elseif($price_group['PriceGroup'] == '外注費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array();
                if(!empty($type['elapsedMonth'])){
                    foreach ($type['elapsedMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                        elseif($price_group['PriceGroup'] == '外注費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['toYear'] = array();
                $data['project_list'][$key]['Price']['oc']['toYear'] = array();
                if(!empty($type['toYear'])){
                    foreach ($type['toYear'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['toYear'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                        elseif($price_group['PriceGroup'] == '外注費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
            }
        }

        if($download_type === 'csv'){

            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=業種別CF-$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'BusinessType','','row3'
            );
            $csv_label =  array(
                '業種','科目','請求先責任者','担当PMO',$data['M'].'月度予算',$data['M'].'月実績(資産+費用)',$data['M'].'月実績進捗',$data['M'].'月末着地','着地差異','着地進捗',
                '経過月予算','経過月実績','経過月進捗','年間予算','年間実績','年間進捗'

            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $value);
                    $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);



            foreach($data['project_list'] as $key => $value){
                if((!empty($value['Price']['px']['toMonth'])) OR (!empty($value['Price']['px']['elapsedMonth'])) OR (!empty($value['Price']['px']['toYear']))){
                    if(!empty($value['Price']['px'])){
                            $csv_value[$key]['px']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['px']['row2'] = '人件費';
                            $csv_value[$key]['px']['row3'] = $value['Accounting'];
                            $csv_value[$key]['px']['row4'] = $value['PMO'];

                        if(!empty($value['Price']['px']['toMonth'])){
                            $csv_value[$key]['px']['row5'] = $value['Price']['px']['toMonth']['PMoney'];
                            $csv_value[$key]['px']['row6'] = $value['Price']['px']['toMonth']['Money'];
                            $csv_value[$key]['px']['row7'] = $value['Price']['px']['toMonth']['Box1'];
                            $csv_value[$key]['px']['row8'] = $value['Price']['px']['toMonth']['Month'];
                            $csv_value[$key]['px']['row9'] = $value['Price']['px']['toMonth']['Difference'];
                            $csv_value[$key]['px']['row10'] = $value['Price']['px']['toMonth']['Box2'];
                        }
                        else{
                            $csv_value[$key]['px']['row5'] = '';
                            $csv_value[$key]['px']['row6'] = '';
                            $csv_value[$key]['px']['row7'] = '';
                            $csv_value[$key]['px']['row8'] = '';
                            $csv_value[$key]['px']['row9'] = '';
                            $csv_value[$key]['px']['row10'] = '';
                        }
                        if(!empty($value['Price']['px']['elapsedMonth'])){
                            $csv_value[$key]['px']['row11'] = $value['Price']['px']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['elapsedMonth']['Money'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['elapsedMonth']['Box1'];
                        }
                        else{
                            $csv_value[$key]['px']['row11'] = '';
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                        }
                        if(!empty($value['Price']['px']['toYear'])){
                            $csv_value[$key]['px']['row11'] = $value['Price']['px']['toYear']['PMoney'];
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['toYear']['Money'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['toYear']['Box1'];
                        }
                        else{
                            $csv_value[$key]['px']['row11'] = '';
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                        }
                    }
                    if(!empty($value['Price']['oc'])){
                            $csv_value[$key]['oc']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['oc']['row2'] = '外注費';
                            $csv_value[$key]['oc']['row3'] = $value['Accounting'];
                            $csv_value[$key]['oc']['row4'] = $value['PMO'];
                        if(!empty($value['Price']['oc']['toMonth'])){
                            $csv_value[$key]['oc']['row5'] = $value['Price']['oc']['toMonth']['PMoney'];
                            $csv_value[$key]['oc']['row6'] = $value['Price']['oc']['toMonth']['Money'];
                            $csv_value[$key]['oc']['row7'] = $value['Price']['oc']['toMonth']['Box1'];
                            $csv_value[$key]['oc']['row8'] = $value['Price']['oc']['toMonth']['Month'];
                            $csv_value[$key]['oc']['row9'] = $value['Price']['oc']['toMonth']['Difference'];
                            $csv_value[$key]['oc']['row10'] = $value['Price']['oc']['toMonth']['Box2'];
                        }
                        else{
                            $csv_value[$key]['oc']['row5'] = '';
                            $csv_value[$key]['oc']['row6'] = '';
                            $csv_value[$key]['oc']['row7'] = '';
                            $csv_value[$key]['oc']['row8'] = '';
                            $csv_value[$key]['oc']['row9'] = '';
                            $csv_value[$key]['oc']['row10'] = '';
                        }
                        if(!empty($value['Price']['oc']['elapsedMonth'])){
                            $csv_value[$key]['oc']['row11'] = $value['Price']['oc']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['elapsedMonth']['Money'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['elapsedMonth']['Box1'];
                        }
                        else{
                            $csv_value[$key]['oc']['row11'] = '';
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                        }
                        if(!empty($value['Price']['oc']['toYear'])){
                            $csv_value[$key]['oc']['row11'] = $value['Price']['oc']['toYear']['PMoney'];
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['toYear']['Money'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['toYear']['Box1'];
                        }
                        else{
                            $csv_value[$key]['oc']['row11'] = '';
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                        }
                    }
                }
            }
        foreach($csv_value as  $assoc_rows){
            if(!empty($assoc_rows['px'])){
                $assoc_row = $assoc_rows['px'];
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                $numeric_row[] = $assoc_row['row12'];
                $numeric_row[] = $assoc_row['row13'];
                fputcsv($stream, $numeric_row);
            }
            if(!empty($assoc_rows['oc'])){
                $assoc_row = $assoc_rows['oc'];
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                $numeric_row[] = $assoc_row['row12'];
                $numeric_row[] = $assoc_row['row13'];
                fputcsv($stream, $numeric_row);
            }
        }
            return $app['twig']->render('csv_file.twig');
        }
        else{
            return $app['twig']->render('csv_data1_1.twig',$data);
        }
    })
    ->bind('data1_1')
    ->method('GET|POST');

//業種別PL(data1_2)-----------------------------------------------------------------------------
    $controllers->match('/data1_2', function (Application $app) {

        $request = Request::createFromGlobals();
        $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        $data['status'] = $request->request->get('status','人件費');
        $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
//      $data['M'] = date("m", strtotime($YM));
        $data['M'] = date("m", strtotime("-$show_month month"));

        $type_list = $app['csvdownload.usecase']->GetData1_2($YM);

        if(!empty($type_list)){
            foreach ($type_list as $key => $type) {

                $data['project_list'][$key] = array(
                    'BusinessType' => $type['BusinessType'], //業種1
                    'Accounting' => $type['Accounting'], //業種2
                    'PMO' => $type['PMO'], //業種2
                    'RowCount' => count($type['toYear']),
                    'Price' => array(),
                );
                $data['project_list'][$key]['Price']['px']['toMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['toMonth'] = array();
                if(!empty($type['toMonth'])){
                    foreach ($type['toMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                        }
                            $data['project_list'][$key]['Price']['px']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        }
                        elseif($price_group['PriceGroup'] == '外注費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array();
                if(!empty($type['elapsedMonth'])){
                    foreach ($type['elapsedMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                        elseif($price_group['PriceGroup'] == '外注費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['toYear'] = array();
                $data['project_list'][$key]['Price']['oc']['toYear'] = array();
                if(!empty($type['toYear'])){
                    foreach ($type['toYear'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['toYear'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                        elseif($price_group['PriceGroup'] == '外注費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
            }
        }

        if($download_type === 'csv'){

            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=業種別PL-$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'BusinessType','','row3'
            );
            $csv_label =  array(
                '業種','科目','請求先責任者','担当PMO',$data['M'].'月度予算',$data['M'].'月実績(費用)',$data['M'].'月実績進捗',$data['M'].'月末着地','着地差異','着地進捗',
                '経過月予算','経過月実績','経過月進捗','年間予算','年間実績','年間進捗'

            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $value);
                    $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);



            foreach($data['project_list'] as $key => $value){
                if((!empty($value['Price']['px']['toMonth'])) OR (!empty($value['Price']['px']['elapsedMonth'])) OR (!empty($value['Price']['px']['toYear']))){
                    if(!empty($value['Price']['px'])){
                            $csv_value[$key]['px']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['px']['row2'] = '人件費';
                            $csv_value[$key]['px']['row3'] = $value['Accounting'];
                            $csv_value[$key]['px']['row4'] = $value['PMO'];

                        if(!empty($value['Price']['px']['toMonth'])){
                            $csv_value[$key]['px']['row5'] = $value['Price']['px']['toMonth']['PMoney'];
                            $csv_value[$key]['px']['row6'] = $value['Price']['px']['toMonth']['Money'];
                            $csv_value[$key]['px']['row7'] = $value['Price']['px']['toMonth']['Box1'];
                            $csv_value[$key]['px']['row8'] = $value['Price']['px']['toMonth']['Month'];
                            $csv_value[$key]['px']['row9'] = $value['Price']['px']['toMonth']['Difference'];
                            $csv_value[$key]['px']['row10'] = $value['Price']['px']['toMonth']['Box2'];
                        }
                        else{
                            $csv_value[$key]['px']['row5'] = '';
                            $csv_value[$key]['px']['row6'] = '';
                            $csv_value[$key]['px']['row7'] = '';
                            $csv_value[$key]['px']['row8'] = '';
                            $csv_value[$key]['px']['row9'] = '';
                            $csv_value[$key]['px']['row10'] = '';
                        }
                        if(!empty($value['Price']['px']['elapsedMonth'])){
                            $csv_value[$key]['px']['row11'] = $value['Price']['px']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['elapsedMonth']['Money'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['elapsedMonth']['Box1'];
                        }
                        else{
                            $csv_value[$key]['px']['row11'] = '';
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                        }
                        if(!empty($value['Price']['px']['toYear'])){
                            $csv_value[$key]['px']['row11'] = $value['Price']['px']['toYear']['PMoney'];
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['toYear']['Money'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['toYear']['Box1'];
                        }
                        else{
                            $csv_value[$key]['px']['row11'] = '';
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                        }
                    }
                    if(!empty($value['Price']['oc'])){
                            $csv_value[$key]['oc']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['oc']['row2'] = '外注費';
                            $csv_value[$key]['oc']['row3'] = $value['Accounting'];
                            $csv_value[$key]['oc']['row4'] = $value['PMO'];
                        if(!empty($value['Price']['oc']['toMonth'])){
                            $csv_value[$key]['oc']['row5'] = $value['Price']['oc']['toMonth']['PMoney'];
                            $csv_value[$key]['oc']['row6'] = $value['Price']['oc']['toMonth']['Money'];
                            $csv_value[$key]['oc']['row7'] = $value['Price']['oc']['toMonth']['Box1'];
                            $csv_value[$key]['oc']['row8'] = $value['Price']['oc']['toMonth']['Month'];
                            $csv_value[$key]['oc']['row9'] = $value['Price']['oc']['toMonth']['Difference'];
                            $csv_value[$key]['oc']['row10'] = $value['Price']['oc']['toMonth']['Box2'];
                        }
                        else{
                            $csv_value[$key]['oc']['row5'] = '';
                            $csv_value[$key]['oc']['row6'] = '';
                            $csv_value[$key]['oc']['row7'] = '';
                            $csv_value[$key]['oc']['row8'] = '';
                            $csv_value[$key]['oc']['row9'] = '';
                            $csv_value[$key]['oc']['row10'] = '';
                        }
                        if(!empty($value['Price']['oc']['elapsedMonth'])){
                            $csv_value[$key]['oc']['row11'] = $value['Price']['oc']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['elapsedMonth']['Money'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['elapsedMonth']['Box1'];
                        }
                        else{
                            $csv_value[$key]['oc']['row11'] = '';
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                        }
                        if(!empty($value['Price']['oc']['toYear'])){
                            $csv_value[$key]['oc']['row11'] = $value['Price']['oc']['toYear']['PMoney'];
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['toYear']['Money'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['toYear']['Box1'];
                        }
                        else{
                            $csv_value[$key]['oc']['row11'] = '';
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                        }
                    }
                }
            }
        foreach($csv_value as  $assoc_rows){
            if(!empty($assoc_rows['px'])){
                $assoc_row = $assoc_rows['px'];
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                $numeric_row[] = $assoc_row['row12'];
                $numeric_row[] = $assoc_row['row13'];
                fputcsv($stream, $numeric_row);
            }
            if(!empty($assoc_rows['oc'])){
                $assoc_row = $assoc_rows['oc'];
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                $numeric_row[] = $assoc_row['row12'];
                $numeric_row[] = $assoc_row['row13'];
                fputcsv($stream, $numeric_row);
            }
        }
            return $app['twig']->render('csv_file.twig');
        }
        else{
            return $app['twig']->render('csv_data1_2.twig',$data);
        }
    })
    ->bind('data1_2')
    ->method('GET|POST');


    //ALLPJ(data2_1)-----------------------------------------------------------------------------
    $controllers->match('/data2_1', function (Application $app) {

        $request = Request::createFromGlobals();
        $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        $data['status'] = $request->request->get('status','人件費');
        $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
        $data['M'] = date("m", strtotime("-$show_month month"));
        $project_list = $app['csvdownload.usecase']->GetData2_1($YM);
        if(!empty($project_list)){
            foreach ($project_list as $key => $project) {

                if(!empty($project['Budget'])){
                    $box1 = round( ($project['elapsedMonth_CF']['Money'] / $project['Budget']) * 100 ).'%'; //進捗
                    $box2 = round((($project['toMonth_CF']['Money'] / 7 * 19) / ($project['Budget'] / 12)) *100).'%'; //進捗
                }
                else{
                    $box1 = '-';
                    $box2 = '-';
                }
                if(!empty($project['toYear_CF']['Money'])){
                    $box3 = round( ($project['toYear_AS']['Money'] / $project['toYear_CF']['Money']) * 100 ).'%'; //資産率
                    $box4 = round( ($project['toYear_PL']['Money'] / $project['toYear_CF']['Money']) * 100 ).'%'; //費用率
                    $box5 = round(($project['toYear_AS']['Money'] / $project['toYear_CF']['Money'])*100) +
                            round(($project['toYear_PL']['Money'] / $project['toYear_CF']['Money'])*100) .'%';
                }
                else{
                    $box3 = '-';
                    $box4 = '-';
                    $box5 = '-';
                }

                $data['project_list'][$key] = array(
                    'row1' => $project['BusinessType'], //業種1
                    // 'row1' => 'hoge', //業種1
                    'row2' => $project['Product'], //業種2
                    'row3' => $project['PMO'], //PMO
                    'row4' => $project['ProjectCord'], //PJコード
                    'row5' => $project['Project'], //PJ名
                    'row6' => $project['toYear_AS']['Money'], //資産金額
                    'row7' => $project['toYear_PL']['Money'], //費用金額
                    'row8' => $project['toYear_CF']['Money'], //合計
                    'row9' => $project['Budget'], //取得予算合計
                    'row10' => $project['elapsedMonth_CF']['Money'], //累計（当月着地含む）
                    'row11' => $project['Budget'] - $project['elapsedMonth_CF']['Money'], //着地差異
                    'row12' => $box1, //進捗
                    'row13' => floor($project['Budget'] / 12), //月度予算計画
                    'row14' => $project['toMonth_CF']['Money'], //月実績
                    'row15' => floor($project['toMonth_CF']['Money'] / 7) * 19, //月末着地
                    'row16' => (floor($project['Budget'] / 12)) - (floor($project['toMonth_CF']['Money'] / 7) * 19), //着地差異
                    'row17' => $box2, //進捗
                    'row18' => $box3,
                    'row19' => $box4,
                    'row20' => $box5
                );

            }
        }
        else{
            $data['project_list'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
                'row6' => '',
                'row7' => '',
                'row8' => '',
                'row9' => '',
                'row10' => '',
                'row11' => '',
                'row12' => '',
                'row13' => '',
                'row14' => '',
                'row15' => '',
                'row16' => '',
                'row17' => '',
                'row18' => '',
                'row19' => '',
                'row20' => ''
            );
        }
        if($download_type === 'csv'){
            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=ALLPJ-$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'row1','row2','row3'
            );
            $csv_label =  array(
                '業種1','業種2','担当PMO','PJコード','PJ名','資産金額','費用金額','合計','取得予算合計','累計(当月着地含)','着地差異','進捗',
                '月度予算計画','月実績','月末着地','着地差異','進捗','資産率','費用率','合計'

            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $value);
                    $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);

            foreach($data['project_list'] as $key => $assoc_row){
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row14']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row15']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row16']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row17']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row18']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row19']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row20']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                $numeric_row[] = $assoc_row['row12'];
                $numeric_row[] = $assoc_row['row13'];
                $numeric_row[] = $assoc_row['row14'];
                $numeric_row[] = $assoc_row['row15'];
                $numeric_row[] = $assoc_row['row16'];
                $numeric_row[] = $assoc_row['row17'];
                $numeric_row[] = $assoc_row['row18'];
                $numeric_row[] = $assoc_row['row19'];
                $numeric_row[] = $assoc_row['row20'];
                foreach ($csv_header as $header_name) {
                    if(isset($assoc_row['days'][$header_name]['day'])){
                        mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['days'][$header_name]['day']);
                        $numeric_row[] = $assoc_row['days'][$header_name]['day'];
                    }
                }
                fputcsv($stream, $numeric_row);
            }
            return $app['twig']->render('csv_file.twig');
        }
        else{
            return $app['twig']->render('csv_data2_1.twig',$data);
        }
    })
    ->bind('data2_1')
    ->method('GET|POST');

//プロダクト別CF(data3_1)-----------------------------------------------------------------------------
    $controllers->match('/data3_1', function (Application $app) {
        $user_info = $app['session']->get('user_info');

        $request = Request::createFromGlobals();
        $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        $data['status'] = $request->request->get('status','人件費');
        $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
//      $data['M'] = date("m", strtotime($YM));
        $data['M'] = date("m", strtotime("-$show_month month"));

        $type_list = $app['csvdownload.usecase']->GetData3_1($YM);

        if(!empty($type_list)){
            foreach ($type_list as $key => $type) {

                $data['project_list'][$key] = array(
                    'BusinessType' => $type['BusinessType'], //業種1
                    'Product' => $type['Product'], //業種1
                    'Accounting' => $type['Accounting'], //業種2
                    'PMO' => $type['PMO'], //業種2
                    'RowCount' => count($type['toYear']),
                    'Price' => array(),
                );
                $data['project_list'][$key]['Price']['px']['toMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['toMonth'] = array();
                if(!empty($type['toMonth'])){
                    foreach ($type['toMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                        }
                            $data['project_list'][$key]['Price']['px']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        }
                        elseif($price_group['PriceGroup'] == '外注費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array();
                if(!empty($type['elapsedMonth'])){
                    foreach ($type['elapsedMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                        elseif($price_group['PriceGroup'] == '外注費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['toYear'] = array();
                $data['project_list'][$key]['Price']['oc']['toYear'] = array();
                if(!empty($type['toYear'])){
                    foreach ($type['toYear'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['toYear'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                        elseif($price_group['PriceGroup'] == '外注費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
            }
        }

        if($download_type === 'csv'){

            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=プロダクト別CF-$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'BusinessType','','row3'
            );
            $csv_label =  array(
                '業種','プロダクト','科目','請求先責任者','担当PMO',$data['M'].'月度予算',$data['M'].'月実績(資産+費用)',$data['M'].'月実績進捗',$data['M'].'月末着地','着地差異','着地進捗',
                '経過月予算','経過月実績','経過月進捗','年間予算','年間実績','年間進捗'

            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $value);
                    $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);



            foreach($data['project_list'] as $key => $value){
                if((!empty($value['Price']['px']['toMonth'])) OR (!empty($value['Price']['px']['elapsedMonth'])) OR (!empty($value['Price']['px']['toYear']))){
                    if(!empty($value['Price']['px'])){
                            $csv_value[$key]['px']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['px']['row2'] = $value['Product'];
                            $csv_value[$key]['px']['row3'] = '人件費';
                            $csv_value[$key]['px']['row4'] = $value['Accounting'];
                            $csv_value[$key]['px']['row5'] = $value['PMO'];

                        if(!empty($value['Price']['px']['toMonth'])){
                            $csv_value[$key]['px']['row6'] = $value['Price']['px']['toMonth']['PMoney'];
                            $csv_value[$key]['px']['row7'] = $value['Price']['px']['toMonth']['Money'];
                            $csv_value[$key]['px']['row8'] = $value['Price']['px']['toMonth']['Box1'];
                            $csv_value[$key]['px']['row9'] = $value['Price']['px']['toMonth']['Month'];
                            $csv_value[$key]['px']['row10'] = $value['Price']['px']['toMonth']['Difference'];
                            $csv_value[$key]['px']['row11'] = $value['Price']['px']['toMonth']['Box2'];
                        }
                        else{
                            $csv_value[$key]['px']['row6'] = '';
                            $csv_value[$key]['px']['row7'] = '';
                            $csv_value[$key]['px']['row8'] = '';
                            $csv_value[$key]['px']['row9'] = '';
                            $csv_value[$key]['px']['row10'] = '';
                            $csv_value[$key]['px']['row11'] = '';
                        }
                        if(!empty($value['Price']['px']['elapsedMonth'])){
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['elapsedMonth']['Money'];
                            $csv_value[$key]['px']['row14'] = $value['Price']['px']['elapsedMonth']['Box1'];
                        }
                        else{
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                            $csv_value[$key]['px']['row14'] = '';
                        }
                        if(!empty($value['Price']['px']['toYear'])){
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['toYear']['PMoney'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['toYear']['Money'];
                            $csv_value[$key]['px']['row14'] = $value['Price']['px']['toYear']['Box1'];
                        }
                        else{
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                            $csv_value[$key]['px']['row14'] = '';
                        }
                    }
                    if(!empty($value['Price']['oc'])){
                            $csv_value[$key]['oc']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['oc']['row2'] = $value['Product'];
                            $csv_value[$key]['oc']['row3'] = '外注費';
                            $csv_value[$key]['oc']['row4'] = $value['Accounting'];
                            $csv_value[$key]['oc']['row5'] = $value['PMO'];
                        if(!empty($value['Price']['oc']['toMonth'])){
                            $csv_value[$key]['oc']['row6'] = $value['Price']['oc']['toMonth']['PMoney'];
                            $csv_value[$key]['oc']['row7'] = $value['Price']['oc']['toMonth']['Money'];
                            $csv_value[$key]['oc']['row8'] = $value['Price']['oc']['toMonth']['Box1'];
                            $csv_value[$key]['oc']['row9'] = $value['Price']['oc']['toMonth']['Month'];
                            $csv_value[$key]['oc']['row10'] = $value['Price']['oc']['toMonth']['Difference'];
                            $csv_value[$key]['oc']['row11'] = $value['Price']['oc']['toMonth']['Box2'];
                        }
                        else{
                            $csv_value[$key]['oc']['row6'] = '';
                            $csv_value[$key]['oc']['row7'] = '';
                            $csv_value[$key]['oc']['row8'] = '';
                            $csv_value[$key]['oc']['row9'] = '';
                            $csv_value[$key]['oc']['row10'] = '';
                            $csv_value[$key]['oc']['row11'] = '';
                        }
                        if(!empty($value['Price']['oc']['elapsedMonth'])){
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['elapsedMonth']['Money'];
                            $csv_value[$key]['oc']['row14'] = $value['Price']['oc']['elapsedMonth']['Box1'];
                        }
                        else{
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                            $csv_value[$key]['oc']['row14'] = '';
                        }
                        if(!empty($value['Price']['oc']['toYear'])){
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['toYear']['PMoney'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['toYear']['Money'];
                            $csv_value[$key]['oc']['row14'] = $value['Price']['oc']['toYear']['Box1'];
                        }
                        else{
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                            $csv_value[$key]['oc']['row14'] = '';
                        }
                    }
                }
            }
        foreach($csv_value as  $assoc_rows){
            if(!empty($assoc_rows['px'])){
                $assoc_row = $assoc_rows['px'];
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row14']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                $numeric_row[] = $assoc_row['row12'];
                $numeric_row[] = $assoc_row['row13'];
                $numeric_row[] = $assoc_row['row14'];
                fputcsv($stream, $numeric_row);
            }
            if(!empty($assoc_rows['oc'])){
                $assoc_row = $assoc_rows['oc'];
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row14']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                $numeric_row[] = $assoc_row['row12'];
                $numeric_row[] = $assoc_row['row13'];
                $numeric_row[] = $assoc_row['row14'];
                fputcsv($stream, $numeric_row);
            }
        }
            return $app['twig']->render('csv_file.twig');
        }
        else{
            return $app['twig']->render('csv_data3_1.twig',$data);
        }
    })
    ->bind('data3_1')
    ->method('GET|POST');

//プロダクト別PL(data3_2)-----------------------------------------------------------------------------
    $controllers->match('/data3_2', function (Application $app) {

        $request = Request::createFromGlobals();
        $show_month = $request->request->get('showMonth',0);
        $download_type = $request->request->get('download',0);
        $data['status'] = $request->request->get('status','人件費');
        $data['month_value']['0'] = date("Ym", strtotime("0 month"));
        $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
        $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
        $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
        $YM = date("Ym", strtotime("-$show_month month"));
        $data['YM'] = $YM;
//      $data['M'] = date("m", strtotime($YM));
        $data['M'] = date("m", strtotime("-$show_month month"));

        $type_list = $app['csvdownload.usecase']->GetData3_2($YM);

        if(!empty($type_list)){
            foreach ($type_list as $key => $type) {

                $data['project_list'][$key] = array(
                    'BusinessType' => $type['BusinessType'], //業種1
                    'Product' => $type['Product'], //業種1
                    'Accounting' => $type['Accounting'], //業種2
                    'PMO' => $type['PMO'], //業種2
                    'RowCount' => count($type['toYear']),
                    'Price' => array(),
                );
                $data['project_list'][$key]['Price']['px']['toMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['toMonth'] = array();
                if(!empty($type['toMonth'])){
                    foreach ($type['toMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                        }
                            $data['project_list'][$key]['Price']['px']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        }
                        elseif($price_group['PriceGroup'] == '外注費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                                $box2 = round((($price_group['Money'] / 7 * 19) / ($PMoney / 12)) *100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['toMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                                'Month' => floor($price_group['Money'] / 7 * 19), //月末着地
                                'Difference' => $PMoney - floor($price_group['Money'] / 7 * 19), //着地差異
                                'Box2' => $box2 //進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array();
                $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array();
                if(!empty($type['elapsedMonth'])){
                    foreach ($type['elapsedMonth'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                        elseif($price_group['PriceGroup'] == '外注費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                                $box2 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
                $data['project_list'][$key]['Price']['px']['toYear'] = array();
                $data['project_list'][$key]['Price']['oc']['toYear'] = array();
                if(!empty($type['toYear'])){
                    foreach ($type['toYear'] as $key2 => $price_group) {
                        if($price_group['PriceGroup'] == '人件費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['px']['toYear'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                        elseif($price_group['PriceGroup'] == '外注費'){
                            $PMoney = 0;
                            if(!empty($PMoney)){
                                $box1 = round(($price_group['Money'] / $PMoney) * 100).'%'; //進捗
                            }
                            else{
                                $box1 = '-';
                            }
                            $data['project_list'][$key]['Price']['oc']['elapsedMonth'] = array(
                                'PriceGroup' => $price_group['PriceGroup'], //科目
                                'PMoney' => $PMoney, //予算
                                'Money' => $price_group['Money'], //実績
                                'Box1' => $box1, //実績進捗
                            );
                        }
                    }
                }
            }
        }

        if($download_type === 'csv'){

            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=プロダクト別PL-$YM.csv");
            $stream = fopen('php://output', 'w');
            $csv_header = array(
                'BusinessType','','row3'
            );
            $csv_label =  array(
                '業種', 'プロダクト','科目','請求先責任者','担当PMO',$data['M'].'月度予算',$data['M'].'月実績(費用)',$data['M'].'月実績進捗',$data['M'].'月末着地','着地差異','着地進捗',
                '経過月予算','経過月実績','経過月進捗','年間予算','年間実績','年間進捗'

            );
            $numeric_label = array();
            foreach ($csv_label as $value) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $value);
                    $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);



            foreach($data['project_list'] as $key => $value){
                if((!empty($value['Price']['px']['toMonth'])) OR (!empty($value['Price']['px']['elapsedMonth'])) OR (!empty($value['Price']['px']['toYear']))){
                    if(!empty($value['Price']['px'])){
                            $csv_value[$key]['px']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['px']['row2'] = $value['Product'];
                            $csv_value[$key]['px']['row3'] = '人件費';
                            $csv_value[$key]['px']['row4'] = $value['Accounting'];
                            $csv_value[$key]['px']['row5'] = $value['PMO'];

                        if(!empty($value['Price']['px']['toMonth'])){
                            $csv_value[$key]['px']['row6'] = $value['Price']['px']['toMonth']['PMoney'];
                            $csv_value[$key]['px']['row7'] = $value['Price']['px']['toMonth']['Money'];
                            $csv_value[$key]['px']['row8'] = $value['Price']['px']['toMonth']['Box1'];
                            $csv_value[$key]['px']['row9'] = $value['Price']['px']['toMonth']['Month'];
                            $csv_value[$key]['px']['row10'] = $value['Price']['px']['toMonth']['Difference'];
                            $csv_value[$key]['px']['row11'] = $value['Price']['px']['toMonth']['Box2'];
                        }
                        else{
                            $csv_value[$key]['px']['row6'] = '';
                            $csv_value[$key]['px']['row7'] = '';
                            $csv_value[$key]['px']['row8'] = '';
                            $csv_value[$key]['px']['row9'] = '';
                            $csv_value[$key]['px']['row10'] = '';
                            $csv_value[$key]['px']['row11'] = '';
                        }
                        if(!empty($value['Price']['px']['elapsedMonth'])){
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['elapsedMonth']['Money'];
                            $csv_value[$key]['px']['row14'] = $value['Price']['px']['elapsedMonth']['Box1'];
                        }
                        else{
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                            $csv_value[$key]['px']['row14'] = '';
                        }
                        if(!empty($value['Price']['px']['toYear'])){
                            $csv_value[$key]['px']['row12'] = $value['Price']['px']['toYear']['PMoney'];
                            $csv_value[$key]['px']['row13'] = $value['Price']['px']['toYear']['Money'];
                            $csv_value[$key]['px']['row14'] = $value['Price']['px']['toYear']['Box1'];
                        }
                        else{
                            $csv_value[$key]['px']['row12'] = '';
                            $csv_value[$key]['px']['row13'] = '';
                            $csv_value[$key]['px']['row14'] = '';
                        }
                    }
                    if(!empty($value['Price']['oc'])){
                            $csv_value[$key]['oc']['row1'] = $value['BusinessType'];
                            $csv_value[$key]['oc']['row2'] = $value['Product'];
                            $csv_value[$key]['oc']['row3'] = '外注費';
                            $csv_value[$key]['oc']['row4'] = $value['Accounting'];
                            $csv_value[$key]['oc']['row5'] = $value['PMO'];
                        if(!empty($value['Price']['oc']['toMonth'])){
                            $csv_value[$key]['oc']['row6'] = $value['Price']['oc']['toMonth']['PMoney'];
                            $csv_value[$key]['oc']['row7'] = $value['Price']['oc']['toMonth']['Money'];
                            $csv_value[$key]['oc']['row8'] = $value['Price']['oc']['toMonth']['Box1'];
                            $csv_value[$key]['oc']['row9'] = $value['Price']['oc']['toMonth']['Month'];
                            $csv_value[$key]['oc']['row10'] = $value['Price']['oc']['toMonth']['Difference'];
                            $csv_value[$key]['oc']['row11'] = $value['Price']['oc']['toMonth']['Box2'];
                        }
                        else{
                            $csv_value[$key]['oc']['row6'] = '';
                            $csv_value[$key]['oc']['row7'] = '';
                            $csv_value[$key]['oc']['row8'] = '';
                            $csv_value[$key]['oc']['row9'] = '';
                            $csv_value[$key]['oc']['row10'] = '';
                            $csv_value[$key]['oc']['row11'] = '';
                        }
                        if(!empty($value['Price']['oc']['elapsedMonth'])){
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['elapsedMonth']['PMoney'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['elapsedMonth']['Money'];
                            $csv_value[$key]['oc']['row14'] = $value['Price']['oc']['elapsedMonth']['Box1'];
                        }
                        else{
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                            $csv_value[$key]['oc']['row14'] = '';
                        }
                        if(!empty($value['Price']['oc']['toYear'])){
                            $csv_value[$key]['oc']['row12'] = $value['Price']['oc']['toYear']['PMoney'];
                            $csv_value[$key]['oc']['row13'] = $value['Price']['oc']['toYear']['Money'];
                            $csv_value[$key]['oc']['row14'] = $value['Price']['oc']['toYear']['Box1'];
                        }
                        else{
                            $csv_value[$key]['oc']['row12'] = '';
                            $csv_value[$key]['oc']['row13'] = '';
                            $csv_value[$key]['oc']['row14'] = '';
                        }
                    }
                }
            }
        foreach($csv_value as  $assoc_rows){
            if(!empty($assoc_rows['px'])){
                $assoc_row = $assoc_rows['px'];
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row14']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                $numeric_row[] = $assoc_row['row12'];
                $numeric_row[] = $assoc_row['row13'];
                $numeric_row[] = $assoc_row['row14'];
                fputcsv($stream, $numeric_row);
            }
            if(!empty($assoc_rows['oc'])){
                $assoc_row = $assoc_rows['oc'];
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row14']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                $numeric_row[] = $assoc_row['row12'];
                $numeric_row[] = $assoc_row['row13'];
                $numeric_row[] = $assoc_row['row14'];
                fputcsv($stream, $numeric_row);
            }
        }
            return $app['twig']->render('csv_file.twig');
        }
        else{
            return $app['twig']->render('csv_data3_2.twig',$data);
        }
    })
    ->bind('data3_2')
    ->method('GET|POST');


//Project一覧(project_data)-----------------------------------------------------------------------------
    $controllers->match('/project_data', function (Application $app) {

        $request = Request::createFromGlobals();
        $status = $request->request->get('status','開発中');
        $year = $request->request->get('year',0);
        $project_list = $app['csvdownload.usecase']->GetProjectData($status,$year);
        if(empty($year)){
                $year =  date('Y');
        }
        $n = date('n');
        if(!empty($project_list)){
            foreach ($project_list as $key => $value) {
                $data['project_list'][$key] = array(
                    'row1' => $value['ProjectCord'],
                    'row2' => $value['Project'],
                    'row3' => $value['Status'],
                    'row4' => $value['BusinessType'],
                    'row5' => $value['Product'],
                    'row6' => $value['PMO'],
                    'row7' => $value['Accounting'],
                    'row8' => $value['Custodian'],
                    'row9' => $value['Budget'],
                    'row10' => $value['CloseDate'],
                    'row11' => $value['BusinessType'],
                    'row12' => '計画',
                    'row13' => $value['row3']['PMoney'],
                    'row14' => $value['Moneys']['PMoney']['4'],
                    'row15' => $value['Moneys']['PMoney']['5'],
                    'row16' => $value['Moneys']['PMoney']['6'],
                    'row17' => $value['Moneys']['PMoney']['7'],
                    'row18' => $value['Moneys']['PMoney']['8'],
                    'row19' => $value['Moneys']['PMoney']['9'],
                    'row20' => $value['Moneys']['PMoney']['10'],
                    'row21' => $value['Moneys']['PMoney']['11'],
                    'row22' => $value['Moneys']['PMoney']['12'],
                    'row23' => $value['Moneys']['PMoney']['1'],
                    'row24' => $value['Moneys']['PMoney']['2'],
                    'row25' => $value['Moneys']['PMoney']['3'],
                    'row26' => '計画',
                    'row27' => $value['row3']['Money'],
                    'row28' => $value['Moneys']['Money']['4'],
                    'row29' => $value['Moneys']['Money']['5'],
                    'row30' => $value['Moneys']['Money']['6'],
                    'row31' => $value['Moneys']['Money']['7'],
                    'row32' => $value['Moneys']['Money']['8'],
                    'row33' => $value['Moneys']['Money']['9'],
                    'row34' => $value['Moneys']['Money']['10'],
                    'row35' => $value['Moneys']['Money']['11'],
                    'row36' => $value['Moneys']['Money']['12'],
                    'row37' => $value['Moneys']['Money']['1'],
                    'row38' => $value['Moneys']['Money']['2'],
                    'row39' => $value['Moneys']['Money']['3'],

                );
            }
        }
        else{
            $data['project_list'][] = array(
                'row1' => '',
                'row2' => '',
                'row3' => '',
                'row4' => '',
                'row5' => '',
                'row6' => '',
                'row7' => '',
                'row8' => '',
                'row9' => '',
                'row10' => '',
                'row11' => '',
                'row12' => '',
                'row13' => '',
                'row14' => '',
                'row15' => '',
                'row16' => '',
                'row17' => '',
                'row18' => '',
                'row19' => '',
                'row20' => '',
                'row21' => '',
                'row22' => '',
                'row23' => '',
                'row24' => '',
                'row25' => '',
                'row26' => '',
                'row27' => '',
                'row28' => '',
                'row29' => '',
                'row30' => '',
                'row31' => '',
                'row32' => '',
                'row33' => '',
                'row34' => '',
                'row35' => '',
                'row36' => '',
                'row37' => '',
                'row38' => '',
                'row39' => '',
            );
        }

            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename=PJ一覧.csv");
            $stream = fopen('php://output', 'w');
            $csv_label =  array(
                'PJコード','PJ名','ステータス','業種','プロダクト','担当PMO','PJ責任者','請求先責任者','取得予算','終了予定日','業種','項目','合計'
                ,$year.'/04',$year.'/05',$year.'/06',$year.'/07',$year.'/08',$year.'/09',$year.'/10'
                ,$year.'/11',$year.'/12',($year+1).'/01',($year+1).'/02',($year+1).'/03',
                '項目','合計',$year.'/04',$year.'/05',$year.'/06',$year.'/07',$year.'/08'
                ,$year.'/09',$year.'/10',$year.'/11',$year.'/12',($year+1).'/01',($year+1).'/02',($year+3).'/03'
            );
            foreach ($csv_label as $value) {
                    mb_convert_variables('SJIS-win', 'UTF-8', $value);
                    $numeric_label[] = $value;
            }
            fputcsv($stream, $numeric_label);

            foreach($data['project_list'] as $key => $assoc_row){
                $numeric_row = array();
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row12']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row13']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row14']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row15']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row16']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row17']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row18']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row19']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row20']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row21']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row22']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row23']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row24']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row25']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row26']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row27']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row28']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row29']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row30']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row31']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row32']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row33']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row34']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row35']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row36']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row37']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row38']);
                mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row39']);
                $numeric_row[] = $assoc_row['row1'];
                $numeric_row[] = $assoc_row['row2'];
                $numeric_row[] = $assoc_row['row3'];
                $numeric_row[] = $assoc_row['row4'];
                $numeric_row[] = $assoc_row['row5'];
                $numeric_row[] = $assoc_row['row6'];
                $numeric_row[] = $assoc_row['row7'];
                $numeric_row[] = $assoc_row['row8'];
                $numeric_row[] = $assoc_row['row9'];
                $numeric_row[] = $assoc_row['row10'];
                $numeric_row[] = $assoc_row['row11'];
                $numeric_row[] = $assoc_row['row12'];
                $numeric_row[] = $assoc_row['row13'];
                $numeric_row[] = $assoc_row['row14'];
                $numeric_row[] = $assoc_row['row15'];
                $numeric_row[] = $assoc_row['row16'];
                $numeric_row[] = $assoc_row['row17'];
                $numeric_row[] = $assoc_row['row18'];
                $numeric_row[] = $assoc_row['row19'];
                $numeric_row[] = $assoc_row['row20'];
                $numeric_row[] = $assoc_row['row21'];
                $numeric_row[] = $assoc_row['row22'];
                $numeric_row[] = $assoc_row['row23'];
                $numeric_row[] = $assoc_row['row24'];
                $numeric_row[] = $assoc_row['row25'];
                $numeric_row[] = $assoc_row['row26'];
                $numeric_row[] = $assoc_row['row27'];
                $numeric_row[] = $assoc_row['row28'];
                $numeric_row[] = $assoc_row['row29'];
                $numeric_row[] = $assoc_row['row30'];
                $numeric_row[] = $assoc_row['row31'];
                $numeric_row[] = $assoc_row['row32'];
                $numeric_row[] = $assoc_row['row33'];
                $numeric_row[] = $assoc_row['row34'];
                $numeric_row[] = $assoc_row['row35'];
                $numeric_row[] = $assoc_row['row36'];
                $numeric_row[] = $assoc_row['row37'];
                $numeric_row[] = $assoc_row['row38'];
                $numeric_row[] = $assoc_row['row39'];
                fputcsv($stream, $numeric_row);
            }

            return $app['twig']->render('csv_file.twig');

    })
    ->bind('project_data')
    ->method('GET|POST');

////業種別サマリ(data1)-----------------------------------------------------------------------------
  $controllers->match('/data1', function (Application $app) {

           $user_info = $app['session']->get('user_info');
     $request = Request::createFromGlobals();
     $show_month = $request->request->get('showMonth',0);
     $download_type = $request->request->get('download',0);
     $data['month_value']['0'] = date("Ym", strtotime("0 month"));
     $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
     $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
     $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
     $data['month_label']['2'] = date("Y年m月", strtotime("-2 month"));
     $YM = date("Ym", strtotime("-$show_month month"));
     $data['YM'] = $YM;
     $project_list = $app['csvdownload.usecase']->GetAllProjects($data['YM']);

     if(!empty($project_list)){

         foreach ($project_list as $key => $value) {
            if ($value['Budget']==0) {
                $row12 = '0%';
            }
            else{
                $row12 = round(($value['Money'] / $value['Budget']) * 100).'%';
            }

            if ($value['PTime']==0) {
                $row15 = '0%';
            }
            else{
                $row15 = round(($value['Time'] / $value['PTime']) * 100).'%';
            }
             $data['project_list'][$key] = array(
                 'row1' => $value['BusinessType'],
                 'row2' => $value['Product'],
                 'row3' => $value['PMO'],
                 'row4' => $value['DMoney1_sum'],
                 'row5' => $value['DMoney2_sum'],
                 'row6' => $value['Dtime1_sum'] * 1600,
                 'row7' => $value['DMoney2_sum'] + ($value['Dtime1_sum'] * 1600),
                 'row8' => $value['DMoney1_sum'] + ($value['DMoney2_sum'] + ($value['Dtime1_sum'] * 1600)),
                 'row9' => $value['Budget'],
                 'row10' => $value['Money'],
                 'row11' => $value['Budget'] - $value['Money'],
                 'row12' => $row12,
                 'row13' => $value['PTime'],
                 'row14' => $value['Time'],
                 'row15' => $row15,
                 'row16' => round(($value['Time'] / 22) * 22),
                 'row17' => $value['PTime'] - round(($value['Time'] / 22) * 22).'%',
                 'row18' => '',
                 'row19' => '',
                 'row20' => '',
                 'row21' => '',
                 'row22' => '',
                 'row23' => '',
                 'row24' => '',
                 'row25' => '',
                 'row26' => '',
                 'row27' => '',
             );
         }
     }
     else{
         $data['project_list'][] = array(
             'row1' => '',
             'row2' => '',
             'row3' => '',
             'row4' => '',
             'row5' => '',
             'row6' => '',
             'row7' => '',
             'row8' => '',
             'row9' => '',
             'row10' => '',
             'row11' => '',
             'row12' => '',
             'row13' => '',
             'row14' => '',
             'row15' => '',
             'row16' => '',
             'row17' => '',
             'row18' => '',
             'row19' => '',
             'row20' => '',
             'row21' => '',
             'row22' => '',
             'row23' => '',
             'row24' => '',
             'row25' => '',
             'row26' => '',
             'row27' => '',
         );
     }
     if($download_type === 'csv'){
         header('Content-Type: application/octet-stream');
             header("Content-Disposition: attachment; filename=業種別サマリ$YM.csv");
         $stream = fopen('php://output', 'w');
         $csv_header = array(
                 'row1','row2','row3','row4','row5','row6','row7','row8','row9','row10',
                 'row11','row12','row13','row14','row15','row16','row17','row18','row19','row20','row21','row22','row23','row24','row25','row26','row27',
             );
         $csv_label =  array(
                 '業種','請求先責任者名','担当PMO名','当月度キャッシュフロー取得予算合計額','当月度キャッシュフロー実績','実績進捗','当月度キャッシュフロー実績月末着地',
             '当月度キャッシュフロー着地差異','当月度予算に対するキャッシュフロー月末着地進捗率','経過月キャッシュフロー取得予算合計',
                 '経過月キャッシュフロー実績合計（当月含む）','>経過月予算に対するキャッシュフロー実績進捗','通年キャッシュフロー取得予算合計',
             '経過月キャッシュフロー実績合計（当月含む）','通年予算に対するキャッシュフロー実績進捗率','当月度PL取得予算合計額','当月度PL実績','当月の予算に対する実績進捗率',
             '当月度PL実績月末着地','当月度PL実績着地差異','当月度予算に対するPL着地進捗率','経過月PL取得予算合計','経過月PL実績合計（当月含む）','経過月予算に対するPL実績進捗率',
             '通年PL取得予算合計','経過月PL実績合計','通年予算に対するPL実績進捗率'
             );
         $numeric_label = array();
         foreach ($csv_label as $value) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
                 $numeric_label[] = $value;
             }
             fputcsv($stream, $numeric_label);
         foreach($data['project_list'] as $key => $assoc_row){
             $numeric_row = array();
             foreach ($csv_header as $header_name) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
                     $numeric_row[] = $assoc_row[$header_name];
                 }
                 fputcsv($stream, $numeric_row);
         }
         return $app['twig']->render('csv_file.twig');
     }
     else{
         return $app['twig']->render('csv/csv_data1.twig',$data);
     }
 })
   ->bind('csv_data1')
   ->method('GET|POST');


////AllProjects(data2)-----------------------------------------------------------------------------
  $controllers->match('/data2', function (Application $app) {

           $user_info = $app['session']->get('user_info');
     $request = Request::createFromGlobals();
     $show_month = $request->request->get('showMonth',0);
     $download_type = $request->request->get('download',0);
     $data['month_value']['0'] = date("Ym", strtotime("0 month"));
     $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
     $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
     $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
     $data['month_label']['2'] = date("Y年m月", strtotime("-2 month"));
     $YM = date("Ym", strtotime("-$show_month month"));
     $data['YM'] = $YM;
     $project_list = $app['csvdownload.usecase']->GetAllProjects($data['YM']);
     if(!empty($project_list)){
         foreach ($project_list as $key => $value) {
            //row13
            if ($value['Budget']==0) {
                $row13 = '0%';
            }
            else{
                $row13 = round(($value['Money'] / $value['Budget']) * 100).'%';
            }
            //row16, row19
            if ($value['PTime']==0) {
                $row16 = '0%';
                $row19 = '0%';
            }
            else{
                $row16 = round(($value['Time'] / $value['PTime']) * 100).'%';
                $row19 = round((round(($value['Time'] / 22) * 22)) / ($value['PTime'])* 100).'%';
            }

             $data['project_list'][$key] = array(
                 'row1' => $value['BusinessType'],
                 'row2' => $value['Product'],
                 'row3' => $value['PMO'],
                 'row4' => $value['ProjectCord'],
                 'row5' => $value['DMoney1_sum'],
                 'row6' => $value['DMoney2_sum'],
                 'row7' => $value['Dtime1_sum'] * 1600,
                 'row8' => $value['DMoney2_sum'] + ($value['Dtime1_sum'] * 1600),
                 'row9' => $value['DMoney1_sum'] + ($value['DMoney2_sum'] + ($value['Dtime1_sum'] * 1600)),
                 'row10' => $value['Budget'],
                 'row11' => $value['Money'],
                 'row12' => $value['Budget'] - $value['Money'],
                 'row13' => $row13,
                 // 'row13' => round(($value['Money'] / $value['Budget']) * 100).'%',
                 'row14' => $value['PTime'],
                 'row15' => $value['Time'],
                 'row16' => $row16,
                 // 'row16' => round(($value['Time'] / $value['PTime']) * 100).'%',
                 'row17' => round(($value['Time'] / 22) * 22),
                 'row18' => $value['PTime'] - round(($value['Time'] / 22) * 22),
                 'row19' => $row19,
                 // 'row19' =>  round((round(($value['Time'] / 22) * 22)) / ($value['PTime'])* 100).'%',
                 'row20' =>  $value['Project']
             );
         }
     }
     else{
         $data['project_list'][] = array(
             'row1' => '',
             'row2' => '',
             'row3' => '',
             'row4' => '',
             'row5' => '',
             'row6' => '',
             'row7' => '',
             'row8' => '',
             'row9' => '',
             'row10' => '',
             'row11' => '',
             'row12' => '',
             'row13' => '',
             'row14' => '',
             'row15' => '',
             'row16' => '',
             'row17' => '',
             'row18' => '',
             'row19' => '',
             'row20' => ''
         );
     }
     if($download_type === 'csv'){
         header('Content-Type: application/octet-stream');
             header("Content-Disposition: attachment; filename=AllProjects$YM.csv");
         $stream = fopen('php://output', 'w');
         $csv_header = array(
                 'row1','row2','row3','row4','row5','row6','row7','row8','row9','row10',
                 'row11','row12','row13','row14','row15','row16','row17','row18','row19','row20'
             );
         $csv_label =  array(
                 '業種','プロダクト','担当PMO','PJコード','資産実績','費用実績','共通費','費用合計','合計（共通費込）','個別プロジェクト',
                 '工数','プロジェクト名','取得予算額','実績合計','着地差異','実績の進捗率','計画','実績','進捗率','月末着地','着地差異','進捗率'
             );
         $numeric_label = array();
         foreach ($csv_label as $value) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
                 $numeric_label[] = $value;
             }
             fputcsv($stream, $numeric_label);
         foreach($data['project_list'] as $key => $assoc_row){
             $numeric_row = array();
             foreach ($csv_header as $header_name) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
                     $numeric_row[] = $assoc_row[$header_name];
                 }
                 fputcsv($stream, $numeric_row);
         }
         return $app['twig']->render('csv_file.twig');
     }
     else{
         return $app['twig']->render('csv/csv_data2.twig',$data);
     }
       })
       ->bind('csv_data2')
       ->method('GET|POST');

////業種別内訳(data3)-----------------------------------------------------------------------------
  $controllers->match('/data3', function (Application $app) {

       $user_info = $app['session']->get('user_info');
     $request = Request::createFromGlobals();
     $show_month = $request->request->get('showMonth',0);
     $download_type = $request->request->get('download',0);
     $data['month_value']['0'] = date("Ym", strtotime("0 month"));
     $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
     $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
     $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
     $data['month_label']['2'] = date("Y年m月", strtotime("-2 month"));
     $YM = date("Ym", strtotime("-$show_month month"));
     $data['YM'] = $YM;
     $project_list = $app['csvdownload.usecase']->getData3($data['YM']);
     if(!empty($project_list)){
         foreach ($project_list as $key => $value) {
            //row13
            if ($value['Budget']==0) {
                $row13 = '0%';
            }
            else{
                $row13 = round(($value['Money'] / $value['Budget']) * 100).'%';
            }
            //row16, row19
            if ($value['PTime']==0) {
                $row16 = '0%';
                $row19 = '0%';
            }
            else{
                $row16 = round(($value['Time'] / $value['PTime']) * 100).'%';
                $row19 = round((round(($value['Time'] / 22) * 22)) / ($value['PTime'])* 100).'%';
            }
             $data['project_list'][$key] = array(
                 'row1' => $value['BusinessType'],
                 'row2' => $value['Product'],
                 'row3' => $value['PMO'],
                 'row4' => $value['ProjectCord'],
                 'row5' => $value['DMoney1_sum'],
                 'row6' => $value['DMoney2_sum'],
                 'row7' => $value['Dtime1_sum'] * 1600,
                 'row8' => $value['DMoney2_sum'] + ($value['Dtime1_sum'] * 1600),
                 'row9' => $value['DMoney1_sum'] + ($value['DMoney2_sum'] + ($value['Dtime1_sum'] * 1600)),
                 'row10' => $value['Budget'],
                 'row11' => $value['Money'],
                 'row12' => $value['Budget'] - $value['Money'],
                 'row13' => $row13,
                 // 'row13' => round(($value['Money'] / $value['Budget']) * 100).'%',
                 'row14' => $value['PTime'],
                 'row15' => $value['Time'],
                 'row16' => $row16,
                 // 'row16' => round(($value['Time'] / $value['PTime']) * 100).'%',
                 'row17' => round(($value['Time'] / 22) * 22),
                 'row18' => $value['PTime'] - round(($value['Time'] / 22) * 22),
                 'row19' =>  $row19,
                 // 'row19' =>  round((round(($value['Time'] / 22) * 22)) / ($value['PTime'])* 100).'%',
                 'row20' =>  $value['Project']
             );
         }
     }
     else{
         $data['project_list'][] = array(
             'row1' => '',
             'row2' => '',
             'row3' => '',
             'row4' => '',
             'row5' => '',
             'row6' => '',
             'row7' => '',
             'row8' => '',
             'row9' => '',
             'row10' => '',
             'row11' => '',
             'row12' => '',
             'row13' => '',
             'row14' => '',
             'row15' => '',
             'row16' => '',
             'row17' => '',
             'row18' => '',
             'row19' => '',
             'row20' => ''
         );
     }
     if($download_type === 'csv'){
         header('Content-Type: application/octet-stream');
             header("Content-Disposition: attachment; filename=AllProjects$YM.csv");
         $stream = fopen('php://output', 'w');
         $csv_header = array(
                 'row1','row2','row3','row4','row5','row6','row7','row8','row9','row10',
                 'row11','row12','row13','row14','row15','row16','row17','row18','row19','row20'
             );
         $csv_label =  array(
                 '業種','プロダクト','担当PMO','PJコード','資産実績','費用実績','共通費','費用合計','合計（共通費込）','個別プロジェクト',
                 '工数','プロジェクト名','取得予算額','実績合計','着地差異','実績の進捗率','計画','実績','進捗率','月末着地','着地差異','進捗率'
             );
         $numeric_label = array();
         foreach ($csv_label as $value) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
                 $numeric_label[] = $value;
             }
             fputcsv($stream, $numeric_label);
         foreach($data['project_list'] as $key => $assoc_row){
             $numeric_row = array();
             foreach ($csv_header as $header_name) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
                     $numeric_row[] = $assoc_row[$header_name];
                 }
                 fputcsv($stream, $numeric_row);
         }
         return $app['twig']->render('csv_file.twig');
     }
     else{
         return $app['twig']->render('csv/csv_data2.twig',$data);
     }
       })
       ->bind('csv_data3')
       ->method('GET|POST');

////人別実績(data4)-----------------------------------------------------------------------------
  $controllers->match('/data4', function (Application $app) {

           $user_info = $app['session']->get('user_info');
     $request = Request::createFromGlobals();
     $show_month = $request->request->get('showMonth',0);
     $download_type = $request->request->get('download',0);
     $data['month_value']['0'] = date("Ym", strtotime("0 month"));
     $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
     $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
     $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
     $YM = date("Ym", strtotime("-$show_month month"));
     $data['YM'] = $YM;
     $project_list = $app['csvdownload.usecase']->GetAllProjects2($data['YM']);
     $n = date('n');
     if(!empty($project_list)){
         foreach ($project_list as $key => $value) {
             $data['project_list'][$key] = array(
                 'row1' => $value['PMO'],
                 'row2' => '請求先責任者',
                 'row3' => $value['BusinessType'],
                 'row4' => $value['Product'],
                 'row5' => $value['AccountId'],
                 'row6' => $value['Name'],
                 'row7' => $value["Price$n"],
                 'row8' => $value['ProjectCord'],
                 'row9' => $value['Project'],
                 'row10' => $value['DTime1'],
                 'row11' => $value['DTime2'],
                 'row12' => $value['DTime1'] * $value["Price$n"],
                 'row13' => ($value['DTime1'] + $value['DTime2']) * 1600,
                 'row14' => ($value['DTime1'] * $value["Price$n"]) + ($value['DTime2'] * $value["Price$n"])
             );
         }
     }
     else{
         $data['project_list'][] = array(
             'row1' => '',
             'row2' => '',
             'row3' => '',
             'row4' => '',
             'row5' => '',
             'row6' => '',
             'row7' => '',
             'row8' => '',
             'row9' => '',
             'row10' => '',
             'row11' => '',
             'row12' => '',
             'row13' => '',
             'row14' => ''
         );
     }
     if($download_type === 'csv'){
         header('Content-Type: application/octet-stream');
             header("Content-Disposition: attachment; filename=人別実績$YM.csv");
         $stream = fopen('php://output', 'w');
         $csv_header = array(
                 'row1','row2','row3','row4','row5','row6','row7','row8','row9','row10',
                 'row11','row12','row13','row14'
             );
         $csv_label =  array(
                 '担当PMO','請求先責任者','業種','プロダクト','社員番号','氏名','時給単価','PJコード','プロジェクト名','資産/工数',
                 '費用/工数','資産実績計','共通費実績計','共通費込実績計'
             );
         $numeric_label = array();
         foreach ($csv_label as $value) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
                 $numeric_label[] = $value;
             }
             fputcsv($stream, $numeric_label);
         foreach($data['project_list'] as $key => $assoc_row){
             $numeric_row = array();
             foreach ($csv_header as $header_name) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
                     $numeric_row[] = $assoc_row[$header_name];
                 }
                 fputcsv($stream, $numeric_row);
         }
         return $app['twig']->render('csv_file.twig');
     }
     else{
         return $app['twig']->render('csv/csv_data4.twig',$data);
     }
       })
       ->bind('data4')
       ->method('GET|POST');

////人別資産化率(data5)-----------------------------------------------------------------------------
 $controllers->match('/data5', function (Application $app) {

       $user_info = $app['session']->get('user_info');
     $request = Request::createFromGlobals();
     $show_month = $request->request->get('showMonth',0);
     $download_type = $request->request->get('download',0);
     $data['month_value']['0'] = date("Ym", strtotime("0 month"));
     $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
     $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
     $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
     $YM = date("Ym", strtotime("-$show_month month"));
     $data['YM'] = $YM;
     $project_list = $app['csvdownload.usecase']->GetAllProjects3($data['YM']);
     $n = date('n');
     if(!empty($project_list)){
         foreach ($project_list as $key => $value) {
             $data['project_list'][$key] = array(
                 'row1' => $value['Class'],
                 'row2' => $value['AccountId'],
                 'row3' => $value['Name'],
                 'row4' => $value['DTime1'],
                 'row5' => $value['DTime2'],
                 'row6' => $value['DTime1']  + $value['DTime2'],
                 'row7' => round(($value['DTime1'] / ($value['DTime1'] + $value['DTime2'])) * 100,1),
                 'row8' => round(($value['DTime2'] / ($value['DTime1'] + $value['DTime2'])) * 100,1).'%',
                 'row9' => $value['DTime3'],
                 'row10' => $value['DTime4'],
                 'row11' => $value['DTime3']  + $value['DTime4'],
                 'row12' => round(($value['DTime3'] / ($value['DTime3'] + $value['DTime4'])) * 100,1).'%',
                 'row13' => round(($value['DTime4'] / ($value['DTime3'] + $value['DTime4'])) * 100,1).'%'
             );
         }
     }
     else{
         $data['project_list'][] = array(
             'row1' => '',
             'row2' => '',
             'row3' => '',
             'row4' => '',
             'row5' => '',
             'row6' => '',
             'row7' => '',
             'row8' => '',
             'row9' => '',
             'row10' => '',
             'row11' => '',
             'row12' => '',
             'row13' => ''
         );
     }
     if($download_type === 'csv'){
         header('Content-Type: application/octet-stream');
             header("Content-Disposition: attachment; filename=人別資産化率$YM.csv");
         $stream = fopen('php://output', 'w');
         $csv_header = array(
                 'row1','row2','row3','row4','row5','row6','row7','row8','row9','row10',
                 'row11','row12','row13'
             );
         $csv_label =  array(
                 '役職','社員番号','氏名','資産/工数','費用/工数','工数総計','資産化率','費用率','間接費工数','直接費工数',
                 '工数総計','間接費比率','直接費比率'
             );
         $numeric_label = array();
         foreach ($csv_label as $value) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
                 $numeric_label[] = $value;
             }
             fputcsv($stream, $numeric_label);
         foreach($data['project_list'] as $key => $assoc_row){
             $numeric_row = array();
             foreach ($csv_header as $header_name) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
                     $numeric_row[] = $assoc_row[$header_name];
                 }
                 fputcsv($stream, $numeric_row);
         }
         return $app['twig']->render('csv_file.twig');
     }
     else{
         return $app['twig']->render('csv/csv_data5.twig',$data);
     }
   })
   ->bind('data5')
   ->method('GET|POST');


////人別日報入力(data6)-----------------------------------------------------------------------------
 $controllers->match('/data6', function (Application $app) {

       $user_info = $app['session']->get('user_info');
     $request = Request::createFromGlobals();
     $show_month = $request->request->get('showMonth',0);
     $download_type = $request->request->get('download',0);
     $data['month_value']['0'] = date("Ym", strtotime("0 month"));
     $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
     $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
     $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
     $YM = date("Ym", strtotime("-$show_month month"));
     $data['YM'] = $YM;
     $project_list = $app['csvdownload.usecase']->GetAllProjects3($data['YM']);
     $n = date('n');
     if(!empty($project_list)){
         foreach ($project_list as $key => $value) {
             $data['project_list'][$key] = array(
                 'row1' => $value['Class'],
                 'row2' => $value['AccountId'],
                 'row3' => $value['Name'],
                 'row4' => $value['BusinessType'],
                 'row5' => $value['ProjectCord'],
                 'row6' => $value['Project'],
                 'row7' => $value['DTime1'],
                 'row8' => $value['DTime2'],
                 'row9' => $value['DTime1']  + $value['DTime2'],
             );
         }
     }
     else{
         $data['project_list'][] = array(
             'row1' => '',
             'row2' => '',
             'row3' => '',
             'row4' => '',
             'row5' => '',
             'row6' => '',
             'row7' => '',
             'row8' => '',
             'row9' => '',

         );
     }
     if($download_type === 'csv'){
         header('Content-Type: application/octet-stream');
             header("Content-Disposition: attachment; filename=人別日報入力$YM.csv");
         $stream = fopen('php://output', 'w');
         $csv_header = array(
                 'row1','row2','row3','row4','row5','row6','row7','row8','row9'
             );
         $csv_label =  array(
                 '役職','社員番号','氏名','業種','PJコード','プロジェクト名','資産/工数','費用/工数','工数総計'
             );
         $numeric_label = array();
         foreach ($csv_label as $value) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
                 $numeric_label[] = $value;
             }
             fputcsv($stream, $numeric_label);
         foreach($data['project_list'] as $key => $assoc_row){
             $numeric_row = array();
             foreach ($csv_header as $header_name) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
                     $numeric_row[] = $assoc_row[$header_name];
                 }
                 fputcsv($stream, $numeric_row);
         }
         return $app['twig']->render('csv_file.twig');
     }
     else{
         return $app['twig']->render('csv/csv_data6.twig',$data);
     }
   })
   ->bind('data6')
   ->method('GET|POST');


////生産性確認(data7)-----------------------------------------------------------------------------
 // $controllers->match('/data7', function (Application $app) {
 //
 //       $user_info = $app['session']->get('user_info');
 //     $request = Request::createFromGlobals();
 //     $show_month = $request->request->get('showMonth',0);
 //     $download_type = $request->request->get('download',0);
 //     $data['month_value']['0'] = date("Ym", strtotime("0 month"));
 //     $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
 //     $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
 //     $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
 //     $YM = date("Ym", strtotime("-$show_month month"));
 //     $data['YM'] = $YM;
 //     $project_list = $app['csvdownload.usecase']->GetData7($data['YM']);
 //     $n = date('n');
 //     if(!empty($project_list)){
 //         foreach ($project_list as $key => $value) {
 //             $data['project_list'][$key] = array(
 //                 'row1' => $value['Name'],
 //                 'row2' => $value['Box']['100'],
 //                 'row3' => $value['Box']['110'],
 //                 'row4' => $value['Box']['120'],
 //                 'row5' => $value['Box']['130'],
 //                 'row6' => $value['Box']['140'],
 //                 'row7' => $value['Box']['150'],
 //                 'row8' => $value['Box']['160'],
 //                 'row9' => $value['Box']['170'],
 //                 'row10' => $value['Box']['200'],
 //                 'row11' => $value['Box']['210'],
 //                 'row12' => $value['Box']['220'],
 //                 'row13' => $value['Box']['230'],
 //                 'row14' => $value['Box']['240'],
 //                 'row15' => $value['Box']['250'],
 //                 'row16' => $value['Box']['300'],
 //                 'row17' => $value['Box1'],
 //                 'row18' => $value['Box2'],
 //                 'row19' => round(($value['Box2'] / $value['Box1'])*100,1).'%'
 //             );
 //         }
 //     }
 //     else{
 //         $data['project_list'][] = array(
 //             'row1' => '',
 //             'row2' => '',
 //             'row3' => '',
 //             'row4' => '',
 //             'row5' => '',
 //             'row6' => '',
 //             'row7' => '',
 //             'row8' => '',
 //             'row9' => '',
 //             'row10' => '',
 //             'row11' => '',
 //             'row12' => '',
 //             'row13' => '',
 //             'row14' => '',
 //             'row15' => '',
 //             'row16' => '',
 //             'row17' => '',
 //             'row18' => '',
 //             'row19' => '',
 //
 //         );
 //     }
 //     if($download_type === 'csv'){
 //         header('Content-Type: application/octet-stream');
 //             header("Content-Disposition: attachment; filename=生産性確認$YM.csv");
 //         $stream = fopen('php://output', 'w');
 //         $csv_header = array(
 //                 'row1','row2','row3','row4','row5','row6','row7','row8','row9'
 //             );
 //         $csv_label =  array(
 //                 '役職','社員番号','氏名','業種','PJコード','プロジェクト名','資産/工数','費用/工数','工数総計'
 //             );
 //         $numeric_label = array();
 //         foreach ($csv_label as $value) {
 //                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
 //                 $numeric_label[] = $value;
 //             }
 //             fputcsv($stream, $numeric_label);
 //         foreach($data['project_list'] as $key => $assoc_row){
 //             $numeric_row = array();
 //             foreach ($csv_header as $header_name) {
 //                     mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
 //                     $numeric_row[] = $assoc_row[$header_name];
 //                 }
 //                 fputcsv($stream, $numeric_row);
 //         }
 //         return $app['twig']->render('csv_file.twig');
 //     }
 //     else{
 //         return $app['twig']->render('csv/csv_data7.twig',$data);
 //     }
 //   })
 //   ->bind('data7')
 //   ->method('GET|POST');
 //

////集計moto(data8)-----------------------------------------------------------------------------
 $controllers->match('/data8', function (Application $app) {

       $user_info = $app['session']->get('user_info');
     $request = Request::createFromGlobals();
     $show_month = $request->request->get('showMonth',0);
     $download_type = $request->request->get('download',0);
     $data['month_value']['0'] = date("Ym", strtotime("0 month"));
     $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
     $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
     $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
     // $YM = date("Ym", strtotime("-$show_month month"));
     $YM = date("Y");
     $data['YM'] = $YM;
     $project_list = $app['csvdownload.usecase']->GetData8($data['YM']);
     $n = date('n');
     if(!empty($project_list)){
         foreach ($project_list as $key => $value) {
             $data['project_list'][$key] = array(
                 'row1' => $value['PMO'],
                 'row2' => $value['Custodian'],
                 'row3' => $value['Accounting'],
                 'row4' => $value['BusinessType'],
                 'row5' => $value['Product'],
                 'row6' => $value["Price$n"],
                 'row7' => $value['Class'],
                 'row8' => $value['AccountId'],
                 'row9' => $value['Name'],
                 'row10' => $value['ProjectCord'],
                 'row11' => $value['Project'],
                 'row12' => $value['Process1'],
                 'row13' => $value['Process2'],
                 'row14' => $value['SubTime'],
                 'row15' => $value['Box1'],
                 'row16' => $value['Box2'],

             );
         }
     }
     else{
         $data['project_list'][] = array(
             'row1' => '',
             'row2' => '',
             'row3' => '',
             'row4' => '',
             'row5' => '',
             'row6' => '',
             'row7' => '',
             'row8' => '',
             'row9' => '',
             'row10' => '',
             'row11' => '',
             'row12' => '',
             'row13' => '',
             'row14' => '',
             'row15' => '',
             'row16' => '',


         );
     }
     if($download_type === 'csv'){
         header('Content-Type: application/octet-stream');
             header("Content-Disposition: attachment; filename=生産性確認$YM.csv");
         $stream = fopen('php://output', 'w');
         $csv_header = array(
                 'row1','row2','row3','row4','row5','row6','row7','row8','row9','row10','row11','row12','row13','row14','row15','row16'
             );
         $csv_label =  array(
                 '担当PMO','PJ責任者','請求先責任者','業種','プロダクト','時給単価','役職','社員番号','氏名','PJコード','PJ名','工程番号','工程','工数','資産or費用','直接費or間接費'
             );
         $numeric_label = array();
         foreach ($csv_label as $value) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
                 $numeric_label[] = $value;
             }
             fputcsv($stream, $numeric_label);
         foreach($data['project_list'] as $key => $assoc_row){
             $numeric_row = array();
             foreach ($csv_header as $header_name) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row[$header_name]);
                     $numeric_row[] = $assoc_row[$header_name];
                 }
                 fputcsv($stream, $numeric_row);
         }
         return $app['twig']->render('csv_file.twig');
     }
     else{
         return $app['twig']->render('csv/csv_data8.twig',$data);
     }
   })
   ->bind('data8')
   ->method('GET|POST');


////人別日報入力(data9)-----------------------------------------------------------------------------
//  $controllers->match('/data9', function (Application $app) {
//
//        $user_info = $app['session']->get('user_info');
//      $request = Request::createFromGlobals();
//      $show_month = $request->request->get('showMonth',0);
//      $download_type = $request->request->get('download',0);
//      $data['month_value']['0'] = date("Ym", strtotime("0 month"));
//      $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
//      $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
//      $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
//      $YM = date("Ym", strtotime("-$show_month month"));
//      $data['YM'] = $YM;
//
//      $lastDay = date('d', strtotime('last day of ' . date('YM',$YM))); /* -----> 月末日 */
//      $Week = array('日', '月', '火', '水', '木', '金', '土');
//
//      // カレンダーID
// //        $calendar_id = urlencode('japanese__ja@holiday.calendar.google.com');
// //        $url = 'https://calendar.google.com/calendar/ical/'.$calendar_id.'/public/full.ics';
// ////      $url = 'https://calendar.google.com/calendar/ical/japanese__ja@holiday.calendar.google.com/public/full.ics';
// //        $ch = curl_init();
// //        curl_setopt($ch, CURLOPT_URL, $url);
// //        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
// //        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
// //        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
// //        $result = curl_exec($ch);
// //        curl_close($ch);
//
//      if (!empty($result)) {
//          $items = $sort = array();
//          $start = false;
//          $count = 0;
//          foreach(explode("\n", $result) as $row => $line) {
//              // 1行目が「BEGIN:VCALENDAR」でなければ終了
//              if (0 === $row && false === stristr($line, 'BEGIN:VCALENDAR')) {
//                  break;
//              }
//              // 改行などを削除
//              $line = trim($line);
//
//              // 「BEGIN:VEVENT」なら日付データの開始
//              if (false !== stristr($line, 'BEGIN:VEVENT')) {
//                  $start = true;
//              } elseif ($start) {
//                  // 「END:VEVENT」なら日付データの終了
//                  if (false !== stristr($line, 'END:VEVENT')) {
//                      $start = false;
//
//                      // 次のデータ用にカウントを追加
//                      ++$count;
//                  } else {
//                      // 配列がなければ作成
//                      if (empty($items[$count])) {
//                          $items[$count] = array('date' => null, 'title' => null);
//                      }
//
//                          //「DTSTART;～」（対象日）の処理
//                      if(0 === strpos($line, 'DTSTART;VALUE')) {
//                          $date = explode(':', $line);
//                          $date = end($date);
//                          $items[$count]['date'] = $date;
//                          // ソート用の配列にセット
//                          $sort[$count] = $date;
//
//                       }
//
//                      // 「SUMMARY:～」（名称）の処理
//                      elseif(0 === strpos($line, 'SUMMARY:')) {
//                          list($title) = explode('/', substr($line, 8));
//                          $items[$count]['title'] = trim($title);
//                      }
//                  }
//              }
//          }
//
//          // 日付でソート
//          $items = array_combine($sort, $items);
//          ksort($items);
//          $Google = $items;
//      }
//
//      $i = 1;
//      while($i <= $lastDay){
//          $Y_M = date('Y-m',  strtotime($YM));
//          $WWeek[$i] =  $Week[date('w', strtotime($Y_M.'-'.$i))];
// //            if(array_key_exists(date("Ymd", strtotime($YM.'-'.$i)), $items) || $WWeek[$i] == '日'){
//          if($WWeek[$i] == '日'){
//              $data['dayLabel'][$i]['day'] = $i.'日';
//              $data['dayLabel'][$i]['num'] = $i;
//              $data['dayLabel'][$i]['color'] = 'red';
//          }elseif($WWeek[$i] == '土'){
//              $data['dayLabel'][$i]['day'] = $i.'日';
//              $data['dayLabel'][$i]['num'] = $i;
//              $data['dayLabel'][$i]['color'] = 'blue';
//          }else{
//              $data['dayLabel'][$i]['day'] = $i.'日';
//              $data['dayLabel'][$i]['num'] = $i;
//              $data['dayLabel'][$i]['color'] = 'black';
//
//          }
//          $i++;
//      }
//
//      $project_list = $app['csvdownload.usecase']->GetData9($data['YM']);
//      $n = date('n');
//      if(!empty($project_list)){
//          foreach ($project_list as $key => $value) {
//              $data['project_list'][$key] = array(
//                  'row1' => $value['AccountId'],
//                  'row2' => $value['Name'],
//                  'row3' => $value['BusinessType'],
//                  'row4' => '',
//                  'row5' => ''
//              );
//              $j = 1;
//              $HDAY = 0;
//              $NotInput = 0;
//              $Input = 0;
//              while($j <= $lastDay){
//
//                  if($value['Time'.$j] == 0 && ($WWeek[$j] == '土' || $WWeek[$j] == '日')){
//                      if($WWeek[$j] == '土'){
//                          $data['project_list'][$key]['days'][$j]['day'] = '休';
//                          $data['project_list'][$key]['days'][$j]['class'] = 'D9td11';
//                      }
//                      else{
//                          $data['project_list'][$key]['days'][$j]['day'] = '休';
//                          $data['project_list'][$key]['days'][$j]['class'] = 'D9td12';
//                      }
//                  }
//                  elseif(!empty($value['Holiday'.$j])){
//                      if($value['Holiday'.$j] == '休'){
//                          $data['project_list'][$key]['days'][$j]['day'] = '休';
//                          $data['project_list'][$key]['days'][$j]['class'] = 'D9td12';
//                          $HDAY++;
//                      }
//                  }
//
//                  else{
//                      if($value['Time'.$j] == 0){
//                          $data['project_list'][$key]['days'][$j]['day'] = $value['Time'.$j];
//                          $data['project_list'][$key]['days'][$j]['class'] = 'D9td02';
//                          $HDAY++;
//                          $NotInput++;
//                      }else{
//                          $data['project_list'][$key]['days'][$j]['day'] = $value['Time'.$j];
//                          $data['project_list'][$key]['days'][$j]['class'] = 'D9td02';
//                          $HDAY++;
//                          $Input++;
//                      }
//                  }
//                  $j++;
//              }
//              $data['project_list'][$key]['row4'] = $HDAY;
//              $data['project_list'][$key]['row5'] = $Input;
//              $data['project_list'][$key]['row6'] = $NotInput;
//          }
//      }
//      else{
//          $data['project_list'][] = array(
//              'row1' => '',
//              'row2' => '',
//              'row3' => '',
//              'row4' => '',
//              'row5' => '',
//              'row6' => '',
//          );
//      }
//      if($download_type === 'csv'){
//          header('Content-Type: application/octet-stream');
//              header("Content-Disposition: attachment; filename=未入力者チェック$YM.csv");
//          $stream = fopen('php://output', 'w');
//          $csv_header = array(
//                  'row1','row2','row3'
//              );
//          $csv_label =  array(
//                  '社員番号','氏名','業種'
//              );
//          foreach($data['dayLabel'] as $value){
//              array_push($csv_header, $value['num']);
//              array_push($csv_label, $value['day']);
//          }
//          $numeric_label = array();
//          foreach ($csv_label as $value) {
//                      mb_convert_variables('SJIS-win', 'UTF-8', $value);
//                  $numeric_label[] = $value;
//              }
//              fputcsv($stream, $numeric_label);
//
//          foreach($data['project_list'] as $key => $assoc_row){
//              $numeric_row = array();
//                  mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
//                  mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
//                  mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
//              $numeric_row[] = $assoc_row['row1'];
//              $numeric_row[] = $assoc_row['row2'];
//              $numeric_row[] = $assoc_row['row3'];
//              foreach ($csv_header as $header_name) {
//                  if(isset($assoc_row['days'][$header_name]['day'])){
//                          mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['days'][$header_name]['day']);
//                          $numeric_row[] = $assoc_row['days'][$header_name]['day'];
//                  }
//                  }
//                  fputcsv($stream, $numeric_row);
//          }
//          return $app['twig']->render('csv_file.twig');
//      }
//      else{
//          return $app['twig']->render('csv/csv_data9.twig',$data);
//      }
//    })
//    ->bind('data9')
//    ->method('GET|POST');


////開発者リスト(data10)-----------------------------------------------------------------------------
 $controllers->match('/data10', function (Application $app) {

       $user_info = $app['session']->get('user_info');
     $request = Request::createFromGlobals();
     $show_month = $request->request->get('showMonth',0);
     $download_type = $request->request->get('download',0);
     $data['status'] = $request->request->get('status','人件費');
     $data['month_value']['0'] = date("Ym", strtotime("0 month"));
     $data['month_value']['1'] = date("Ym", strtotime("-1 month"));
     $data['month_label']['0'] = date("Y年m月", strtotime("0 month"));
     $data['month_label']['1'] = date("Y年m月", strtotime("-1 month"));
     $YM = date("Ym", strtotime("-$show_month month"));
     $YM = '201603';
     $YM2 = date("Y");
     $data['YM'] = $YM;

     $lastDay = date('d', strtotime('last day of ' . date('YM',$YM))); /* -----> 月末日 */
     $Week = array('日', '月', '火', '水', '木', '金', '土');
     if(date("m", strtotime($YM))<4){
             $data['between1'] = date("Ym", strtotime((date("Y", strtotime($YM))-1).'-04-01'));
             $data['between2'] = date("Ym", strtotime(date("Y", strtotime($YM)).'-03-01'));
             $data['Y'] = date("Y", strtotime($YM))-1;
             $dl = (date("Y", strtotime($YM))-1).'-04-01';
         }
         else{
             $data['between1'] = date("Ym", strtotime(date("Y", strtotime($YM)).'-04-01'));
             $data['between2'] = date("Ym", strtotime((date("Y", strtotime($YM))+1).'-03-01'));
             $data['Y'] = date("Y", strtotime($YM));
             $dl = (date("Y", strtotime($YM))).'-04-01';
         }
     if(date("m")<4){
         $data['TCheck'] = date("Ym", strtotime((date("Y")-1).'-04-01'));
         $data['SY'] = date("Y", strtotime((date("Y")-1).'-04-01'));
     }else{
         $data['TCheck'] = date("Ym", strtotime((date("Y")).'-04-01'));
         $data['SY'] = date("Y", strtotime((date("Y")).'-04-01'));
     }

     $i = 1;
     while($i <= $lastDay){
         $Y_M = date('Y-m',  strtotime($YM));
         $WWeek[$i] =  $Week[date('w', strtotime($Y_M.'-'.$i))];
//            if(array_key_exists(date("Ymd", strtotime($YM.'-'.$i)), $items) || $WWeek[$i] == '日'){
         if($WWeek[$i] == '日'){
             $data['dayLabel'][$i]['day'] = $i.'日';
             $data['dayLabel'][$i]['num'] = $i;
             $data['dayLabel'][$i]['color'] = 'red';
         }elseif($WWeek[$i] == '土'){
             $data['dayLabel'][$i]['day'] = $i.'日';
             $data['dayLabel'][$i]['num'] = $i;
             $data['dayLabel'][$i]['color'] = 'blue';
         }else{
             $data['dayLabel'][$i]['day'] = $i.'日';
             $data['dayLabel'][$i]['num'] = $i;
             $data['dayLabel'][$i]['color'] = 'black';

         }
         $i++;
     }
//
     $project_list = $app['csvdownload.usecase']->GetData10($data['between1'],$data['between2'],$data['status'], $YM2);
//        echo "<meta charset='UTF-8'/><pre>";
//print_r($project_list);
//echo "</pre>";
     $n = date('n');
     if(!empty($project_list)){
         foreach ($project_list as $key => $value) {

             $data['project_list'][$key] = array(
                 'row1' => 'No.'.$key+1,
                 'row2' => $value['AccountId'],
                 'row3' => $value['Name'],
                 // 'row4' => $value['PriceGroup'],
                 'row4' => '人件費',
                 'row5' => '計画',
                 'row6' => $value['Moneys']['PMoney']['sum'],
                 'row7' => $value['Moneys']['PMoney'][4],
                 'row8' => $value['Moneys']['PMoney'][5],
                 'row9' => $value['Moneys']['PMoney'][6],
                 'row10' => $value['Moneys']['PMoney'][7],
                 'row11' => $value['Moneys']['PMoney'][8],
                 'row12' => $value['Moneys']['PMoney'][9],
                 'row13' => $value['Moneys']['PMoney'][10],
                 'row14' => $value['Moneys']['PMoney'][11],
                 'row15' => $value['Moneys']['PMoney'][12],
                 'row16' => $value['Moneys']['PMoney'][1],
                 'row17' => $value['Moneys']['PMoney'][2],
                 'row18' => $value['Moneys']['PMoney'][3],
                 'row19' => $value['row3']['Money'],
                 'row20' => $value['Moneys']['Money'][4],
                 'row21' => $value['Moneys']['Money'][5],
                 'row22' => $value['Moneys']['Money'][6],
                 'row23' => $value['Moneys']['Money'][7],
                 'row24' => $value['Moneys']['Money'][8],
                 'row25' => $value['Moneys']['Money'][9],
                 'row26' => $value['Moneys']['Money'][10],
                 'row27' => $value['Moneys']['Money'][11],
                 'row28' => $value['Moneys']['Money'][12],
                 'row29' => $value['Moneys']['Money'][1],
                 'row30' => $value['Moneys']['Money'][2],
                 'row31' => $value['Moneys']['Money'][3],
             );
         }
     }
     else{
         $data['project_list'][] = array(
             'row1' => '',
             'row2' => '',
             'row3' => '',
             'row4' => '',
             'row5' => '',
             'row6' => '',
             'row7' => '',
             'row8' => '',
             'row9' => '',
             'row10' => '',
             'row11' => '',
             'row12' => '',
             'row13' => '',
             'row14' => '',
             'row15' => '',
             'row16' => '',
             'row17' => '',
             'row18' => '',
             'row19' => '',
             'row20' => '',
             'row21' => '',
             'row22' => '',
             'row23' => '',
             'row24' => '',
             'row25' => '',
             'row26' => '',
             'row27' => '',
             'row28' => '',
             'row29' => '',
             'row30' => '',
             'row31' => '',
         );
     }
     if($download_type === 'csv'){
         header('Content-Type: application/octet-stream');
             header("Content-Disposition: attachment; filename=開発者リスト$YM.csv");
         $stream = fopen('php://output', 'w');
         $csv_header = array(
                 'row1','row2','row3'
             );
         $csv_label =  array(
                 '社員番号','氏名','業種'
             );
         foreach($data['dayLabel'] as $value){
             array_push($csv_header, $value['num']);
             array_push($csv_label, $value['day']);
         }
         $numeric_label = array();
         foreach ($csv_label as $value) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
                 $numeric_label[] = $value;
             }
             fputcsv($stream, $numeric_label);

         foreach($data['project_list'] as $key => $assoc_row){
             $numeric_row = array();
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
             $numeric_row[] = $assoc_row['row1'];
             $numeric_row[] = $assoc_row['row2'];
             $numeric_row[] = $assoc_row['row3'];
             foreach ($csv_header as $header_name) {
                 if(isset($assoc_row['days'][$header_name]['day'])){
                         mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['days'][$header_name]['day']);
                         $numeric_row[] = $assoc_row['days'][$header_name]['day'];
                 }
                 }
                 fputcsv($stream, $numeric_row);
         }
         return $app['twig']->render('csv_file.twig');
     }
     else{
         return $app['twig']->render('csv/csv_data10.twig',$data);
     }
   })
   ->bind('data10')
   ->method('GET|POST');

////業種マスタ(data11)-----------------------------------------------------------------------------
 // $controllers->match('/data11', function (Application $app) {
 //
 //       $user_info = $app['session']->get('user_info');
 //     $request = Request::createFromGlobals();
 //     $download_type = $request->request->get('download',0);
 //     $data['edit_no'] = $request->request->get('edit_no',null);
 //
 //     $project_list = $app['csvdownload.usecase']->GetData11($data['edit_no']);
 //
 //     $n = date('n');
 //     if(!empty($project_list)){
 //         foreach ($project_list as $key => $value) {
 //             $no = str_pad($key+1, 3, 0, STR_PAD_LEFT);
 //             $data['project_list'][$key] = array(
 //                 'row1' => $no,
 //                 'row2' => $value['BusinessType'],
 //                 'row3' => $value['Product'],
 //             );
 //         }
 //     }
 //     else{
 //         $data['project_list'][] = array(
 //             'row1' => '',
 //             'row2' => '',
 //             'row3' => '',
 //         );
 //     }
 //     if($download_type === 'csv'){
 //         header('Content-Type: application/octet-stream');
 //             header("Content-Disposition: attachment; filename=業種マスタ.csv");
 //         $stream = fopen('php://output', 'w');
 //         $csv_header = array(
 //                 'row1','row2','row3'
 //             );
 //         $csv_label =  array(
 //                 'No','業種','プロダクト'
 //             );
 //         foreach ($csv_label as $value) {
 //                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
 //                 $numeric_label[] = $value;
 //             }
 //             fputcsv($stream, $numeric_label);
 //
 //         foreach($data['project_list'] as $key => $assoc_row){
 //             $numeric_row = array();
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
 //             $numeric_row[] = $assoc_row['row1'];
 //             $numeric_row[] = $assoc_row['row2'];
 //             $numeric_row[] = $assoc_row['row3'];
 //             foreach ($csv_header as $header_name) {
 //                 if(isset($assoc_row['days'][$header_name]['day'])){
 //                         mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['days'][$header_name]['day']);
 //                         $numeric_row[] = $assoc_row['days'][$header_name]['day'];
 //                 }
 //                 }
 //                 fputcsv($stream, $numeric_row);
 //         }
 //         return $app['twig']->render('csv_file.twig');
 //     }
 //     else{
 //         return $app['twig']->render('csv/csv_data11.twig',$data);
 //     }
 //   })
 //   ->bind('data11')
 //   ->method('GET|POST');

////業種/請求先/担当PMOマスタ(data12)-----------------------------------------------------------------------------
 // $controllers->match('/data12', function (Application $app) {
 //
 //       $user_info = $app['session']->get('user_info');
 //     $request = Request::createFromGlobals();
 //     $download_type = $request->request->get('download',0);
 //     $data['edit_no'] = $request->request->get('edit_no',null);
 //
 //     $project_list = $app['csvdownload.usecase']->GetData12($data['edit_no']);
 //
 //     $n = date('n');
 //     if(!empty($project_list)){
 //         foreach ($project_list as $key => $value) {
 //             $no = str_pad($key+1, 3, 0, STR_PAD_LEFT);
 //             $data['project_list'][$key] = array(
 //                 'row1' => $no,
 //                 'row2' => $value['PMO'],
 //                 'row3' => $value['Accounting'],
 //                 'row4' => $value['BusinessType'],
 //             );
 //         }
 //     }
 //     else{
 //         $data['project_list'][] = array(
 //             'row1' => '',
 //             'row2' => '',
 //             'row3' => '',
 //             'row4' => '',
 //         );
 //     }
 //     if($download_type === 'csv'){
 //         header('Content-Type: application/octet-stream');
 //             header("Content-Disposition: attachment; filename=業種・請求先・PMOマスタ.csv");
 //         $stream = fopen('php://output', 'w');
 //         $csv_header = array(
 //                 'No','row2','row3','row4'
 //             );
 //         $csv_label =  array(
 //                 'No','担当PMO','請求責任者','業種'
 //             );
 //         foreach ($csv_label as $value) {
 //                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
 //                 $numeric_label[] = $value;
 //             }
 //             fputcsv($stream, $numeric_label);
 //
 //         foreach($data['project_list'] as $key => $assoc_row){
 //             $numeric_row = array();
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
 //             $numeric_row[] = $assoc_row['row1'];
 //             $numeric_row[] = $assoc_row['row2'];
 //             $numeric_row[] = $assoc_row['row3'];
 //             $numeric_row[] = $assoc_row['row4'];
 //                 fputcsv($stream, $numeric_row);
 //         }
 //         return $app['twig']->render('csv_file.twig');
 //     }
 //     else{
 //         return $app['twig']->render('csv/csv_data12.twig',$data);
 //     }
 //   })
 //   ->bind('data12')
 //   ->method('GET|POST');

////資産OR費用(data13)-----------------------------------------------------------------------------
 // $controllers->match('/data13', function (Application $app) {
 //
 //       $user_info = $app['session']->get('user_info');
 //     $request = Request::createFromGlobals();
 //     $download_type = $request->request->get('download',0);
 //     $data['edit_no'] = $request->request->get('edit_no',null);
 //
 //     $project_list = $app['csvdownload.usecase']->GetData13($data['edit_no']);
 //
 //     $n = date('n');
 //     if(!empty($project_list)){
 //         foreach ($project_list as $key => $value) {
 //             $no = str_pad($key+1, 3, 0, STR_PAD_LEFT);
 //             $data['project_list'][$key] = array(
 //                 'row1' => $no,
 //                 'row2' => $value['WorkName'],
 //                 'row3' => $value['WorkNo'],
 //                 'row4' => $value['WGroup1'],
 //                 'row5' => $value['WGroup2'],
 //             );
 //         }
 //     }
 //     else{
 //         $data['project_list'][] = array(
 //             'row1' => '',
 //             'row2' => '',
 //             'row3' => '',
 //             'row4' => '',
 //         );
 //     }
 //     if($download_type === 'csv'){
 //         header('Content-Type: application/octet-stream');
 //             header("Content-Disposition: attachment; filename=資産OR費用.csv");
 //         $stream = fopen('php://output', 'w');
 //         $csv_header = array(
 //                 'No','row2','row3','row4','row5'
 //             );
 //         $csv_label =  array(
 //                 'No','PJコード区分','工程番号','工程名','区分'
 //             );
 //         foreach ($csv_label as $value) {
 //                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
 //                 $numeric_label[] = $value;
 //             }
 //             fputcsv($stream, $numeric_label);
 //
 //         foreach($data['project_list'] as $key => $assoc_row){
 //             $numeric_row = array();
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
 //             $numeric_row[] = $assoc_row['row1'];
 //             $numeric_row[] = $assoc_row['row2'];
 //             $numeric_row[] = $assoc_row['row3'];
 //             $numeric_row[] = $assoc_row['row4'];
 //             $numeric_row[] = $assoc_row['row5'];
 //                 fputcsv($stream, $numeric_row);
 //         }
 //         return $app['twig']->render('csv_file.twig');
 //     }
 //     else{
 //         return $app['twig']->render('csv/csv_data13.twig',$data);
 //     }
 //   })
 //   ->bind('data13')
 //   ->method('GET|POST');

////PJコードマスタ(data14)-----------------------------------------------------------------------------
 $controllers->match('/data14', function (Application $app) {

       $user_info = $app['session']->get('user_info');
     $request = Request::createFromGlobals();
     $download_type = $request->request->get('download',0);
     $data['edit_no'] = $request->request->get('edit_no',null);

     $project_list = $app['csvdownload.usecase']->GetData14($data['edit_no']);

     $n = date('n');
     if(!empty($project_list)){
         foreach ($project_list as $key => $value) {
             $no = str_pad($key+1, 3, 0, STR_PAD_LEFT);
             $data['project_list'][$key] = array(
                 'row1' => $value['ProjectCord'],
                 'row2' => $value['Project'],
                 'row3' => $value['Status'],
                 'row4' => $value['BusinessType'],
                 'row5' => $value['Product'],
                 'row6' => $value['PMO'],
                 'row7' => $value['Accounting'],
                 'row8' => $value['Custodian'],
                 'row9' => $value['Budget'],
                 'row10' => $value['PlanDate'],
                 'row11' => $value['CloseDate'],
//                    'row9' => $value['Budget'],
             );
         }
     }
     else{
         $data['project_list'][] = array(
             'row1' => '',
             'row2' => '',
             'row3' => '',
             'row4' => '',
             'row5' => '',
             'row6' => '',
             'row7' => '',
             'row8' => '',
             'row9' => '',
             'row10' => '',
             'row11' => '',
         );
     }
     if($download_type === 'csv'){
         header('Content-Type: application/octet-stream');
             header("Content-Disposition: attachment; filename=PJコードマスタ.csv");
         $stream = fopen('php://output', 'w');
         $csv_header = array(
                 'row1','row2','row3','row4','row5','row6','row7','row8','row9','row10','row11'
             );
         $csv_label =  array(
                 'PJコード','PJ名','ステータス','業種','プロダクト','担当PMO','PJ責任者','請求先責任者','取得予算','開始日','終了予定日'
             );
         foreach ($csv_label as $value) {
                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
                 $numeric_label[] = $value;
             }
             fputcsv($stream, $numeric_label);

         foreach($data['project_list'] as $key => $assoc_row){
             $numeric_row = array();
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row1']);
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row5']);
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row6']);
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row7']);
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row8']);
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row9']);
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row10']);
                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row11']);
             $numeric_row[] = $assoc_row['row1'];
             $numeric_row[] = $assoc_row['row2'];
             $numeric_row[] = $assoc_row['row3'];
             $numeric_row[] = $assoc_row['row4'];
             $numeric_row[] = $assoc_row['row5'];
             $numeric_row[] = $assoc_row['row6'];
             $numeric_row[] = $assoc_row['row7'];
             $numeric_row[] = $assoc_row['row8'];
             $numeric_row[] = $assoc_row['row9'];
             $numeric_row[] = $assoc_row['row10'];
             $numeric_row[] = $assoc_row['row11'];
                 fputcsv($stream, $numeric_row);
         }
         return $app['twig']->render('csv_file.twig');
     }
     else{
         return $app['twig']->render('csv/csv_data14.twig',$data);
     }
   })
   ->bind('data14')
   ->method('GET|POST');

////組織図リストマスタ(data15)-----------------------------------------------------------------------------
 // $controllers->match('/data15', function (Application $app) {
 //
 //       $user_info = $app['session']->get('user_info');
 //     $request = Request::createFromGlobals();
 //     $download_type = $request->request->get('download',0);
 //     $data['edit_no'] = $request->request->get('edit_no',null);
 //
 //     $project_list = $app['csvdownload.usecase']->GetData15($data['edit_no']);
 //
 //     $n = date('n');
 //     if(!empty($project_list)){
 //         foreach ($project_list as $key => $value) {
 //             $no = str_pad($key+1, 3, 0, STR_PAD_LEFT);
 //             $data['project_list'][$key] = array(
 //                 'row1' => $no,
 //                 'row2' => $value['AccountId'],
 //                 'row3' => $value['Name'],
 //                 'row4' => $value['Chief'],
 //             );
 //         }
 //     }
 //     else{
 //         $data['project_list'][] = array(
 //             'row1' => '',
 //             'row2' => '',
 //             'row3' => '',
 //             'row4' => '',
 //         );
 //     }
 //     if($download_type === 'csv'){
 //         header('Content-Type: application/octet-stream');
 //             header("Content-Disposition: attachment; filename=組織図リストマスタ.csv");
 //         $stream = fopen('php://output', 'w');
 //         $csv_header = array(
 //                 'row1','row2','row3'
 //             );
 //         $csv_label =  array(
 //                 '社員番号','氏名','ブロック責任者'
 //             );
 //         foreach ($csv_label as $value) {
 //                     mb_convert_variables('SJIS-win', 'UTF-8', $value);
 //                 $numeric_label[] = $value;
 //             }
 //             fputcsv($stream, $numeric_label);
 //
 //         foreach($data['project_list'] as $key => $assoc_row){
 //             $numeric_row = array();
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row2']);
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row3']);
 //                 mb_convert_variables('SJIS-win', 'UTF-8', $assoc_row['row4']);
 //             $numeric_row[] = $assoc_row['row2'];
 //             $numeric_row[] = $assoc_row['row3'];
 //             $numeric_row[] = $assoc_row['row4'];
 //                 fputcsv($stream, $numeric_row);
 //         }
 //         return $app['twig']->render('csv_file.twig');
 //     }
 //     else{
 //         return $app['twig']->render('csv/csv_data15.twig',$data);
 //     }
 //   })
 //   ->bind('data15')
 //   ->method('GET|POST');


 // $controllers->match('/download_value_test', function (Application $app) {
 //     $user_info = $app['session']->get('user_info');
 //      $data['YM'] =  date('Ym');
 //     $data['project_list'] = $app['csvdownload.usecase']->GetData1_1('201607');
 //     echo " <meta charset='UTF-8'/><pre>";
 //     print_r($data['project_list']);
 //     echo "</pre>";
 //     return $app['twig']->render('csv/csv_download_value_test.twig',$data);
 //       })
 //       ->bind('download_value_test')
 //       ->method('GET|POST');

        return $controllers;

    }
}
