<?php

namespace App\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Silex\ControllerProviderInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;

/**
 *
 */
class ProjectListController implements ControllerProviderInterface
{


    public function connect(Application $app)
    {
        $controllers = $app['controllers_factory'];
        $user_info = $app['session']->get('user_info');

        $controllers->before(function (Request $request, Application $app) {
            $user_info = $app['session']->get('user_info');
            if (!$user_info) {
                return $app->redirect($app['url_generator']->generate('login'));
            }
            switch ($user_info->getLevel()) {
                case '事務局':
                    break;
                case '管理者':
                    break;
                case '一般':
                    return $app->redirect($app['url_generator']->generate('home'));
                    break;
            }
        });

        $controllers->match('/projectlist', function (Request $request, Application $app) {

            if (!($request->request->get('year')) && !($request->request->get('status')) ) {
                $request->request->set('status', '進行中');
                $request->request->set('year', date('Y'));
            }
            $user_info = $app['session']->get('user_info');


            if ($request->isMethod('POST')) {
                $allprojectlist = $app['all_projects.usecase']->GetAllProjects($request->request, $user_info);
            }else{
                $allprojectlist = $app['all_projects.usecase']->GetAllProjects($request->request, $user_info);
            }
            // var_dump($request->request);
            // exit();
            $project_money = $app['all_projects.usecase']->GetProjectsBudget();
            $year_flag = $request->request->get('year');
            $status_flag = $request->request->get('status');
            $search = $request->request->get('search');
            $data = array(
                      'allprojects'  => $allprojectlist,
                      'status_flag'  => $status_flag,
                      'year_flag'    => $year_flag,
                      'project_money'    => $project_money,
                      'search'    => $search,
                      'user_info'    => $user_info
                        );
            return $app['twig']->render('projectlist.twig', $data);
        })
        ->bind('projectlist')
        ->method('GET|POST');


        $controllers->match('/EditProject/{No}', function (Request $request, Application $app, $No) {
            $user_info = $app['session']->get('user_info');
             if (!($request->request->get('year')))
             {
                $month = intval(date('m'));
                $year = date('Y');
                if ($month<4) {
                  $year = $year - 1;
                }
                $request->request->set('year', $year);

             }
              if (!($request->request->get('No')))
             {
                $request->request->set('No', $No);
             }
             if($app['session']->get('message')){
                 $message = $app['session']->get('message'); 
                $app['session']->remove('message');
             }
             else{
                $message = '';
             }
             $year_flag = $request->request->get('year');
            if ($request->isMethod('POST')) {
                if ($request->request->get('year')) {
                $project_data = $app['all_projects.usecase']->GetProjectDataById($request->request);
                $project_money = $app['all_projects.usecase']->GetProjectMoneyById($request->request, $project_data);
                $user_time_sum = $app['all_projects.usecase']->GetMonthTimeSumByProjectId($request->request, $project_data);
                $project_time_sum = $app['all_projects.usecase']->GetProjectMonthTimeSumByProjectId($request->request, $project_data);
                $business_type  = $app['add_project.usecase']->GetBusinessType();
                $project_officer =$app['add_project.usecase']->GetName();
                $budget_office = $app['add_project.usecase']->GetBudgetoffice();
                $data = array('project_data' => $project_data,
                              'user_time_sum' => $user_time_sum,
                              'project_time_sum' => $project_time_sum,
                              'year_flag' => $year_flag,
                              'business_type' => $business_type,
                              'project_officer' => $project_officer,
                              'budget_office' => $budget_office,
                              'project_money' => $project_money,
                              'user_info'    => $user_info,
                            );
                return $app['twig']->render('EditProject.twig', $data);
                }
            }
            
            $project_data = $app['all_projects.usecase']->GetProjectDataById($request->request);
            $project_money = $app['all_projects.usecase']->GetProjectMoneyById($request->request, $project_data);
            $user_time_sum = $app['all_projects.usecase']->GetMonthTimeSumByProjectId($request->request, $project_data);
            $project_time_sum = $app['all_projects.usecase']->GetProjectMonthTimeSumByProjectId($request->request, $project_data);
            $business_type  = $app['add_project.usecase']->GetBusinessType();
            $project_officer =$app['add_project.usecase']->GetName();
            $budget_office = $app['add_project.usecase']->GetBudgetoffice();
            $data = array('project_data' => $project_data,
                          'user_time_sum' => $user_time_sum,
                          'project_time_sum' => $project_time_sum,
                          'year_flag' => $year_flag,
                          'business_type' => $business_type,
                          'project_officer' => $project_officer,
                          'budget_office' => $budget_office,
                          'project_money' => $project_money,
                          'user_info'    => $user_info,
                          'message'    => $message
                        );
            return $app['twig']->render('EditProject.twig', $data);
        })
        ->bind('EditProject')
        ->assert('No', '\d{1,20}');

         $controllers->match('/UpdateProject', function (Request $request, Application $app) {
          $No = $request->request->get('Number');
          $request->request->set('No', $No);
	  $user_info = $app['session']->get('user_info');
          $mydb = $app['dbs'];
          if (!($request->request->get('year')))
             {
                $request->request->set('year', date('Y'));
             }
          $project_data = $app['all_projects.usecase']->GetProjectDataById($request->request);
          $user_time_sum = $app['all_projects.usecase']->GetMonthTimeSumByProjectId($request->request, $project_data);
          $mydb = $app['dbs'];
          $connection = new \PDO("mysql:host=".$mydb['default']->getHost().";dbname=".$mydb['default']->getDatabase().";charset=utf8", $mydb['default']->getUsername(), $mydb['default']->getPassword(),  array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
          $edit_project_status = $app['all_projects.usecase']->UpdateProjectStatus($request->request, $user_time_sum, $user_info, $connection);
          if ($project_data->getPStatus() === "未着手") {
            $pmo_mail = $app['add_project.usecase']->findPMOMailId($project_data);
            // $app['Mailer']->sendMailToPMO($project_data, $pmo_mail);
          }   
          return $app->redirect($app['url_generator']->generate('EditProject', array('No' => $No)));

        })
         ->bind('UpdateProject');
        return $controllers;

    }
}
