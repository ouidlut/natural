<?php

namespace App\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Silex\ControllerProviderInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;


/**
 *
 */
class AddMemberController implements ControllerProviderInterface
{

  public function connect(Application $app)
  {
      $controllers = $app['controllers_factory'];
      $user_info = $app['session']->get('user_info');



      $controllers->match('/AddMember', function (Request $request, Application $app)
      {
        $projectofficer =$app['']->GetName();

        $budgetoffice = $app['']->GetBudgetoffice();
        $BusinessType	= $app['']->GetBusinessType();


        return $app['twig']->render('AddMember.twig');

      })
      ->bind('AddProject');






      return $controllers;


  }





}
