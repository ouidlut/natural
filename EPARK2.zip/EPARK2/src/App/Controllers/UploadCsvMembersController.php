<?php

namespace App\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ParameterBag;
use Silex\ControllerProviderInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Intl\Exception\RuntimeException;

class UploadCsvMembersController implements ControllerProviderInterface
{
public function connect(Application $app)
{
	$controllers = $app['controllers_factory'];
	$user_info = $app['session']->get('user_info');

	$controllers->before(function (Request $request, Application $app) {
	$user_info = $app['session']->get('user_info');
		if (!$user_info) {
			return $app->redirect($app['url_generator']->generate('login'));
		}
		switch ($user_info->getLevel()) {
			case '事務局':
				break;
			case '管理者':
				break;
			case '一般':
				return $app->redirect($app['url_generator']->generate('home'));
				break;
		}
	});
		
	$controllers->match('/UploadCsvMembers', function (Request $request, Application $app) {
		$accountID= array();
		$accountPass = array();
		$accountName = array();
		$level = array();
		$results = array();

		try {
			$user_info = $app['session']->get('user_info');
			// 未定義である・複数ファイルである・$_FILES Corruption 攻撃を受けた
			// どれかに該当していれば不正なパラメータとして処理する
			if (!isset($_FILES['upfile']['error']) || !is_int($_FILES['upfile']['error'])) {
    				throw new RuntimeException('パラメータが不正です');
			}

			// $_FILES['upfile']['error'] の値を確認
			switch ($_FILES['upfile']['error']) {
				case UPLOAD_ERR_OK: // OK
					break;
				case UPLOAD_ERR_NO_FILE:   // ファイル未選択
					throw new RuntimeException('ファイルが選択されていません');
				case UPLOAD_ERR_INI_SIZE:  // php.ini定義の最大サイズ超過
       				case UPLOAD_ERR_FORM_SIZE: // フォーム定義の最大サイズ超過 (設定した場合のみ)
           				throw new RuntimeException('ファイルサイズが大きすぎます');
        			default:
            				throw new RuntimeException('その他のエラーが発生しました');
    			}
				
			$name = $_FILES['upfile']['name'];
			$tmp_name = $_FILES['upfile']['tmp_name'];
			$detect_order = 'ASCII,JIS,UTF-8,CP51932,SJIS-win';
			setlocale(LC_ALL, 'ja_JP.UTF-8');

			if (!strpos($name , ".csv")) {
				throw new RuntimeException('ファイル形式が不正です');
			}

    			// $_FILES['upfile']['mime']の値はブラウザ側で偽装可能なので
    			// MIMEタイプに対応する拡張子を自前で取得する
    			if (!$ext = array_search(mime_content_type($tmp_name),array('csv' => 'text/plain'),true)) {
        			throw new RuntimeException('ファイル形式が不正です');
    			}

			/* 文字コードを変換してファイルを置換 */
			$buffer = file_get_contents($tmp_name);
			if (!$encoding = mb_detect_encoding($buffer, $detect_order, true)) {
				// 文字コードの自動判定に失敗
				unset($buffer);
				throw new RuntimeException('Character set detection failed');
			}
			file_put_contents($tmp_name, mb_convert_encoding($buffer, 'UTF-8', $encoding));
			unset($buffer);

			error_log("データベース選択失敗---0");
			//データベース選択
			$link = mysql_connect('localhost', 'root', '');	
			if(!$link) {
				echo "データベース接続失敗";
				exit;
			}
			error_log("データベース選択失敗---1");
			
			$db = mysql_select_db('epark_report_manage', $link);
			if(!$db) {
				echo "データベース選択失敗";
				exit;
			}
			
			error_log("データベース選択失敗");
			mysql_query("SET AUTOCOMMIT = 0");
			mysql_query("begin");
			try {
				error_log("-------------1--------------");
				$fp = fopen($tmp_name, 'rb');
				error_log("-------------2--------------");
				fgetcsv($fp);
				error_log("-------------3--------------");
				while ($row = fgetcsv($fp)) {
					//$count = recCount($pdo);
					error_log("-------------4--------------");
					$error = "";
					if($row === array(null)) {
					//　空行はスキップ
						continue;
					}
					array_unshift ($row, date("YmdHis").rand(10000, 99999));
					$row[] = $row[1].$row[3];
					if (count($row) !== 12) {
						throw new RuntimeException('データ項目数が誤っているデータがあります');
					} else if ($row[1] === "" or $row[2] === "" or $row[4] === "" or $row[6] === "" or $row[7] === "" or $row[8] === "") {
						if ($row[1] === "") {
							throw new RuntimeException("アカウントIDが反映されていないデータがあります");
						}
						if ($row[2] === "") {
							throw new RuntimeException("パスワードが反映されていないデータがあります");
						}
						if ($row[3] === "") {
							throw new RuntimeException("OP番号が反映されていないデータがあります");
						}
						if ($row[4] === "") {
							throw new RuntimeException("氏名が反映されていないデータがあります");
						}
						if ($row[6] === "") {
							throw new RuntimeException("権限が反映されていないデータがあります");
						}
						if ($row[7] === "") {
							throw new RuntimeException("作業者区分が反映されていないデータがあります");
						}
						if ($row[8] === "") {
							throw new RuntimeException("所属会社が反映されていないデータがあります");
						}
					} else {
						$executed = mysql_query(
								"INSERT INTO AccountData ( No,AccountId, Pass,Name,Class,Level,PriceGroup,Company,Area,Note,AddDate,AddTime,AddName)
								VALUES ('".$row[0]."', '".$row[1]."', '".$row[2]."', '".$row[4]."', '".$row[5]."', '".$row[6]."', 
									'".$row[7]."', '".$row[8]."', '".$row[9]."', '".$row[10]."', '".date("Y-m-d")."','".date("H:i:s")."','".$user_info->getUserName()."') 
								ON DUPLICATE KEY UPDATE
									No = '".$row[0]."', Pass = '".$row[2]."', Name = '".$row[4]."', Class = '".$row[5]."', 
									Level = '".$row[6]."', PriceGroup = '".$row[7]."', Company = '".$row[8]."', Area = '".$row[9]."', Note = '".$row[10]."',EditDate = '".date("Y-m-d")."',
									EditTime = '".date("H:i:s")."',
									EditName = '".$user_info->getUserName()."'"
						);
						$executed2 = mysql_query(
								"INSERT INTO AccountID_OPNo (No,AccountId, OPNo, ID_OPNo) 
								VALUES ('".$row[0]."', '".$row[1]."', '".$row[3]."', '".$row[1].$row[3]."')
								ON DUPLICATE KEY UPDATE
									No = '".$row[0]."', OPNo = '".$row[3]."', ID_OPNo = '".$row[1].$row[3]."'"
								);

						if(!$executed) {
							$error .= mysql_error($link);
						} else {
							$error = "OK";
						}
					}
					if ($error != "OK") {
						$accountID[] = $row[1];
						$accountPass[] = $row[2];
						$accountName[] = $row[4];
						$level[] = $row[6];
						$results[] = $error;
					}
				}  //while
				if(!feof($fp)) {
					throw new RuntimeException('読み込みの途中でエラーが発生しました');
				}
				fclose($fp);
				mysql_query("commit");
			} catch(Exception $e) {
				fclose($fp);
				mysql_query("rollback");
				throw $e;
			}
			if (isset($executed)) {
				//一回以上実行された
				$msg = array('green', '新規作成・更新成功');
			} else {
				//一回も実行されていない
				$msg = array('black', '新規作成・更新できるデータはありませんでした');
			}
		} catch (RuntimeException $e) {
			$msg = array('red', $e->getMessage());
		}
			
		$user_info = $app['session']->get('user_info');
		$data = array( 'user_info' => $user_info, 'msg' => $msg, 'accountID' => $accountID, 'accountPass' => $accountPass, 'accountName' => $accountName,
						'level' => $level, 'results' => $results);
		return $app['twig']->render('UploadCsvMembers.twig', $data);
	})
	->bind('UploadCsvMembers')
	->method('GET|POST');
	return $controllers;
	
}
}

