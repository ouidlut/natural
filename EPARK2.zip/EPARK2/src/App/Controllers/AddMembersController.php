<?php

namespace App\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ParameterBag;
use Silex\ControllerProviderInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\HttpFoundation\JsonResponse;

class AddMembersController implements ControllerProviderInterface
{
	public function connect(Application $app)
	{
		$controllers = $app['controllers_factory'];
		$user_info = $app['session']->get('user_info');

		$controllers->before(function (Request $request, Application $app) {
			$user_info = $app['session']->get('user_info');
			if (!$user_info) {
				return $app->redirect($app['url_generator']->generate('login'));
			}
			switch ($user_info->getLevel()) {
				case '事務局':
					break;
				case '管理者':
					break;
				case '一般':
					return $app->redirect($app['url_generator']->generate('home'));
					break;
			}
		});

		$controllers->match('/AddMembers', function (Request $request, Application $app) {
			$user_info = $app['session']->get('user_info');
			$data = array( 'user_info' => $user_info  );
			return $app['twig']->render('AddMembers.twig', $data);
		})
		->bind('AddMembers')
		->method('GET|POST');
		return $controllers;
	}
}
