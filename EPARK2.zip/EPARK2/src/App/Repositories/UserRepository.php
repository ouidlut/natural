<?php
namespace App\Repositories;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use App\Entities\LoginInfoEntity;
use App\Entities\UserEntity;
use App\Entities\NewUserEntity;
use Doctrine\DBAL\Connection;
use Symfony\Component\HttpFoundation\Session\Session;
use Carbon\Carbon;

class UserRepository implements RepositoryInterface
{

    protected $db;
    protected $uuid;

    public function __construct(Connection $db)
    {
        $this->db = $db;
    }

    public function saveNewUser(
      EntityInterface $entity,
      $tran = true,
      $date = null) {
      try {
        if ($tran) {
            $this->db->beginTransaction();
        }
        $sql = $this->insertNewUserSql();
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue('No', $entity->getId(), \PDO::PARAM_STR);
        $stmt->bindValue('name1', $entity->getName1(), \PDO::PARAM_STR);
        $stmt->bindValue('class', $entity->getClass(), \PDO::PARAM_STR);
        $stmt->bindValue('company', $entity->getCompany(), \PDO::PARAM_STR);
        $stmt->bindValue('email', $entity->getEmail(), \PDO::PARAM_STR);
        $stmt->execute();
        if ($tran) {
            $this->db->commit();
        }
        return true;
      } catch (\Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
      }
      }


    private function insertNewUserSql()
       {
         $sql = 'INSERT INTO AccountData ( '
                 . 'No, '
                 . 'Name, '
                 . 'Class, '
                 . 'Company, '
                 . 'EMail '
                 . ') VALUES ('
                 . ':No, '
                 . ':name1, '
                 . ':class,'
                 . ':company, '
                 . ':email '
                 . ')';
         return $sql;
       }

    public function findByIdAndPassword(EntityInterface $user_entity)
    {
        $account_id = $user_entity->getLoginId();
        $password = $user_entity->getPassword();
//        if($account_id==123 && $password==123)
//        {
//          $account_id =1087000;
//          $password=1234;
//        }
        try {
            $sql = 'SELECT * '
                 .'FROM AccountData '
                 .'WHERE AccountId = :account_id '
                 .'AND Pass = :password';
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam('account_id', $account_id, \PDO::PARAM_STR);
            $stmt->bindParam('password', $password, \PDO::PARAM_STR);
            $stmt->execute();
            $user_data = $stmt->fetchAll();
            if ($user_data) {
              $login_info = array(
              'user_id'   => $user_data[0]['AccountId'] ,
              'user_name' => $user_data[0]['Name'],
              'password'  => $user_data[0]['Pass'],
              'EMail'  => $user_data[0]['EMail'],
              'authority'  => $user_data[0]['authority'],
              'Level'  => $user_data[0]['Level'],
              'opno' => $user_data[0]['OPNo']
              );
            }
            return $user_data ? $this->buildUserInfo($login_info) : false;
        } catch (\Exception $e) {
            throw $e;
        }
    }

    /**
     * @param EntityInterface $entity
     */


     public function buildUserInfo(Array $paramaters = array())
    {
        $entity = new UserEntity;
        $entity->setProperties($paramaters);

        return $entity;
    }

    public function buildNewUserInfo(Array $paramaters = array())
   {
       $entity = new NewUserEntity;
       $entity->setProperties($paramaters);

       return $entity;
   }

     public function buildLoginInfoEntity(Array $paramaters = array())
    {
        $entity = new LoginInfoEntity;
        $entity->setProperties($paramaters);
        return $entity;
    }


    /**
     * @param EntityInterface $entity
     */
    public function add(EntityInterface $entity)
    {
        return;
    }
    /**
     * @param EntityInterface $entity
     */
    public function remove(EntityInterface $entity)
    {
        return;
    }
}
