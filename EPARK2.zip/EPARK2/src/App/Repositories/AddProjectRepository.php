<?php
namespace App\Repositories;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use App\Entities\AddProjectEntity;
use App\Entities\AllProjectsEntity;
use App\Entities\AllMembersEntity;
use App\Entities\UserDailyDataEntity;
use App\Entities\MonthDataEntity;
use App\Entities\MemberAddEntity;

use App\Entities\PmoEntity;
use Doctrine\DBAL\Connection;
use Symfony\Component\HttpFoundation\Session\Session;
use Carbon\Carbon;


/**
 *
 */
class AddProjectRepository  implements RepositoryInterface
{
  protected $db;
  protected $uuid;

  public function __construct(Connection $db)
  {
      $this->db = $db;
  }


  public function getnames( $tran = true)
  {
    try {
      if ($tran) {
             $this->db->beginTransaction();
         }
         $stmt =$this->db->prepare('SELECT * From AccountData WHERE LEVEL =\'管理者\'' );
         $stmt->execute();
         $allnames=$stmt->fetchAll();
         foreach ($allnames as $all_names) {
          $names[] = $this->BuildProject($all_names);
         }
         return $allnames ? $names : false;
    } catch (Exception $e) {
      if ($tran) {
          $this->db->rollBack();
      }
      throw $e;
    }

  }

  public function GetBudget( $tran = true)
  {
    try {
      if ($tran) {
             $this->db->beginTransaction();
         }
         $stmt =$this->db->prepare(
           'SELECT DISTINCT Accounting '
          .'FROM PMO '
          .'ORDER BY Accounting DESC'
          );
         $stmt->execute();
         $allbudget=$stmt->fetchAll();
         foreach ($allbudget as $all_budget) {
          $budget[] = $this->BuildProject($all_budget);
        }
         return $allbudget ? $budget : false;
    } catch (Exception $e) {
      if ($tran) {
          $this->db->rollBack();
      }
      throw $e;
    }

  }

  public function GetBusiness($tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
             $stmt =$this->db->prepare(
               'SELECT * '
              .' FROM BusinessType '
              .' GROUP BY BusinessType'
              );
             $stmt->execute();
             $allbusiness=$stmt->fetchAll();
             foreach ($allbusiness as $all_business) {
              $business[] = $this->BuildProject($all_business);
              }
             return $allbusiness ? $business : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }

  public function FindAllProjectListForConfirmation($tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
             $stmt =$this->db->prepare(
               'SELECT * '
              .' FROM ProjectData '
              .' WHERE ApprovaFlg = :ApprovaFlg '
              );
             $stmt->bindValue('ApprovaFlg', '仮登録', \PDO::PARAM_STR);
             $stmt->execute();
             $allprojects=$stmt->fetchAll();
             foreach ($allprojects as $projects) {
              $entity[] = $this->BuildNewProject($projects);
              }
             return $allprojects ? $entity : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }

    public function FindPMOMail(EntityInterface $result, $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
             $stmt =$this->db->prepare(
               'SELECT EMail '
               // 'SELECT * '
              .' FROM AccountData '
              .' WHERE AccountId = (SELECT pmo_mail
              FROM PMO where PMO = :pmo LIMIT 1) '
              );
             $stmt->bindValue('pmo', $result->getPMO(), \PDO::PARAM_STR);
             // $stmt->bindValue('BusinessType', $result->getBusinessType(), \PDO::PARAM_STR);
             $stmt->execute();
             $mail_id=$stmt->fetchAll();
             return $mail_id ? $this->builAddMember($mail_id[0]) : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }

    public function SearchIfProjectExists($ProjectCord, $tran = true){
        try {
             $stmt =$this->db->prepare(
               'SELECT ProjectCord '
              .' FROM ProjectData '
              .' WHERE ProjectCord = :ProjectCord '
              );
             $stmt->bindValue('ProjectCord', $ProjectCord, \PDO::PARAM_STR);
             $stmt->execute();
             $projectcode = $stmt->fetchAll();
             return $projectcode ? true : false;
        } catch (Exception $e) {
          throw $e;
        }
    }

  public function FindProjectDataSelectedForConfirmation(
      EntityInterface $project_id,
      $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
             $stmt =$this->db->prepare(
               ' SELECT * '
              .' FROM ProjectData '
              .' WHERE No = :No'
              );
             $stmt->bindValue('No', $project_id->getNo(), \PDO::PARAM_STR);
             $stmt->execute();
             $project_data=$stmt->fetchAll();
             return $project_data ? $this->BuildNewProject($project_data[0]) : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }

    public function FindOldProjectData(
      EntityInterface $project_id,
      $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
             $stmt =$this->db->prepare(
               ' SELECT * '
              .' FROM ProjectData '
              .' WHERE No = :No'
              );
             $stmt->bindValue('No', $project_id->getNo(), \PDO::PARAM_STR);
             $stmt->execute();
             $project_data=$stmt->fetchAll();
             return $project_data ? $this->BuildProjectCopy($project_data[0]) : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }
 public function FindTransferProjectData(
      EntityInterface $project_id,
      $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
             $stmt =$this->db->prepare(
               ' SELECT * '
              .' FROM ProjectData '
              .' WHERE ProjectCord = :projectcord'
              );
             $stmt->bindValue('projectcord', $project_id->getProjectCord(), \PDO::PARAM_STR);
             $stmt->execute();
             $project_data=$stmt->fetchAll();
             return $project_data ? $this->BuildProjectCopy($project_data[0]) : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }
    public function FindProjectBudget(
      EntityInterface $project_code,
      $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
             $stmt =$this->db->prepare(
               ' SELECT SUM(PTotalMoney) as PMoney '
              .' FROM MonthData2 '
              .' WHERE ProjectCord = :ProjectCord '
              .'AND ProjectCord = :ProjectCord '
              .'AND MemberY = :MemberY '
              );
            //  var_dump($project_code->getProjectCord());
            //  var_dump($project_code->getProject());
            //  var_dump($project_code->getyear());
            $stmt->bindValue('ProjectCord',$project_code->getProjectCord(), \PDO::PARAM_STR);
            $stmt->bindValue('Project',$project_code->getProject(), \PDO::PARAM_STR);
            $stmt->bindValue('MemberY',$project_code->getMemberY(), \PDO::PARAM_STR);
            $stmt->execute();
            $project_budget = $stmt->fetchAll();
             return $project_budget ? $this->BuildMemberData($project_budget[0]) : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }

  public function FindMonthTimeSumByProjectId(EntityInterface $project_data, $tran = true)
{
    try {
      if ($tran) {
             $this->db->beginTransaction();
         }
        $stmt = $this->db->prepare(
           'SELECT '
          .'(PTime1 + PTime2 + PTime3 + PTime4 + PTime5 + PTime6 + PTime7 + PTime8 + PTime9 + PTime10 + PTime11 + PTime12) AS PTime, '
          .'(PMoney1 + PMoney2 + PMoney3 + PMoney4 + PMoney5 + PMoney6 + PMoney7 + PMoney8 + PMoney9 + PMoney10 + PMoney11 + PMoney12) AS PMoney, '
          .'(Time1 + Time2 + Time3 + Time4 + Time5 + Time6 + Time7 + Time8 + Time9 + Time10 + Time11 + Time12) AS Time, '
          .'(Money1 + Money2 + Money3 + Money4 + Money5 + Money6 + Money7 + Money8 + Money9 + Money10 + Money11 + Money12) AS Money, '
          .' PTime1 , PTime2 , PTime3 ,PTime4 , PTime5 , PTime6 , PTime7 , PTime8 , PTime9 , PTime10 , PTime11 , PTime12, '
          .'PMoney1 , PMoney2,PMoney3,PMoney4,PMoney5,PMoney6,PMoney7,PMoney8,PMoney9,PMoney10,PMoney11,PMoney12, '
          .'Time1, Time2, Time3,Time4,Time5,Time6,Time7,Time8,Time9,Time10,Time11,Time12, '
          .'Money1,Money2,Money3,Money4,Money5,Money6,Money7,Money8,Money9,Money10,Money11,Money12, '
          .'AccountId, '
          .'Name, '
          // .'PriceGroup, '
          .'MemberY, '
          .'ProjectCord, '
          .'Project, '
          .'No '
          .'FROM MonthData2 '
          .'WHERE '
          .'('
          .'ProjectCord = :ProjectCord OR '
          .'Project = :Project '
          .')'
          .'AND MemberY = :MemberY '
          .'GROUP By AccountId'
          );
        $stmt->bindValue('ProjectCord',$project_data->getProjectCord(), \PDO::PARAM_STR);
        $stmt->bindValue('Project',$project_data->getProject(), \PDO::PARAM_STR);
        $stmt->bindValue('MemberY',$project_data->getyear(), \PDO::PARAM_STR);
        $stmt->execute();
        $all_months=$stmt->fetchAll();
        foreach ($all_months as $month) {
          $entity[] = $this->BuildMemberData($month);
        }
        return $all_months ? $entity : false;
    } catch (\Exception $e) {
        if ($tran) {
            $this->db->rollBack();
        }
        throw $e;
    }
}

  public function FindMemberDataSelectedForConfirmation(
      EntityInterface $project_data,
      $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
             $stmt =$this->db->prepare(
               ' SELECT * '
              .' FROM MonthData2 '
              .' WHERE ProjectCord = :ProjectCord'
              .' AND Project = :Project'
              );
             $stmt->bindValue('ProjectCord', $project_data->getProjectCord(), \PDO::PARAM_STR);
             $stmt->bindValue('Project', $project_data->getProject(), \PDO::PARAM_STR);
             $stmt->execute();
             $member_data=$stmt->fetchAll();
             foreach ($member_data as $member) {
              $entity[] = $this->BuildMemberAdd($member);
              }
             return $member_data ? $entity : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }

  public function DeleteMemberFromMonthlyData(EntityInterface $member_data, $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
            // $membery = date('Y');
            // if (date('m')<4) {
            //   $membery = $membery - 1;
            // }

             // $date = date('m',strtotime('2017-04'));
             // $membery = date('Y');
             //  if (date('m')<4) {
             //  $membery = $membery - 1;
             //  }
             // $membery = date('Y') - 1;
             $stmt =$this->db->prepare(
               'DELETE '
              .' FROM MonthData2 '
              .' WHERE AccountId = :AccountId'
              .' AND ProjectCord = :ProjectCord'

              );
             $stmt->bindValue('AccountId', $member_data->getAccountId(), \PDO::PARAM_STR);
             $stmt->bindValue('ProjectCord', $member_data->getProjectCord(), \PDO::PARAM_STR);
             $stmt->execute();
             if ($tran) {
                $this->db->commit();
                return true;
            }
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }

  public function GetBusinessData(
      EntityInterface $business_selected,
      $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
             $stmt =$this->db->prepare(
               ' SELECT Product '
              .' FROM BusinessType '
              .' WHERE BusinessType = :business'
              );
             $stmt->bindValue('business', $business_selected->getbusinesstype(), \PDO::PARAM_STR);
             $stmt->execute();
             $business_data=$stmt->fetchAll();
             foreach ($business_data as $business) {
              $entity[] = $this->BuildProject($business);
              }
             return $business_data ? $entity : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }

  public function GetUserData(
      EntityInterface $user_selected,
      $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
             $stmt =$this->db->prepare(
               ' SELECT Name, AccountId  '
              .' FROM AccountData '
              .' WHERE Name LIKE '.'\'%'.$user_selected->getName().'%\''
              .' OR AccountId LIKE '.'\'%'.$user_selected->getName().'%\' '
              .' GROUP BY AccountId LIMIT 10 '
              );
             $stmt->bindValue('name', $user_selected->getName(), \PDO::PARAM_STR);
             $stmt->execute();
             $user_data=$stmt->fetchAll();
             foreach ($user_data as $user) {
              $entity[] = $this->BuildUser($user);
              }
             return $user_data ? $entity : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }


  public function GetPmoData(
      EntityInterface $business_selected,
      $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
             $stmt =$this->db->prepare(
               ' SELECT * '
              .' FROM PMO '
              .' WHERE BusinessType = :business'
              );
             $stmt->bindValue('business', $business_selected->getBusinessType(), \PDO::PARAM_STR);
             $stmt->execute();
             $pmo_data=$stmt->fetchAll();
             foreach ($pmo_data as $pmo) {
              $entity[] = $this->BuildPmo($pmo);
              }
             return $pmo_data ? $entity : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }

  public function GetAccountData(
  EntityInterface $account_id,
  $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }

             $stmt =$this->db->prepare(
               ' SELECT * '
              .' FROM AccountData '
              .' WHERE AccountId = :account_id'
              .' LIMIT 1'
              );
             $stmt->bindValue('account_id', $account_id->getAccountId(), \PDO::PARAM_STR);
             $stmt->execute();
             $user_data=$stmt->fetchAll();
             foreach ($user_data as $user) {
              $entity[] = $this->builAddMember($user);
              }
              return $user_data ? $entity : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }

  public function GetMonthData(
  EntityInterface $account_id,
  $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
             $stmt =$this->db->prepare(
               ' SELECT * '
              .' FROM MonthData '
              .' WHERE AccountId = :account_id'
              );
             $stmt->bindValue('account_id', $account_id->getAccountId(), \PDO::PARAM_STR);
             $stmt->execute();
             $month_data=$stmt->fetchAll();
             foreach ($month_data as $month) {
              $entity[] = $this->BuildUserMonthData($month);
              }
              return $month_data ? $entity : false;
        } catch (Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
        }
    }

    /* 2017-06-26 Add */
    /* To Get Client(Project) List */
    /* パラメータ:プロジェクトコードを与えること。 */
    public function GetClientData(
      $ProjectCord,
      $user_opno, 
      $userid,
      $date,
      $tran = true)
    {
	try{
	  if ($tran) {
		$this->db->beginTransaction();
	  }

	  $project_cord = $ProjectCord['ClientNumber'];
	  //日報で作成済みのプロジェクトコード
	  $daily_project_cord = $this->GetProjectCordById($userid, $date);
	  $where2 = '';
	  if(count($daily_project_cord) !== 0) {
		$i = 1;
		foreach ($daily_project_cord as $value) {
			if (count($daily_project_cord) === $i) {
				$where2 = $where2.' ProjectCord NOT LIKE "'.$value.'" ';
			} else {
				$where2 = $where2.' ProjectCord NOT LIKE "'.$value.'" AND ';
			}
			$i++;
		}
		$where2 = ' AND ( '.$where2.' ) ';
	  }
	  $where = $this->CreateOPNoSql($user_opno);
	  $stmt = $this->db->prepare(
		 ' SELECT ProjectCord, Project, ArticleNo, StartDate, CloseDate, OPNo, Status, HouseName'
		.' FROM ProjectData '
		.' WHERE ProjectCord LIKE '.'\'%'.$project_cord.'%\' '
		.' AND Status NOT LIKE \'完了\' '
		.' AND Status NOT LIKE \'中止\' '
                	.' AND ( OPNo = \''.$user_opno[0].'\' '
		. $where. ' ) '.$where2
		);
	$stmt->execute();
	$client_data = $stmt->fetchAll();
	
	  //$stmt->bindValue('projectcord', $ProjectCord['ClientNumber'], \PDO::PARAM_STR);
//echo 'stmt'.PHP_EOL;
//var_dump($stmt);
	 
//echo 'c_data'.PHP_EOL;
//var_dump($client_data);
	  foreach ($client_data as $client) {
		//$entity[] = BuildProject($client);
	  }
//echo 'entity'.PHP_EOL;
//var_dump($entity);
	  return $client_data ? $client_data : false;
	}catch (Exception $e) {
	  if ($tran) {
		$this->db->rollBack();
	  }
	  throw $e;
	}
    }
    /* 2017-06-26 Add　ここまで  */

    public function CreateOPNoSql($user_opno) {
	$sql = "";
	for($i = 1; $i < count($user_opno); $i++) {
		$sql .= ' OR OPNo = \''.$user_opno[$i].'\' ';
	}
	return $sql;
    }

    /* 2017-07-24 Add */
    public function GetOPNoByClientID ($user_id, $tran = true) {
    	try{
		if ($tran) {
			$this->db->beginTransaction();
	  	}
	  	$stmt = $this->db->prepare(
		  ' SELECT OPNo'
		  .' FROM AccountID_OPNo'
		  .' WHERE AccountID = '.$user_id
		  );
	  	$stmt->execute();
		$OPNo = $this->array_column($stmt->fetchAll(), 'OPNo');
	  	return $OPNo ? $OPNo : false;
	} catch (Exception $e) {
		if ($tran) {
			$this->db->rollBack();
		}
		throw $e;
	}
    }
    /* 2017-07-24 Add ここまで  */

    public function GetProjectCordById($accountId, $date) {
	$stmt = $this->db->prepare('SELECT ProjectCord FROM DailyData WHERE AccountId LIKE :accountId and YM LIKE :date and UploadF LIKE 0');
	$stmt->bindValue('accountId', $accountId, \PDO::PARAM_STR);
	$stmt->bindValue('date', $date, \PDO::PARAM_STR);
	$stmt->execute();
	$result = $stmt->fetchAll();
	return $this->array_column($result, 'ProjectCord');
    }

    public function UpdateProjectBudget(
        EntityInterface $project_budget,
        EntityInterface $project_code,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            // var_dump($project_budget->getPMoney());
            // exit();
            $sql = $this->UpdateProjectBudgetSql();
            $stmt = $connection->prepare($sql);
            $stmt->bindValue('Budget', $project_budget->getPMoney(), \PDO::PARAM_STR);
            $stmt->bindValue('ProjectCord', $project_code->getProjectCord(), \PDO::PARAM_STR);
            $stmt->bindValue('ProjectY', $project_code->getMemberY(), \PDO::PARAM_STR);
            $stmt->bindValue('Project', $project_code->getProject(), \PDO::PARAM_STR);
            $stmt->bindValue('member_flag', '1', \PDO::PARAM_STR);
            $stmt->execute();
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }

  private function UpdateProjectBudgetSql()
  {
     $sql ='UPDATE ProjectData SET '
      . 'Budget = :Budget, '
      . 'member_flag = :member_flag '
      . 'WHERE ProjectCord = :ProjectCord '
      .'AND ProjectY = :ProjectY '
      .'AND Project = :Project';
      return $sql;
  }

    public function UpdateProjectStatusForConfirmation(
        EntityInterface $project_status,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            if ($project_status->getProjectCord()) {
              $sql = $this->UpdateProjectStatusWithProjectCordSql();
              $stmt = $connection->prepare($sql);
              $stmt->bindValue('ProjectCord', $project_status->getProjectCord(), \PDO::PARAM_STR);
            }
            else{
            $sql = $this->UpdateProjectStatusSql();
            $stmt = $connection->prepare($sql);
            }

            if ($project_status->getApprovaFlg()==='承認') {
              $stmt->bindValue(':Status', '開発中', \PDO::PARAM_INT);
            }
            elseif ($project_status->getApprovaFlg()==='未承認') {
              $stmt->bindValue(':Status', '差戻し', \PDO::PARAM_INT);
              
            }
            else{
             $stmt->bindValue(':Status', $project_status->getstatus(), \PDO::PARAM_INT); 
            }
            $stmt->bindValue(':ApprovaFlg', $project_status->getApprovaFlg(), \PDO::PARAM_INT);
            $stmt->bindValue(':No', $project_status->getNo(), \PDO::PARAM_INT);
            $stmt->execute();
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }

  private function UpdateProjectStatusSql()
  {
     $sql ='UPDATE ProjectData SET '
      . 'ApprovaFlg = :ApprovaFlg '
      . 'WHERE No = :No';
      return $sql;
  }

    private function UpdateProjectStatusWithProjectCordSql()
  {
     $sql ='UPDATE ProjectData SET '
      . 'ApprovaFlg = :ApprovaFlg, '
      . 'Status = :Status, '
      . 'ProjectCord = :ProjectCord '
      . 'WHERE No = :No';
      return $sql;
  }

    public function DeleteProjectEntryFromDatabase(
        EntityInterface $project_data,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {  
          if ($tran) {
            $connection->beginTransaction();
          }
          $sql = $this->DeleteProjectSql();
          $stmt = $connection->prepare($sql);
          $stmt->bindValue('ProjectCord', $project_data->getProjectCord(), \PDO::PARAM_STR);
          $stmt->bindValue(':No', $project_data->getNo(), \PDO::PARAM_INT);
          $stmt->execute();
          if ($tran) {
              $connection->commit();
              return true;
          }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }

  private function DeleteProjectSql()
  {
     $sql ='DELETE FROM ProjectData '
      . 'WHERE '
      . 'ProjectCord = :ProjectCord '
      . 'AND No = :No';
      return $sql;
  }

  public function UpdateMemberDataInProject(
        EntityInterface $member_data,
        EntityInterface $account_data,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            $sql = $this->UpdateMemberDataSql();
            $stmt = $connection->prepare($sql);
            $stmt->bindValue(':AccountId', $member_data->getAccountId(), \PDO::PARAM_INT);
            $stmt->bindValue(':MemberY', $member_data->getMemberY(), \PDO::PARAM_INT);
            $stmt->bindValue(':ProjectCord', $member_data->getProjectCord(), \PDO::PARAM_INT);
            $stmt->bindValue(':Project', $member_data->getProject(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime1', $member_data->getPTime1(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime2', $member_data->getPTime2(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime3', $member_data->getPTime3(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime4', $member_data->getPTime4(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime5', $member_data->getPTime5(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime6', $member_data->getPTime6(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime7', $member_data->getPTime7(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime8', $member_data->getPTime8(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime9', $member_data->getPTime9(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime10', $member_data->getPTime10(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime11', $member_data->getPTime11(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime12', $member_data->getPTime12(), \PDO::PARAM_INT);
            // if ($account_data->getPriceGroup() ==='人件費') {
            $stmt->bindValue(':PMoney1', $account_data->getPrice1()*$member_data->getPTime1(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney2', $account_data->getPrice2()*$member_data->getPTime2(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney3', $account_data->getPrice3()*$member_data->getPTime3(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney4', $account_data->getPrice4()*$member_data->getPTime4(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney5', $account_data->getPrice5()*$member_data->getPTime5(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney6', $account_data->getPrice6()*$member_data->getPTime6(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney7', $account_data->getPrice7()*$member_data->getPTime7(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney8', $account_data->getPrice8()*$member_data->getPTime8(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney9', $account_data->getPrice9()*$member_data->getPTime9(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney10', $account_data->getPrice10()*$member_data->getPTime10(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney11', $account_data->getPrice11()*$member_data->getPTime11(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney12', $account_data->getPrice12()*$member_data->getPTime12(), \PDO::PARAM_INT);
            // } else {
            // $stmt->bindValue(':PMoney1', $member_data->getPMoney1(), \PDO::PARAM_INT);
            // $stmt->bindValue(':PMoney2', $member_data->getPMoney2(), \PDO::PARAM_INT);
            // $stmt->bindValue(':PMoney3', $member_data->getPMoney3(), \PDO::PARAM_INT);
            // $stmt->bindValue(':PMoney4', $member_data->getPMoney4(), \PDO::PARAM_INT);
            // $stmt->bindValue(':PMoney5', $member_data->getPMoney5(), \PDO::PARAM_INT);
            // $stmt->bindValue(':PMoney6', $member_data->getPMoney6(), \PDO::PARAM_INT);
            // $stmt->bindValue(':PMoney7', $member_data->getPMoney7(), \PDO::PARAM_INT);
            // $stmt->bindValue(':PMoney8', $member_data->getPMoney8(), \PDO::PARAM_INT);
            // $stmt->bindValue(':PMoney9', $member_data->getPMoney9(), \PDO::PARAM_INT);
            // $stmt->bindValue(':PMoney10', $member_data->getPMoney10(), \PDO::PARAM_INT);
            // $stmt->bindValue(':PMoney11', $member_data->getPMoney11(), \PDO::PARAM_INT);
            // $stmt->bindValue(':PMoney12', $member_data->getPMoney12(), \PDO::PARAM_INT);
            // }

            $stmt->execute();
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }

  private function UpdateMemberDataSql()
  {
     $sql ='UPDATE MonthData2 SET '
      . 'PTime1 = :PTime1, '
      . 'PTime2 = :PTime2, '
      . 'PTime3 = :PTime3, '
      . 'PTime4 = :PTime4, '
      . 'PTime5 = :PTime5, '
      . 'PTime6 = :PTime6, '
      . 'PTime7 = :PTime7, '
      . 'PTime8 = :PTime8, '
      . 'PTime9 = :PTime9, '
      . 'PTime10 = :PTime10, '
      . 'PTime11 = :PTime11, '
      . 'PTime12 = :PTime12, '
      . 'PMoney1 = :PMoney1, '
      . 'PMoney2 = :PMoney2, '
      . 'PMoney3 = :PMoney3, '
      . 'PMoney4 = :PMoney4, '
      . 'PMoney5 = :PMoney5, '
      . 'PMoney6 = :PMoney6, '
      . 'PMoney7 = :PMoney7, '
      . 'PMoney8 = :PMoney8, '
      . 'PMoney9 = :PMoney9, '
      . 'PMoney10 = :PMoney10, '
      . 'PMoney11 = :PMoney11, '
      . 'PMoney12 = :PMoney12, '
      // . 'Time1 = :PTime1, '
      // . 'Time2 = :PTime2, '
      // . 'Time3 = :PTime3, '
      // . 'Time4 = :PTime4, '
      // . 'Time5 = :PTime5, '
      // . 'Time6 = :PTime6, '
      // . 'Time7 = :PTime7, '
      // . 'Time8 = :PTime8, '
      // . 'Time9 = :PTime9, '
      // . 'Time10 = :PTime10, '
      // . 'Time11 = :PTime11, '
      // . 'Time12 = :PTime12, '
      // . 'Money1 = :PMoney1, '
      // . 'Money2 = :PMoney2, '
      // . 'Money3 = :PMoney3, '
      // . 'Money4 = :PMoney4, '
      // . 'Money5 = :PMoney5, '
      // . 'Money6 = :PMoney6, '
      // . 'Money7 = :PMoney7, '
      // . 'Money8 = :PMoney8, '
      // . 'Money9 = :PMoney9, '
      // . 'Money10 = :PMoney10, '
      // . 'Money11 = :PMoney11, '
      // . 'PMoney12 = :PMoney12, '
      . 'PTotalTime = (:PTime1 + :PTime2 + :PTime3 + :PTime4 + :PTime5 + :PTime6 + :PTime7 + :PTime8 + :PTime9 + :PTime10 + :PTime11 + :PTime12), '
      . 'PTotalMoney = (:PMoney1 + :PMoney2 + :PMoney3 + :PMoney4 + :PMoney5 + :PMoney6 + :PMoney7 + :PMoney8 + :PMoney9 + :PMoney10 + :PMoney11 + :PMoney12) '
      // . 'TotalTime = (:PTime1 + :PTime2 + :PTime3 + :PTime4 + :PTime5 + :PTime6 + :PTime7 + :PTime8 + :PTime9 + :PTime10 + :PTime11 + :PTime12), '
      // . 'TotalMoney = (:PMoney1 + :PMoney2 + :PMoney3 + :PMoney4 + :PMoney5 + :PMoney6 + :PMoney7 + :PMoney8 + :PMoney9 + :PMoney10 + :PMoney11 + :PMoney12) '
      . 'WHERE (MemberY = :MemberY '
      . 'AND AccountId = :AccountId '
      . 'AND (ProjectCord = :ProjectCord OR Project = :Project ))';
      return $sql;
  }

  public function CopyOldProject(
        EntityInterface $old_project_data,
        EntityInterface $new_project_code,
        EntityInterface $user_info,
        EntityInterface $numberentity,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            $sql = $this->registerNewProjectSql();
            $stmt = $connection->prepare($sql);
            $stmt->bindValue(':no',number_format($numberentity->getNumber(),0,'.','') , \PDO::PARAM_INT);
            $stmt->bindValue(':ProjectY', $year, \PDO::PARAM_INT);
            $stmt->bindValue('projectcord', $new_project_code->getProjectCord(), \PDO::PARAM_STR);
            $stmt->bindValue('project', $old_project_data->getProject(), \PDO::PARAM_STR);
            $stmt->bindValue('status', $old_project_data->getPStatus(), \PDO::PARAM_STR);
	    $stmt->bindValue('ArticleNo', $old_project_data->getArticleNo(), \PDO::PARAM_STR);
            $stmt->bindValue('business_type', $old_project_data->getBusinessType(), \PDO::PARAM_STR);
            $stmt->bindValue('custodian', $old_project_data->getCustodian(), \PDO::PARAM_STR);
            $stmt->bindValue('accounting', $old_project_data->getAccounting(), \PDO::PARAM_STR);
            $stmt->bindValue('budget', $old_project_data->getBudget(), \PDO::PARAM_STR);
            $stmt->bindValue('plan_date', $old_project_data->getPlanDate(), \PDO::PARAM_STR);
            $stmt->bindValue('add_date', date('Y-m-d'), \PDO::PARAM_STR);
            $stmt->bindValue('add_time', date('H:i'), \PDO::PARAM_STR);
            $stmt->bindValue('add_name', $user_info->getUserName(), \PDO::PARAM_STR);
            $stmt->bindValue('edit_date', date('Y-m-d'), \PDO::PARAM_STR);
            $stmt->bindValue('edit_time', date('H:i'), \PDO::PARAM_STR);
            $stmt->bindValue('edit_name', $user_info->getUserName(), \PDO::PARAM_STR);
            $stmt->bindValue('note1', $old_project_data->getNote1(), \PDO::PARAM_STR);
            $stmt->bindValue('note2', $old_project_data->getNote2(), \PDO::PARAM_STR);
            $stmt->bindValue('approval_flag', $old_project_data->getApprovaFlg(), \PDO::PARAM_STR);
            $stmt->bindValue('member_flag', '0', \PDO::PARAM_STR);
            $stmt->bindValue('product', $old_project_data->getProduct(), \PDO::PARAM_STR);
            $stmt->bindValue('pmo', $old_project_data->getPMO(), \PDO::PARAM_STR);
            $stmt->execute();
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }



    public function registerNewProject(
        EntityInterface $project_data,
        EntityInterface $user_info,
        EntityInterface $numberentity,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            $sql = $this->registerNewProjectSql();
            $stmt = $connection->prepare($sql);
            $month = intval(date('m'));
            $year = date('Y');
            if ($month<4) {
              $year = $year - 1;
            }
            $stmt->bindValue(':no',number_format($numberentity->getNumber(),0,'.','') , \PDO::PARAM_INT);
            $stmt->bindValue(':ProjectY', $year, \PDO::PARAM_INT);
            $stmt->bindValue('projectcord', $project_data->getProjectCord(), \PDO::PARAM_STR);
            $stmt->bindValue('project', $project_data->getProject(), \PDO::PARAM_STR);
            $stmt->bindValue('status', '未着手', \PDO::PARAM_STR);
	    $stmt->bindValue(':ArticleNo', $project_data->getArticleNo(), \PDO::PARAM_STR);
            $stmt->bindValue('business_type', $project_data->getBusinessType(), \PDO::PARAM_STR);
            $stmt->bindValue('custodian', $project_data->getCustodian(), \PDO::PARAM_STR);
            //$stmt->bindValue('accounting', $project_data->getAccounting(), \PDO::PARAM_STR);
            //$stmt->bindValue('budget', $project_data->getBudget(), \PDO::PARAM_STR);
            //$stmt->bindValue('plan_date', $project_data->getPlanDate(), \PDO::PARAM_STR);
	    //$stmt->bindValue('close_date', $project_data->getCloseDate(), \PDO::PARAM_STR);
            $stmt->bindValue('add_date', date('Y-m-d'), \PDO::PARAM_STR);
            $stmt->bindValue('add_time', date('H:i'), \PDO::PARAM_STR);
            $stmt->bindValue('add_name', $user_info->getUserName(), \PDO::PARAM_STR);
            $stmt->bindValue('edit_date', date('Y-m-d'), \PDO::PARAM_STR);
            $stmt->bindValue('edit_time', date('H:i'), \PDO::PARAM_STR);
            $stmt->bindValue('edit_name', $user_info->getUserName(), \PDO::PARAM_STR);
            //$stmt->bindValue('note1', $project_data->getNote1(), \PDO::PARAM_STR);
            //$stmt->bindValue('note2', $project_data->getNote2(), \PDO::PARAM_STR);
            $stmt->bindValue('approval_flag', '仮登録', \PDO::PARAM_STR);
            //$stmt->bindValue('product', $project_data->getProduct(), \PDO::PARAM_STR);
            $stmt->bindValue('member_flag', '0', \PDO::PARAM_STR);
            //$stmt->bindValue('pmo', $project_data->getPMO(), \PDO::PARAM_STR);
	    $stmt->bindValue('OPNo', $user_info->getOpno(), \PDO::PARAM_STR);
	    $stmt->bindValue('OP_ArticleNo', $user_info->getOpno().$project_data->getArticleNo(), \PDO::PARAM_STR);
            $stmt->execute();
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }



        private function registerNewProjectSql()
        {
          $sql = 'INSERT INTO `ProjectData` ('
            . 'No, '
            . 'ProjectY, '
            . 'ProjectCord, '
            . 'Project, '
            . 'Status, '
	    . 'ArticleNo, '
            . 'BusinessType, '
            . 'Custodian, '
            //. 'Budget, '
	    //. 'CloseDate,'
            //. 'Accounting, '
            . 'AddDate, '
            . 'AddTime, '
            . 'AddName, '
            . 'EditDate, '
            . 'EditTime, '
            . 'EditName, '
            //. 'Note1, '
            //. 'Note2, '
            . 'ApprovaFlg, '
            //. 'Product, '
            . 'member_flag, '
            //. 'PMO, '
	    . 'OPNo, '
	    . 'OP_ArticleNo'
            . ') '
             .'VALUES ('
            . ':no, '
            . ':ProjectY, '
            . ':projectcord,  '
            . ':project, '
            . ':status, '
	    . ':ArticleNo, '
            . ':business_type, '
            . ':custodian, '
            //. ':budget, '
	    //. ':close_date, '
            //. ':accounting, '
            . ':add_date, '
            . ':add_time, '
            . ':add_name, '
            . ':edit_date, '
            . ':edit_time, '
            . ':edit_name, '
            //. ':note1, '
            //. ':note2, '
            . ':approval_flag, '
            //. ':product, '
            . ':member_flag, '
            //. ':pmo, '
	    . ':OPNo, '
	    . ':OP_ArticleNo '
            // . ':ngflag, '
            .')';
        return $sql;
        }

  public function SearchFromMonthlyData(
    EntityInterface $member_data,
    EntityInterface $account_data,
    $tran = true,
    $date = null)
  {
    try {
      if ($tran) {
             $this->db->beginTransaction();
         }
         $stmt =$this->db->prepare(
           'SELECT * '
          .'FROM MonthData2 '
          .'WHERE AccountId = :AccountId '
          .'AND ProjectCord = :ProjectCord '
          .'AND (ProjectNo = :No OR Project = :Project ) '
          );
         $stmt->bindValue(':AccountId', $member_data->getAccountId(), \PDO::PARAM_INT);
         $stmt->bindValue(':No', $member_data->getNumber(), \PDO::PARAM_INT);
         $stmt->bindValue(':ProjectCord', $member_data->getProjectCord(), \PDO::PARAM_STR);
         $stmt->bindValue(':Project', $member_data->getProject(), \PDO::PARAM_STR);
         
         $stmt->execute();
         $monthlydata=$stmt->fetchAll();
         return $monthlydata ? true : false;
    } catch (Exception $e) {
      if ($tran) {
          $this->db->rollBack();
      }
      throw $e;
    }

  }

//  public function CopyOldMember(
//        EntityInterface $old_project_data,
//        EntityInterface $new_project_code,
//        EntityInterface $member,
//        EntityInterface $numberentity,
//        $connection,
//        $tran = true,
//        $date = null
//    ) {
//        if ($date === null) {
//            $date = date('Y-m-d H:i;s');
//        }
//        try {
//            if ($tran) {
//                $connection->beginTransaction();
//            }
//            $no = $this->GetRandomNumber();
//            if ($member->getMemberY()) {
//              $membery = $member->getMemberY();
//            }
//            else{
//              $membery = date('Y');
//            if (date('m')<4) {
//              $membery = $membery - 1;
//            }
//            }
//            $sql = $this->InsertIntoMonthlyDataSql();
//
//
//            $stmt = $connection->prepare($sql);
//            $stmt->bindValue(':no', $no, \PDO::PARAM_INT);
//            $stmt->bindValue(':AccountId', $member->getAccountId(), \PDO::PARAM_INT);
//            $stmt->bindValue(':Name',  $member->getName(), \PDO::PARAM_INT);
//            $stmt->bindValue(':MemberY',  $membery, \PDO::PARAM_INT);
//            $stmt->bindValue(':ProjectCord', $new_project_code->getProjectCord(), \PDO::PARAM_INT);
//            $stmt->bindValue(':ProjectNo', number_format($numberentity->getNumber(),0,'.',''), \PDO::PARAM_INT);
//            $stmt->bindValue(':Project', $member->getProject(), \PDO::PARAM_INT);
//
//
//            $stmt->bindValue(':PTime1', $member->getPTime1(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PTime2', $member->getPTime2(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PTime3', $member->getPTime3(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PTime4', $member->getPTime4(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PTime5', $member->getPTime5(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PTime6', $member->getPTime6(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PTime7', $member->getPTime7(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PTime8', $member->getPTime8(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PTime9', $member->getPTime9(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PTime10', $member->getPTime10(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PTime11', $member->getPTime11(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PTime12', $member->getPTime12(), \PDO::PARAM_INT);
//            // if ($account_data->getPriceGroup() ==='人件費') {
//            // $stmt->bindValue(':PMoney1', $account_data->getPrice1()*$member_data->getPTime1(), \PDO::PARAM_INT);
//            // $stmt->bindValue(':PMoney2', $account_data->getPrice2()*$member_data->getPTime2(), \PDO::PARAM_INT);
//            // $stmt->bindValue(':PMoney3', $account_data->getPrice3()*$member_data->getPTime3(), \PDO::PARAM_INT);
//            // $stmt->bindValue(':PMoney4', $account_data->getPrice4()*$member_data->getPTime4(), \PDO::PARAM_INT);
//            // $stmt->bindValue(':PMoney5', $account_data->getPrice5()*$member_data->getPTime5(), \PDO::PARAM_INT);
//            // $stmt->bindValue(':PMoney6', $account_data->getPrice6()*$member_data->getPTime6(), \PDO::PARAM_INT);
//            // $stmt->bindValue(':PMoney7', $account_data->getPrice7()*$member_data->getPTime7(), \PDO::PARAM_INT);
//            // $stmt->bindValue(':PMoney8', $account_data->getPrice8()*$member_data->getPTime8(), \PDO::PARAM_INT);
//            // $stmt->bindValue(':PMoney9', $account_data->getPrice9()*$member_data->getPTime9(), \PDO::PARAM_INT);
//            // $stmt->bindValue(':PMoney10', $account_data->getPrice10()*$member_data->getPTime10(), \PDO::PARAM_INT);
//            // $stmt->bindValue(':PMoney11', $account_data->getPrice11()*$member_data->getPTime11(), \PDO::PARAM_INT);
//            // $stmt->bindValue(':PMoney12', $account_data->getPrice12()*$member_data->getPTime12(), \PDO::PARAM_INT);
//            // } else {
//            $stmt->bindValue(':PMoney1', $member->getPMoney1(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PMoney2', $member->getPMoney2(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PMoney3', $member->getPMoney3(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PMoney4', $member->getPMoney4(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PMoney5', $member->getPMoney5(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PMoney6', $member->getPMoney6(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PMoney7', $member->getPMoney7(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PMoney8', $member->getPMoney8(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PMoney9', $member->getPMoney9(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PMoney10', $member->getPMoney10(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PMoney11', $member->getPMoney11(), \PDO::PARAM_INT);
//            $stmt->bindValue(':PMoney12', $member->getPMoney12(), \PDO::PARAM_INT);
//            // }
//
//            $stmt->execute();
//            if ($tran) {
//                $connection->commit();
//                return $no;
//            }
//        } catch (\Exception $e) {
//            if ($tran) {
//                $connection->rollBack();
//                throw $e;
//            }
//            return false;
//        }
//    }
 public function CopyOldMember(
        EntityInterface $old_project_data,
        EntityInterface $transfer_project_data,
        EntityInterface $user_info,
        EntityInterface $numberentity,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            $sql = 'UPDATE `MonthData2` SET '
            .'ProjectNo = :projectno, '
            .'ProjectCord = :projectcord, '
            .'Project = :project '
            .'WHERE No = :no';
            $stmt = $connection->prepare($sql);
            $stmt->bindValue(':projectno',number_format($transfer_project_data->getNo(),0,'.',''),\PDO::PARAM_INT);
            $stmt->bindValue(':projectcord', $transfer_project_data->getProjectCord(), \PDO::PARAM_STR);
            $stmt->bindValue(':project', $transfer_project_data->getProject(), \PDO::PARAM_STR);
            $stmt->bindValue(':no', $user_info->getNumber(), \PDO::PARAM_STR);
            $stmt->execute();

            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    } 

    public function InsertIntoMonthlyData(
        EntityInterface $member_data,
        EntityInterface $account_data,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            $no = $this->GetRandomNumber();
            if ($member_data->getMemberY()) {
              $membery = $member_data->getMemberY();
            }
            else{
              $membery = date('Y');
            if (intval(date('m')<4)) {
              $membery = $membery - 1;
            }
            }
            $sql = $this->InsertIntoMonthlyDataSql();
            $stmt = $connection->prepare($sql);
            $stmt->bindValue(':no', $no, \PDO::PARAM_INT);
            $stmt->bindValue(':AccountId', $account_data->getAccountId(), \PDO::PARAM_INT);
            $stmt->bindValue(':Name',  $account_data->getName(), \PDO::PARAM_INT);
            $stmt->bindValue(':MemberY',  $membery, \PDO::PARAM_INT);
            $stmt->bindValue(':ProjectCord', $member_data->getProjectCord(), \PDO::PARAM_INT);
            $stmt->bindValue(':ProjectNo', $member_data->getNumber(), \PDO::PARAM_INT);
            $stmt->bindValue(':Project', $member_data->getProject(), \PDO::PARAM_INT);


            $stmt->bindValue(':PTime1', $member_data->getPTime1(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime2', $member_data->getPTime2(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime3', $member_data->getPTime3(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime4', $member_data->getPTime4(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime5', $member_data->getPTime5(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime6', $member_data->getPTime6(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime7', $member_data->getPTime7(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime8', $member_data->getPTime8(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime9', $member_data->getPTime9(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime10', $member_data->getPTime10(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime11', $member_data->getPTime11(), \PDO::PARAM_INT);
            $stmt->bindValue(':PTime12', $member_data->getPTime12(), \PDO::PARAM_INT);
            if ($account_data->getPriceGroup() ==='人件費') {
            $stmt->bindValue(':PMoney1', $account_data->getPrice1()*$member_data->getPTime1(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney2', $account_data->getPrice2()*$member_data->getPTime2(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney3', $account_data->getPrice3()*$member_data->getPTime3(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney4', $account_data->getPrice4()*$member_data->getPTime4(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney5', $account_data->getPrice5()*$member_data->getPTime5(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney6', $account_data->getPrice6()*$member_data->getPTime6(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney7', $account_data->getPrice7()*$member_data->getPTime7(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney8', $account_data->getPrice8()*$member_data->getPTime8(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney9', $account_data->getPrice9()*$member_data->getPTime9(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney10', $account_data->getPrice10()*$member_data->getPTime10(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney11', $account_data->getPrice11()*$member_data->getPTime11(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney12', $account_data->getPrice12()*$member_data->getPTime12(), \PDO::PARAM_INT);
            } else {
            $stmt->bindValue(':PMoney1', $member_data->getPMoney1(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney2', $member_data->getPMoney2(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney3', $member_data->getPMoney3(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney4', $member_data->getPMoney4(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney5', $member_data->getPMoney5(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney6', $member_data->getPMoney6(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney7', $member_data->getPMoney7(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney8', $member_data->getPMoney8(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney9', $member_data->getPMoney9(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney10', $member_data->getPMoney10(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney11', $member_data->getPMoney11(), \PDO::PARAM_INT);
            $stmt->bindValue(':PMoney12', $member_data->getPMoney12(), \PDO::PARAM_INT);
            }
            $stmt->execute();
            if ($tran) {
                $connection->commit();
                return $no;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }

    private function InsertIntoMonthlyDataSql()
        {
          $sql = 'INSERT INTO `MonthData2` ('
            . '`No`, '
            . 'AccountId, '
            . 'Name, '
            . 'MemberY, '
            . 'ProjectCord, '
            . 'ProjectNo, '
            . 'Project, '

            . 'Time1, '
            . 'Time2, '
            . 'Time3, '
            . 'Time4, '
            . 'Time5, '
            . 'Time6, '
            . 'Time7, '
            . 'Time8, '
            . 'Time9, '
            . 'Time10, '
            . 'Time11, '
            . 'Time12, '

            . 'PTime1, '
            . 'PTime2, '
            . 'PTime3, '
            . 'PTime4, '
            . 'PTime5, '
            . 'PTime6, '
            . 'PTime7, '
            . 'PTime8, '
            . 'PTime9, '
            . 'PTime10, '
            . 'PTime11, '
            . 'PTime12, '

            . 'PMoney1, '
            . 'PMoney2, '
            . 'PMoney3, '
            . 'PMoney4, '
            . 'PMoney5, '
            . 'PMoney6, '
            . 'PMoney7, '
            . 'PMoney8, '
            . 'PMoney9, '
            . 'PMoney10, '
            . 'PMoney11, '
            . 'PMoney12, '

            . 'Money1, '
            . 'Money2, '
            . 'Money3, '
            . 'Money4, '
            . 'Money5, '
            . 'Money6, '
            . 'Money7, '
            . 'Money8, '
            . 'Money9, '
            . 'Money10, '
            . 'Money11, '
            . 'Money12, '
            . 'TotalTime, '
            . 'PTotalTime, '
            . 'TotalMoney, '
            . 'PTotalMoney '
            // . 'ProjectCord, '
            . ') '
             .'VALUES ('
            . ':no, '
            . ':AccountId,  '
            . ':Name,  '
            . ':MemberY,  '
            . ':ProjectCord,  '
            . ':ProjectNo,  '
            . ':Project,  '
            . ':PTime1,  '
            . ':PTime2,  '
            . ':PTime3,  '
            . ':PTime4,  '
            . ':PTime5,  '
            . ':PTime6,  '
            . ':PTime7,  '
            . ':PTime8,  '
            . ':PTime9,  '
            . ':PTime10,  '
            . ':PTime11,  '
            . ':PTime12,  '
                                        //currently Time1- Time12 have same value as PTime1 - PTime12
            . ':PTime1,  '
            . ':PTime2,  '
            . ':PTime3,  '
            . ':PTime4,  '
            . ':PTime5,  '
            . ':PTime6,  '
            . ':PTime7,  '
            . ':PTime8,  '
            . ':PTime9,  '
            . ':PTime10,  '
            . ':PTime11,  '
            . ':PTime12,  '

            . ':PMoney1,  '
            . ':PMoney2,  '
            . ':PMoney3,  '
            . ':PMoney4,  '
            . ':PMoney5,  '
            . ':PMoney6,  '
            . ':PMoney7,  '
            . ':PMoney8,  '
            . ':PMoney9,  '
            . ':PMoney10,  '
            . ':PMoney11,  '
            . ':PMoney12,  '
                                //currently Money values are also same as Pmoney Money starts from below
            . ':PMoney1,  '
            . ':PMoney2,  '
            . ':PMoney3,  '
            . ':PMoney4,  '
            . ':PMoney5,  '
            . ':PMoney6,  '
            . ':PMoney7,  '
            . ':PMoney8,  '
            . ':PMoney9,  '
            . ':PMoney10,  '
            . ':PMoney11,  '
            . ':PMoney12,  '

            . ':PTime1 + :PTime2 + :PTime3 + :PTime4 + :PTime5 + :PTime6 + :PTime7 + :PTime8 + :PTime9 + :PTime10 + :PTime11 + :PTime12 , '
            . ':PTime1 + :PTime2 + :PTime3 + :PTime4 + :PTime5 + :PTime6 + :PTime7 + :PTime8 + :PTime9 + :PTime10 + :PTime11 + :PTime12 , '

            . ':PMoney1 + :PMoney2 + :PMoney3 + :PMoney4 + :PMoney5 + :PMoney6 + '
            . ':PMoney7 + :PMoney8 + :PMoney9 + :PMoney10 + :PMoney11 + :PMoney1 , '

            . ':PMoney1 + :PMoney2 + :PMoney3 + :PMoney4 + :PMoney5 + :PMoney6 + '
            . ':PMoney7 + :PMoney8 + :PMoney9 + :PMoney10 + :PMoney11 + :PMoney1  '

            .')';
        return $sql;
        }

  function array_column($input = null, $columnKey = null, $indexKey = null)
    {
        // Using func_get_args() in order to check for proper number of
        // parameters and trigger errors exactly as the built-in array_column()
        // does in PHP 5.5.
        $argc = func_num_args();
        $params = func_get_args();
        if ($argc < 2) {
            trigger_error("array_column() expects at least 2 parameters, {$argc} given", E_USER_WARNING);
            return null;
        }
        if (!is_array($params[0])) {
            trigger_error(
                'array_column() expects parameter 1 to be array, ' . gettype($params[0]) . ' given',
                E_USER_WARNING
            );
            return null;
        }
        if (!is_int($params[1])
            && !is_float($params[1])
            && !is_string($params[1])
            && $params[1] !== null
            && !(is_object($params[1]) && method_exists($params[1], '__toString'))
        ) {
            trigger_error('array_column(): The column key should be either a string or an integer', E_USER_WARNING);
            return false;
        }
        if (isset($params[2])
            && !is_int($params[2])
            && !is_float($params[2])
            && !is_string($params[2])
            && !(is_object($params[2]) && method_exists($params[2], '__toString'))
        ) {
            trigger_error('array_column(): The index key should be either a string or an integer', E_USER_WARNING);
            return false;
        }
        $paramsInput = $params[0];
        $paramsColumnKey = ($params[1] !== null) ? (string) $params[1] : null;
        $paramsIndexKey = null;
        if (isset($params[2])) {
            if (is_float($params[2]) || is_int($params[2])) {
                $paramsIndexKey = (int) $params[2];
            } else {
                $paramsIndexKey = (string) $params[2];
            }
        }
        $resultArray = array();
        foreach ($paramsInput as $row) {
            $key = $value = null;
            $keySet = $valueSet = false;
            if ($paramsIndexKey !== null && array_key_exists($paramsIndexKey, $row)) {
                $keySet = true;
                $key = (string) $row[$paramsIndexKey];
            }
            if ($paramsColumnKey === null) {
                $valueSet = true;
                $value = $row;
            } elseif (is_array($row) && array_key_exists($paramsColumnKey, $row)) {
                $valueSet = true;
                $value = $row[$paramsColumnKey];
            }
            if ($valueSet) {
                if ($keySet) {
                    $resultArray[$key] = $value;
                } else {
                    $resultArray[] = $value;
                }
            }
        }
        return $resultArray;
    }

  public function GetRandomNumber()
  {
    $randnum = rand(100000,999999);
    $date= date("YmdHis");
    $no = $date*100000+$randnum;
    return $no;
  }

  public function BuildUser($parameter)
  {
    $entity = new UserDailyDataEntity;
    $entity->setProperties($parameter);
    return $entity;
  }

  public function BuildProject($parameter)
  {
    $entity = new AddProjectEntity;
    $entity->setProperties($parameter);
    return $entity;
  }

    public function BuildMemberAdd($parameter)
  {
    $entity = new MemberAddEntity;
    $entity->setProperties($parameter);
    if (array_key_exists('PTime1', $parameter)) {
            $entity->setPTime1(mb_convert_kana(
                $parameter['PTime1'],
                'kVas',
                'UTF-8'
            ));
    }
    if (array_key_exists('PTime2', $parameter)) {
            $entity->setPTime2(mb_convert_kana(
                $parameter['PTime2'],
                'kVas',
                'UTF-8'
            ));
    }

    if (array_key_exists('PTime3', $parameter)) {
            $entity->setPTime3(mb_convert_kana(
                $parameter['PTime3'],
                'kVas',
                'UTF-8'
            ));
    }

    if (array_key_exists('PTime4', $parameter)) {
            $entity->setPTime4(mb_convert_kana(
                $parameter['PTime4'],
                'kVas',
                'UTF-8'
            ));
    }

    if (array_key_exists('PTime5', $parameter)) {
            $entity->setPTime5(mb_convert_kana(
                $parameter['PTime5'],
                'kVas',
                'UTF-8'
            ));
    }

    if (array_key_exists('PTime6', $parameter)) {
            $entity->setPTime6(mb_convert_kana(
                $parameter['PTime6'],
                'kVas',
                'UTF-8'
            ));
    }

    if (array_key_exists('PTime7', $parameter)) {
            $entity->setPTime7(mb_convert_kana(
                $parameter['PTime7'],
                'kVas',
                'UTF-8'
            ));
    }

    if (array_key_exists('PTime8', $parameter)) {
            $entity->setPTime8(mb_convert_kana(
                $parameter['PTime8'],
                'kVas',
                'UTF-8'
            ));
    }

    if (array_key_exists('PTime9', $parameter)) {
            $entity->setPTime9(mb_convert_kana(
                $parameter['PTime9'],
                'kVas',
                'UTF-8'
            ));
    }

    if (array_key_exists('PTime10', $parameter)) {
            $entity->setPTime10(mb_convert_kana(
                $parameter['PTime10'],
                'kVas',
                'UTF-8'
            ));
    }

    if (array_key_exists('PTime11', $parameter)) {
            $entity->setPTime11(mb_convert_kana(
                $parameter['PTime11'],
                'kVas',
                'UTF-8'
            ));
    }

    if (array_key_exists('PTime12', $parameter)) {
            $entity->setPTime12(mb_convert_kana(
                $parameter['PTime12'],
                'kVas',
                'UTF-8'
            ));
    }
    return $entity;
  }

  public function BuildMonthData($parameter)
  {
    $entity = new AddProjectEntity;
    $entity->setProperties($parameter);
    return $entity;
  }

  public function BuildNewProject($parameter)
  {
    $entity = new AllProjectsEntity;
    $entity->setProperties($parameter);
    return $entity;
  }

  public function BuildProjectCopy($parameter)
  {
    $entity = new AllProjectsEntity;
    $entity->setProperties($parameter);
    if (array_key_exists('ProjectY', $parameter)) 
    {
        $entity->setYear($parameter['ProjectY']);
    }
    // if (array_key_exists('Status', $parameter)) 
    // {
    //     $entity->setStatus($parameter['Status']);
    // }
    return $entity;
  }

  public function BuildUserMonthData($parameter)
  {
    $entity = new MonthDataEntity;
    $entity->setProperties($parameter);
    return $entity;
  }


  public function builAddMember($parameter)
  {
    $entity = new AllMembersEntity;
    $entity->setProperties($parameter);
    return $entity;
  }

public function BuildMemberData($paramaters)
{
  $entity = new MemberAddEntity;
  $entity->setProperties($paramaters);
  return $entity;
}

  public function BuildPmo($parameter)
  {
    $entity = new PmoEntity;
    $entity->setProperties($parameter);
    return $entity;
  }

  public function add(EntityInterface $entity)
  {
      return;
  }
  /**
   * @param EntityInterface $entity
   */
  public function remove(EntityInterface $entity)
  {
      return;
  }

}
