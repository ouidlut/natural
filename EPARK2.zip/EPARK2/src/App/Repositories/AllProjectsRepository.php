<?php
namespace App\Repositories;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use App\Entities\LoginInfoEntity;
use App\Entities\UserEntity;
use App\Entities\UserProjectsEntity;
use App\Entities\MemberAddEntity;
use App\Entities\UserDailyDataEntity;
use App\Entities\AllProjectsEntity;
use App\Entities\NewUserEntity;
use App\Entities\MonthDataEntity;
use Doctrine\DBAL\Connection;
use Symfony\Component\HttpFoundation\Session\Session;
use Carbon\Carbon;


class AllProjectsRepository implements RepositoryInterface
{

  protected $db;
  protected $uuid;

  public function __construct(Connection $db)
  {
      $this->db = $db;
  }

  public function FindAllProjectsbyYearandStatus(AllProjectsEntity $year_status, UserEntity $user_info, $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }

	    $id = $user_info->getLoginId();
	    $stmt3 = $this->db->prepare('SELECT OPNo FROM AccountID_OPNo WHERE AccountID = :AccountID');
	    $stmt3->bindValue('AccountID', $id, \PDO::PARAM_STR);
	    $stmt3->execute();
	    $opno = $this->array_column($stmt3->fetchAll(), 'OPNo');
	    $where = ' (OPNo LIKE :OPNo ';
	    for ($i = 1; $i < count($opno); $i++) {
		$where = $where.' OR OPNo LIKE :OPNo'.$i;
	    }
	    $where = $where.') ';
            $stmt = $this->db->prepare(
               'SELECT * FROM ProjectData '
              .'WHERE (ProjectY = :ProjectY '
              .'AND Status = :Status) '
	      .'AND '.$where
              .'ORDER BY ProjectCord'
              );
            $stmt->bindValue('ProjectY',$year_status->getyear(), \PDO::PARAM_STR);
            $stmt->bindValue('Status',$year_status->getstatus(), \PDO::PARAM_STR);
	    $stmt->bindValue('OPNo' ,$opno[0], \PDO::PARAM_STR);
	    for ($i = 1; $i < count($opno); $i++) {
		$stmt->bindValue('OPNo'.$i, $opno[$i], \PDO::PARAM_STR);
	    }
            $stmt->execute();
            $allprojects=$stmt->fetchAll();
            foreach ($allprojects as $all_project) {
              $projects[] = $this->BuildAllProjects($all_project);
              }
              if ($allprojects) {
            foreach ($projects as $project) {

               $stmt2 = $this->db->prepare(
               'SELECT '
              .'SUM(Time1) as Time1, '
              .'SUM(Time2) as Time2, '
              .'SUM(Time3) as Time3, '
              .'SUM(Time4) as Time4, '
              .'SUM(Time5) as Time5, '
              .'SUM(Time6) as Time6, '
              .'SUM(Time7) as Time7, '
              .'SUM(Time8) as Time8, '
              .'SUM(Time9) as Time9, '
              .'SUM(Time10) as Time10, '
              .'SUM(Time11) as Time11, '
              .'SUM(Time12) as Time12, '
              .'SUM(Money1) as Money1, '
              .'SUM(Money2) as Money2, '
              .'SUM(Money3) as Money3, '
              .'SUM(Money4) as Money4, '
              .'SUM(Money5) as Money5, '
              .'SUM(Money6) as Money6, '
              .'SUM(Money7) as Money7, '
              .'SUM(Money8) as Money8, '
              .'SUM(Money9) as Money9, '
              .'SUM(Money10) as Money10, '
              .'SUM(Money11) as Money11, '
              .'SUM(Money12) as Money12, '
              .'SUM(TotalTime) as TotalTime, '
              .'SUM(TotalMoney) as TotalMoney, '
              .'SUM(PTime1) as PTime1, '
              .'SUM(PTime2) as PTime2, '
              .'SUM(PTime3) as PTime3, '
              .'SUM(PTime4) as PTime4, '
              .'SUM(PTime5) as PTime5, '
              .'SUM(PTime6) as PTime6, '
              .'SUM(PTime7) as PTime7, '
              .'SUM(PTime8) as PTime8, '
              .'SUM(PTime9) as PTime9, '
              .'SUM(PTime10) as PTime10, '
              .'SUM(PTime11) as PTime11, '
              .'SUM(PTime12) as PTime12, '
              .'SUM(PMoney1) as PMoney1, '
              .'SUM(PMoney2) as PMoney2, '
              .'SUM(PMoney3) as PMoney3, '
              .'SUM(PMoney4) as PMoney4, '
              .'SUM(PMoney5) as PMoney5, '
              .'SUM(PMoney6) as PMoney6, '
              .'SUM(PMoney7) as PMoney7, '
              .'SUM(PMoney8) as PMoney8, '
              .'SUM(PMoney9) as PMoney9, '
              .'SUM(PMoney10) as PMoney10, '
              .'SUM(PMoney11) as PMoney11, '
              .'SUM(PMoney12) as PMoney12, '
              .'SUM(PTotalTime) as PTotalTime, '
              .'SUM(PTotalMoney) as PTotalMoney '
              .' FROM MonthData2 '
              .'WHERE (MemberY  = :MemberY '
              .'AND Project = :Project AND ProjectCord = :ProjectCord ) '
              .'ORDER BY ProjectCord'
              );
              $stmt2->bindValue('MemberY',$year_status->getyear(), \PDO::PARAM_STR);
              $stmt2->bindValue('ProjectCord',$project->getProjectCord(), \PDO::PARAM_STR);
              $stmt2->bindValue('Project',$project->getProject(), \PDO::PARAM_STR);
              $stmt2->execute();
              $allmonths=$stmt2->fetchAll();
              $project->setTime1($allmonths[0]['Time1']);
              $project->setTime2($allmonths[0]['Time2']);
              $project->setTime3($allmonths[0]['Time3']);
              $project->setTime4($allmonths[0]['Time4']);
              $project->setTime5($allmonths[0]['Time5']);
              $project->setTime6($allmonths[0]['Time6']);
              $project->setTime7($allmonths[0]['Time7']);
              $project->setTime8($allmonths[0]['Time8']);
              $project->setTime9($allmonths[0]['Time9']);
              $project->setTime10($allmonths[0]['Time10']);
              $project->setTime11($allmonths[0]['Time11']);
              $project->setTime12($allmonths[0]['Time12']);
              $project->setMoney1($allmonths[0]['Money1']);
              $project->setMoney2($allmonths[0]['Money2']);
              $project->setMoney3($allmonths[0]['Money3']);
              $project->setMoney4($allmonths[0]['Money4']);
              $project->setMoney5($allmonths[0]['Money5']);
              $project->setMoney6($allmonths[0]['Money6']);
              $project->setMoney7($allmonths[0]['Money7']);
              $project->setMoney8($allmonths[0]['Money8']);
              $project->setMoney9($allmonths[0]['Money9']);
              $project->setMoney10($allmonths[0]['Money10']);
              $project->setMoney11($allmonths[0]['Money11']);
              $project->setMoney12($allmonths[0]['Money12']);
              $project->setTotalTime($allmonths[0]['TotalTime']);
              $project->setTotalMoney($allmonths[0]['TotalMoney']);
              $project->setPTime1($allmonths[0]['PTime1']);
              $project->setPTime2($allmonths[0]['PTime2']);
              $project->setPTime3($allmonths[0]['PTime3']);
              $project->setPTime4($allmonths[0]['PTime4']);
              $project->setPTime5($allmonths[0]['PTime5']);
              $project->setPTime6($allmonths[0]['PTime6']);
              $project->setPTime7($allmonths[0]['PTime7']);
              $project->setPTime8($allmonths[0]['PTime8']);
              $project->setPTime9($allmonths[0]['PTime9']);
              $project->setPTime10($allmonths[0]['PTime10']);
              $project->setPTime11($allmonths[0]['PTime11']);
              $project->setPTime12($allmonths[0]['PTime12']);
              $project->setPMoney1($allmonths[0]['PMoney1']);
              $project->setPMoney2($allmonths[0]['PMoney2']);
              $project->setPMoney3($allmonths[0]['PMoney3']);
              $project->setPMoney4($allmonths[0]['PMoney4']);
              $project->setPMoney5($allmonths[0]['PMoney5']);
              $project->setPMoney6($allmonths[0]['PMoney6']);
              $project->setPMoney7($allmonths[0]['PMoney7']);
              $project->setPMoney8($allmonths[0]['PMoney8']);
              $project->setPMoney9($allmonths[0]['PMoney9']);
              $project->setPMoney10($allmonths[0]['PMoney10']);
              $project->setPMoney11($allmonths[0]['PMoney11']);
              $project->setPMoney12($allmonths[0]['PMoney12']);
              $project->setPTotalTime($allmonths[0]['PTotalTime']);
              $project->setPTotalMoney($allmonths[0]['PTotalMoney']);
            }
         }
            return $allprojects ? $projects : false;
        } catch (\Exception $e) {
            if ($tran) {
                $this->db->rollBack();
            }
            throw $e;
        }
  }

    public function GetProjectApprovalStatus(EntityInterface $project_entity, $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }
            $stmt = $this->db->prepare(
               'SELECT ApprovaFlg FROM ProjectData '
              .'WHERE No = :No '
              );
            $stmt->bindValue('No',$project_entity->getNo(), \PDO::PARAM_STR);
            $stmt->execute();
            $allprojects=$stmt->fetchAll();
            return $allprojects ? $this->BuildAllProjects($allprojects[0]) : false;
        } catch (\Exception $e) {
            if ($tran) {
                $this->db->rollBack();
            }
            throw $e;
        }
  }

      public function UpdateProjectStatusByProjectCode(
        EntityInterface $project_entity,
        EntityInterface $project_approval_status,
	EntityInterface $user_info,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            if ($project_approval_status->getApprovaFlg() ==='未承認') {
              $approval_flag = '仮登録';
            }
            else{
             $project_approval_status = $project_approval_status->getApprovaFlg();
            }
            
            $no = ((int)$project_entity->getNo());

            $sql = $this->UpdateProjectStatusSql();
            $stmt = $connection->prepare($sql);
	    $sql2 = $this->UpdateDailyData();
	    $stmt2 = $connection->prepare($sql2);

	    $StartDate = $project_entity->getStartDate();
	    $CancelDate = $project_entity->getCancelDate();
	    $CloseDate = $project_entity->getCloseDate();
	    if ($StartDate === NULL or $StartDate === "") {
		$StartDate = "0000-00-00";
	    }
	    if ($CancelDate === NULL or $CancelDate === "") {
	    	$CancelDate = "0000-00-00";
	    }

	    if ($CloseDate === NULL or $CloseDate === "") {
		$CloseDate = "0000-00-00";
	    }
            $stmt->bindValue(':CloseDate', $CloseDate, \PDO::PARAM_STR);
	    $stmt2->bindValue(':CloseDate', $CloseDate, \PDO::PARAM_STR);
	    $stmt->bindValue(':StartDate', $StartDate, \PDO::PARAM_STR);
	    $stmt2->bindValue(':StartDate', $StartDate, \PDO::PARAM_STR);
	    $stmt->bindValue(':CancelDate', $CancelDate, \PDO::PARAM_STR);
	    $stmt2->bindValue(':CancelDate', $CancelDate, \PDO::PARAM_STR);
	    $stmt2->bindValue(':Status', $project_entity->getstatus(), \PDO::PARAM_STR);

	    //$sql2 = $this->UpdateDailyData();
	    //$stmt2 = $connection->prepare($sql2);

            $stmt->bindValue(':Status', $project_entity->getstatus(), \PDO::PARAM_STR);
            $stmt->bindValue(':Project', $project_entity->getProject(), \PDO::PARAM_STR);
            $stmt->bindValue(':ProjectCord', $project_entity->getProjectCord(), \PDO::PARAM_STR);
            $stmt->bindValue(':Custodian', $project_entity->getCustodian(), \PDO::PARAM_INT);
	    //$stmt->bindValue(':StartDate', $project_entity->getStartDate(), \PDO::PARAM_INT);
            //$stmt->bindValue(':Budget', $project_entity->getBudget(), \PDO::PARAM_INT);
            //$stmt->bindValue(':PMO', $project_entity->getPMO(), \PDO::PARAM_INT);
            //$stmt->bindValue(':Product', $project_entity->getProduct(), \PDO::PARAM_INT);
            //$stmt->bindValue(':Accounting', $project_entity->getAccounting(), \PDO::PARAM_INT);
            $stmt->bindValue(':BusinessType', $project_entity->getBusinessType(), \PDO::PARAM_INT);
            //$stmt->bindValue(':No',$no, \PDO::PARAM_INT);
            $stmt->bindValue(':ApprovaFlg', $project_approval_status, \PDO::PARAM_STR);
	    $stmt->bindValue(':EditDate', date('Y-m-d'), \PDO::PARAM_INT);
	    $stmt->bindValue(':EditTime', date('H:i:s'), \PDO::PARAM_INT);
	    $stmt->bindValue(':EditName', $user_info->getUserName(), \PDO::PARAM_STR);
	    $stmt->bindValue(':OP_ArticleNo', $project_entity->getOp_ArticleNo(), \PDO::PARAM_STR);
            $stmt->execute();
	    $stmt2->bindValue(':OP_ArticleNo', $project_entity->getOPno().$project_entity->getArticleNo(), \PDO::PARAM_STR);
	    $stmt2->execute();
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }

  private function UpdateProjectStatusSql()
  {
     $sql ='UPDATE ProjectData SET '
      . 'Status = :Status, '
      . 'Project = :Project, '
      . 'ProjectCord = :ProjectCord, '
      . 'Custodian = :Custodian, '
      //. 'Budget = :Budget, '
      //. 'PMO = :PMO, '
      //. 'Accounting = :Accounting, '
      . 'StartDate = :StartDate, '
      . 'CancelDate = :CancelDate, '
      . 'CloseDate = :CloseDate, '
      //. 'Product = :Product, '
      . 'BusinessType = :BusinessType, '
      . 'ApprovaFlg = :ApprovaFlg, '
      . 'EditDate = :EditDate, '
      . 'EditTime = :EditTime, '
      . 'EditName = :EditName '
      . 'WHERE OP_ArticleNo = :OP_ArticleNo ';
      return $sql;
  }

  private function UpdateProjectStatusWithPlanDateSql()
  {
     $sql ='UPDATE ProjectData SET '
      . 'Status = :Status, '
      . 'Project = :Project, '
      . 'ProjectCord = :ProjectCord, '
      . 'StartDate = :StartDate, '
      . 'CancelDate = :CancelDate, '
      . 'CloseDate = :CloseDate, '
      . 'Custodian = :Custodian, '
      //. 'Budget = :Budget, '
      //. 'PMO = :PMO, '
      //. 'Accounting = :Accounting, '
      //. 'Product = :Product, '
      . 'BusinessType = :BusinessType, '
      . 'ApprovaFlg = :ApprovaFlg, '
      . 'EditDate = :EditDate, '
      . 'EditTime = :EditTime, '
      . 'EditName = :EditName '
      . 'WHERE OP_ArticleNo = :OP_ArticleNo ';
      return $sql;
  }

  private function UpdateDailyData() {
	$sql = 'UPDATE DailyData SET '
		. 'Status = :Status, '
		. 'StartDate = :StartDate, '
		. 'CancelDate = :CancelDate, '
		. 'CloseDate = :CloseDate '
		. 'WHERE OP_ArticleNo = :OP_ArticleNo ';
	return $sql;
  }

  private function UpdateDailyData2() {
	$sql = 'UPDATE DailyData SET '
		. 'CloseDate = :CloseDate '
		. 'WHERE OP_ArticleNo = :OP_ArticleNo ';
	return $sql;
  }

      public function UpdateMemberData(
        EntityInterface $user,
        EntityInterface $project_data,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            $sql = $this->UpdateMemberDataSql();
            $stmt = $connection->prepare($sql);
            $stmt->bindValue('ProjectCord', $project_data->getProjectCord(), \PDO::PARAM_STR);
            $stmt->bindValue('Project', $project_data->getProject(), \PDO::PARAM_STR);
            $stmt->bindValue('ProjectNo', $project_data->getNo(), \PDO::PARAM_STR);

            $stmt->bindValue('AccountId', $user->getAccountId(), \PDO::PARAM_STR);
            $stmt->bindValue('MemberY', $project_data->getyear(), \PDO::PARAM_STR);
            $stmt->bindValue('UserProjectCord', $user->getProjectCord(), \PDO::PARAM_STR);
            $stmt->bindValue('UserProject', $user->getProject(), \PDO::PARAM_STR);
            $stmt->execute();
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }

  private function UpdateMemberDataSql()
  {
     $sql ='UPDATE MonthData2 SET '
      . 'ProjectCord = :ProjectCord, '
      . 'Project = :Project, '
      . 'ProjectNo = :ProjectNo '
      . 'WHERE '
      . 'AccountId = :AccountId '
      . 'AND MemberY = :MemberY '
      . 'AND ProjectCord = :UserProjectCord '
      . 'AND Project = :UserProject';
      return $sql;
  }    

  public function FindAllProjectsbyYearandStatusAndSearch(AllProjectsEntity $year_status, UserEntity $user_info, $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }

	    $id = $user_info->getLoginId();

	    $stmt3 = $this->db->prepare('SELECT OPNo FROM AccountID_OPNo WHERE AccountID = :AccountID');
	    $stmt3->bindvalue('AccountID', $id, \PDO::PARAM_STR);
	    $stmt3->execute();
	    $opno = $this->array_column($stmt3->fetchAll(), 'OPNo');
	    $where = ' (OPNo LIKE :OPNo ';
	    for ($i = 1; $i < count($opno); $i++) {
		$where = $where.' OR OPNo LIKE :OPNo'.$i.' ';
	    }
            $where = $where.') ';
            $stmt = $this->db->prepare(
               'SELECT * FROM ProjectData '
              .'WHERE '
              .'(ProjectY = :ProjectY '
              // .'AND Status = :Status
              .') '
              .'AND '
              .'('
              .'   ProjectCord LIKE CONCAT("%" , :search , "%") '
              .'OR Project LIKE CONCAT("%" , :search , "%") '
              .'OR Status LIKE CONCAT("%" , :search , "%") '
              .'OR BusinessType LIKE CONCAT("%" , :search , "%") '
              .'OR Custodian LIKE CONCAT("%" , :search , "%") '
              .'OR Budget LIKE CONCAT("%" , :search , "%") '
              .'OR Accounting LIKE CONCAT("%" , :search , "%") '
              .'OR Product LIKE CONCAT("%" , :search , "%") '
              .'OR PMO LIKE CONCAT("%" , :search , "%") '
              // .'OR PlanDate LIKE (%'. $year_status->getSearch() .'%) '
              // DATE_FORMAT(bi.updated_at, "%Y-%m-%d") >= :updated_date_from 
              // .'OR Custodian LIKE CONCAT("%" , :search , "%") '
              // .'OR Custodian LIKE CONCAT("%" , :search , "%") '
              .''
              .' ) '
	      .' AND '.$where
              .'ORDER BY ProjectCord'
              );
            $stmt->bindValue('ProjectY',$year_status->getyear(), \PDO::PARAM_STR);
            $stmt->bindValue('search',$year_status->getSearch(), \PDO::PARAM_STR);
	    $stmt->bindValue('OPNo', $opno[0], \PDO::PARAM_STR);
	    for ($i = 1; $i < count($opno); $i++) {
		$stmt->bindvalue('OPNo'.$i, $opno[$i], \PDO::PARAM_STR);
	    }
            $stmt->execute();
            $allprojects=$stmt->fetchAll();
            foreach ($allprojects as $all_project) {
              $projects[] = $this->BuildAllProjects($all_project);
            }
            if ($allprojects) {
              foreach ($projects as $project) {
                $stmt2 = $this->db->prepare(
                  'SELECT '
                  .'SUM(Time1) as Time1, '
                  .'SUM(Time2) as Time2, '
                  .'SUM(Time3) as Time3, '
                  .'SUM(Time4) as Time4, '
                  .'SUM(Time5) as Time5, '
                  .'SUM(Time6) as Time6, '
                  .'SUM(Time7) as Time7, '
                  .'SUM(Time8) as Time8, '
                  .'SUM(Time9) as Time9, '
                  .'SUM(Time10) as Time10, '
                  .'SUM(Time11) as Time11, '
                  .'SUM(Time12) as Time12, '
                  .'SUM(Money1) as Money1, '
                  .'SUM(Money2) as Money2, '
                  .'SUM(Money3) as Money3, '
                  .'SUM(Money4) as Money4, '
                  .'SUM(Money5) as Money5, '
                  .'SUM(Money6) as Money6, '
                  .'SUM(Money7) as Money7, '
                  .'SUM(Money8) as Money8, '
                  .'SUM(Money9) as Money9, '
                  .'SUM(Money10) as Money10, '
                  .'SUM(Money11) as Money11, '
                  .'SUM(Money12) as Money12, '
                  .'SUM(TotalTime) as TotalTime, '
                  .'SUM(TotalMoney) as TotalMoney, '
                  .'SUM(PTime1) as PTime1, '
                  .'SUM(PTime2) as PTime2, '
                  .'SUM(PTime3) as PTime3, '
                  .'SUM(PTime4) as PTime4, '
                  .'SUM(PTime5) as PTime5, '
                  .'SUM(PTime6) as PTime6, '
                  .'SUM(PTime7) as PTime7, '
                  .'SUM(PTime8) as PTime8, '
                  .'SUM(PTime9) as PTime9, '
                  .'SUM(PTime10) as PTime10, '
                  .'SUM(PTime11) as PTime11, '
                  .'SUM(PTime12) as PTime12, '
                  .'SUM(PMoney1) as PMoney1, '
                  .'SUM(PMoney2) as PMoney2, '
                  .'SUM(PMoney3) as PMoney3, '
                  .'SUM(PMoney4) as PMoney4, '
                  .'SUM(PMoney5) as PMoney5, '
                  .'SUM(PMoney6) as PMoney6, '
                  .'SUM(PMoney7) as PMoney7, '
                  .'SUM(PMoney8) as PMoney8, '
                  .'SUM(PMoney9) as PMoney9, '
                  .'SUM(PMoney10) as PMoney10, '
                  .'SUM(PMoney11) as PMoney11, '
                  .'SUM(PMoney12) as PMoney12, '
                  .'SUM(PTotalTime) as PTotalTime, '
                  .'SUM(PTotalMoney) as PTotalMoney '
                  .' FROM MonthData2 '
                  .'WHERE (MemberY  = :MemberY '
                  .'AND Project = :Project AND ProjectCord = :ProjectCord ) '
                  .'ORDER BY ProjectCord'
                  );
                $stmt2->bindValue('MemberY',$year_status->getyear(), \PDO::PARAM_STR);
                $stmt2->bindValue('ProjectCord',$project->getProjectCord(), \PDO::PARAM_STR);
                $stmt2->bindValue('Project',$project->getProject(), \PDO::PARAM_STR);
                $stmt2->execute();
                $allmonths = $stmt2->fetchAll();
                $project->setTime1($allmonths[0]['Time1']);
              $project->setTime2($allmonths[0]['Time2']);
              $project->setTime3($allmonths[0]['Time3']);
              $project->setTime4($allmonths[0]['Time4']);
              $project->setTime5($allmonths[0]['Time5']);
              $project->setTime6($allmonths[0]['Time6']);
              $project->setTime7($allmonths[0]['Time7']);
              $project->setTime8($allmonths[0]['Time8']);
              $project->setTime9($allmonths[0]['Time9']);
              $project->setTime10($allmonths[0]['Time10']);
              $project->setTime11($allmonths[0]['Time11']);
              $project->setTime12($allmonths[0]['Time12']);
              $project->setMoney1($allmonths[0]['Money1']);
              $project->setMoney2($allmonths[0]['Money2']);
              $project->setMoney3($allmonths[0]['Money3']);
              $project->setMoney4($allmonths[0]['Money4']);
              $project->setMoney5($allmonths[0]['Money5']);
              $project->setMoney6($allmonths[0]['Money6']);
              $project->setMoney7($allmonths[0]['Money7']);
              $project->setMoney8($allmonths[0]['Money8']);
              $project->setMoney9($allmonths[0]['Money9']);
              $project->setMoney10($allmonths[0]['Money10']);
              $project->setMoney11($allmonths[0]['Money11']);
              $project->setMoney12($allmonths[0]['Money12']);
              $project->setTotalTime($allmonths[0]['TotalTime']);
              $project->setTotalMoney($allmonths[0]['TotalMoney']);
              $project->setPTime1($allmonths[0]['PTime1']);
              $project->setPTime2($allmonths[0]['PTime2']);
              $project->setPTime3($allmonths[0]['PTime3']);
              $project->setPTime4($allmonths[0]['PTime4']);
              $project->setPTime5($allmonths[0]['PTime5']);
              $project->setPTime6($allmonths[0]['PTime6']);
              $project->setPTime7($allmonths[0]['PTime7']);
              $project->setPTime8($allmonths[0]['PTime8']);
              $project->setPTime9($allmonths[0]['PTime9']);
              $project->setPTime10($allmonths[0]['PTime10']);
              $project->setPTime11($allmonths[0]['PTime11']);
              $project->setPTime12($allmonths[0]['PTime12']);
              $project->setPMoney1($allmonths[0]['PMoney1']);
              $project->setPMoney2($allmonths[0]['PMoney2']);
              $project->setPMoney3($allmonths[0]['PMoney3']);
              $project->setPMoney4($allmonths[0]['PMoney4']);
              $project->setPMoney5($allmonths[0]['PMoney5']);
              $project->setPMoney6($allmonths[0]['PMoney6']);
              $project->setPMoney7($allmonths[0]['PMoney7']);
              $project->setPMoney8($allmonths[0]['PMoney8']);
              $project->setPMoney9($allmonths[0]['PMoney9']);
              $project->setPMoney10($allmonths[0]['PMoney10']);
              $project->setPMoney11($allmonths[0]['PMoney11']);
              $project->setPMoney12($allmonths[0]['PMoney12']);
              $project->setPTotalTime($allmonths[0]['PTotalTime']);
              $project->setPTotalMoney($allmonths[0]['PTotalMoney']);
              }
            }
            return $allprojects ? $projects : false;
        } catch (\Exception $e) {
            if ($tran) {
                $this->db->rollBack();
            }
            throw $e;
        }
  }



    public function FindProjectDataById(EntityInterface $project_id, $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }

            $stmt = $this->db->prepare(
               'SELECT * FROM ProjectData '
              .'WHERE No = :No '
              .'ORDER BY ProjectCord'
              );
            $stmt->bindValue('No',$project_id->getNo(), \PDO::PARAM_STR);
            $stmt->execute();
            $allprojects=$stmt->fetchAll();
            return $allprojects ? $this->BuildAllProjects($allprojects[0]) : false;
        } catch (\Exception $e) {
            if ($tran) {
                $this->db->rollBack();
            }
            throw $e;
        }
  }

  public function FindProjectMoneyDataById(EntityInterface $project_year, EntityInterface $project_data, $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }

            $stmt = $this->db->prepare(
               'SELECT '
               .'SUM(Time1) as Time1, '
               .'SUM(Time2) as Time2, '
               .'SUM(Time3) as Time3, '
               .'SUM(Time4) as Time4, '
               .'SUM(Time5) as Time5, '
               .'SUM(Time6) as Time6, '
               .'SUM(Time7) as Time7, '
               .'SUM(Time8) as Time8, '
               .'SUM(Time9) as Time9, '
               .'SUM(Time10) as Time10, '
               .'SUM(Time11) as Time11, '
               .'SUM(Time12) as Time12, '
               .'SUM(PTime1) as PTime1, '
               .'SUM(PTime2) as PTime2, '
               .'SUM(PTime3) as PTime3, '
               .'SUM(PTime4) as PTime4, '
               .'SUM(PTime5) as PTime5, '
               .'SUM(PTime6) as PTime6, '
               .'SUM(PTime7) as PTime7, '
               .'SUM(PTime8) as PTime8, '
               .'SUM(PTime9) as PTime9, '
               .'SUM(PTime10) as PTime10, '
               .'SUM(PTime11) as PTime11, '
               .'SUM(PTime12) as PTime12, '
               .'SUM(Money1) as Money1, '
               .'SUM(Money2) as Money2, '
               .'SUM(Money3) as Money3, '
               .'SUM(Money4) as Money4, '
               .'SUM(Money5) as Money5, '
               .'SUM(Money6) as Money6, '
               .'SUM(Money7) as Money7, '
               .'SUM(Money8) as Money8, '
               .'SUM(Money9) as Money9, '
               .'SUM(Money10) as Money10, '
               .'SUM(Money11) as Money11, '
               .'SUM(Money12) as Money12, '
               .'SUM(PMoney1) as PMoney1, '
               .'SUM(PMoney2) as PMoney2, '
               .'SUM(PMoney3) as PMoney3, '
               .'SUM(PMoney4) as PMoney4, '
               .'SUM(PMoney5) as PMoney5, '
               .'SUM(PMoney6) as PMoney6, '
               .'SUM(PMoney7) as PMoney7, '
               .'SUM(PMoney8) as PMoney8, '
               .'SUM(PMoney9) as PMoney9, '
               .'SUM(PMoney10) as PMoney10, '
               .'SUM(PMoney11) as PMoney11, '
               .'SUM(PMoney12) as PMoney12, '

               .'SUM(TotalTime) as Time, '
               .'SUM(TotalMoney) as Money, '
               .'SUM(PTotalTime) as PTime, '
               .'SUM(PTotalMoney) as PMoney '
               .'FROM MonthData2 '
               .'WHERE ProjectCord = :ProjectCord '
               .'AND MemberY = :MemberY AND Project = :Project '
              );
        $stmt->bindValue('ProjectCord',$project_data->getProjectCord(), \PDO::PARAM_STR);
        $stmt->bindValue('Project',$project_data->getProject(), \PDO::PARAM_STR);
        $stmt->bindValue('MemberY',$project_year->getyear(), \PDO::PARAM_STR);

            $stmt->execute();
            $allprojects=$stmt->fetchAll();
            return $allprojects ? $this->BuildNewMonthdata($allprojects[0]) : false;
        } catch (\Exception $e) {
            if ($tran) {
                $this->db->rollBack();
            }
            throw $e;
        }
  }


public function FindProjectMonthTimeSumByProjectId(EntityInterface $project_year, EntityInterface $project_data, $tran = true)
{
    try {
      if ($tran) {
             $this->db->beginTransaction();
         }
        $stmt = $this->db->prepare(
            'SELECT * FROM MonthData2 '
           .'WHERE ProjectCord = :ProjectCord '
           .'AND MemberY = :MemberY '
          );
        $stmt->bindValue('ProjectCord',$project_data->getProjectCord(), \PDO::PARAM_STR);
        $stmt->bindValue('MemberY',$project_year->getyear(), \PDO::PARAM_STR);
        $stmt->execute();
        $all_months=$stmt->fetchAll();
        foreach ($all_months as $months) {
          $entity[] = $this->BuildNewMonthdata($months);
        }
        return $all_months ? $entity : false;
    } catch (\Exception $e) {
        if ($tran) {
            $this->db->rollBack();
        }
        throw $e;
    }
}

public function FindMonthDataByProjectId(EntityInterface $project_data, $tran = true)
{
    try {
      if ($tran) {
             $this->db->beginTransaction();
         }
        $stmt = $this->db->prepare(
           'SELECT * FROM MonthData '
          .'WHERE ProjectCord = :ProjectCord '
          .'GROUP By AccountId'
          );
        $stmt->bindValue('ProjectCord',$project_data->getProjectCord(), \PDO::PARAM_STR);
        $stmt->execute();
        $all_months=$stmt->fetchAll();
        foreach ($all_months as $month) {
          $entity[] = $this->BuildMonthData($month);
        }
        return $all_months ? $entity : false;
    } catch (\Exception $e) {
        if ($tran) {
            $this->db->rollBack();
        }
        throw $e;
    }
}

public function FindMonthTimeSumByProjectId(EntityInterface $project_year, EntityInterface $project_data, $tran = true)
{
    try {
      if ($tran) {
             $this->db->beginTransaction();
         }
        $stmt = $this->db->prepare(
           'SELECT '
          .'(PTime1 + PTime2 + PTime3 + PTime4 + PTime5 + PTime6 + PTime7 + PTime8 + PTime9 + PTime10 + PTime11 + PTime12) AS PTime, '
          .'(PMoney1 + PMoney2 + PMoney3 + PMoney4 + PMoney5 + PMoney6 + PMoney7 + PMoney8 + PMoney9 + PMoney10 + PMoney11 + PMoney12) AS PMoney, '
          .'(Time1 + Time2 + Time3 + Time4 + Time5 + Time6 + Time7 + Time8 + Time9 + Time10 + Time11 + Time12) AS Time, '
          .'(Money1 + Money2 + Money3 + Money4 + Money5 + Money6 + Money7 + Money8 + Money9 + Money10 + Money11 + Money12) AS Money, '
          .' PTime1 , PTime2 , PTime3 ,PTime4 , PTime5 , PTime6 , PTime7 , PTime8 , PTime9 , PTime10 , PTime11 , PTime12, '
          .'PMoney1 , PMoney2,PMoney3,PMoney4,PMoney5,PMoney6,PMoney7,PMoney8,PMoney9,PMoney10,PMoney11,PMoney12, '
          .'Time1, Time2, Time3,Time4,Time5,Time6,Time7,Time8,Time9,Time10,Time11,Time12, '
          .'Money1,Money2,Money3,Money4,Money5,Money6,Money7,Money8,Money9,Money10,Money11,Money12, '
          .'AccountId, '
          .'Name, '
          // .'PriceGroup, '
          .'MemberY, '
          .'ProjectCord, '
          .'Project, '
          .'No '
          .'FROM MonthData2 '
          .'WHERE '
          .'('
          .'ProjectCord = :ProjectCord'
          // .' OR '
          // .'Project = :Project '
          .')'
          .'AND MemberY = :MemberY AND Project = :Project '
          .'GROUP By AccountId'
          );
        $stmt->bindValue('ProjectCord',$project_data->getProjectCord(), \PDO::PARAM_STR);
        $stmt->bindValue('Project',$project_data->getProject(), \PDO::PARAM_STR);
        $stmt->bindValue('MemberY',$project_year->getyear(), \PDO::PARAM_STR);
        $stmt->execute();
        $all_months=$stmt->fetchAll();
        foreach ($all_months as $month) {
          $entity[] = $this->BuildNewMonthData($month);
        }
        return $all_months ? $entity : false;
    } catch (\Exception $e) {
        if ($tran) {
            $this->db->rollBack();
        }
        throw $e;
    }
}

      public function FindUserDataByProjectCode(EntityInterface $project_code, $tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }

            $stmt = $this->db->prepare(
               'SELECT * FROM MonthData '
              .'WHERE ProjectCord = :ProjectCord '
              .'GROUP By AccountId'
              );
            $stmt->bindValue('ProjectCord',$project_code->getProjectCord(), \PDO::PARAM_STR);
            $stmt->execute();
            $allusers=$stmt->fetchAll();
            foreach ($allusers as $users) {
              $entity[] = $this->BuildMonthData($users);
            }
            return $allusers ? $entity : false;
        } catch (\Exception $e) {
            if ($tran) {
                $this->db->rollBack();
            }
            throw $e;
        }
  }

      public function GetProjectCompleteBudget($tran = true)
  {
        try {
          if ($tran) {
                 $this->db->beginTransaction();
             }

            $stmt = $this->db->prepare(
               'SELECT `ProjectCord`, SUM(`Money`) as `Money` FROM MonthData '
              // .'WHERE No = :No '
              .'GROUP BY  `ProjectCord`'
              );
            // $stmt->bindValue('No',$project_id->getNo(), \PDO::PARAM_STR);
            $stmt->execute();
            $project_budget=$stmt->fetchAll();
            foreach ($project_budget as $budget) {
              $entity[] = $this->BuildMonthData($budget);
            }
            return $project_budget ? $entity : false;
        } catch (\Exception $e) {
            if ($tran) {
                $this->db->rollBack();
            }
            throw $e;
        }
  }


  public function Buildyearandstatus(Array $paramaters = array())
  {
    $entity = new AllProjectsEntity;
    $entity->setProperties($paramaters);
    return $entity;
  }

  public function BuildAllProjects($paramaters)
  {
    $entity = new AllProjectsEntity;
    $entity->setProperties($paramaters);
    return $entity;
  }

    public function BuildMonthData($paramaters)
  {
    $entity = new MonthDataEntity;
    $entity->setProperties($paramaters);
    return $entity;
  }

public function BuildNewMonthData($paramaters)
{
  $entity = new MemberAddEntity;
  $entity->setProperties($paramaters);
  return $entity;
}


  public function add(EntityInterface $entity)
  {
      return;
  }
  /**
   * @param EntityInterface $entity
   */
  public function remove(EntityInterface $entity)
  {
      return;
  }

   /**
     * Returns the values from a single column of the input array, identified by
     * the $columnKey.
     *
     * Optionally, you may provide an $indexKey to index the values in the returned
     * array by the values from the $indexKey column in the input array.
     *
     * @param array $input A multi-dimensional array (record set) from which to pull
     *                     a column of values.
     * @param mixed $columnKey The column of values to return. This value may be the
     *                         integer key of the column you wish to retrieve, or it
     *                         may be the string key name for an associative array.
     * @param mixed $indexKey (Optional.) The column to use as the index/keys for
     *                        the returned array. This value may be the integer key
     *                        of the column, or it may be the string key name.
     * @return array
     */
    function array_column($input = null, $columnKey = null, $indexKey = null)
    {
        // Using func_get_args() in order to check for proper number of
        // parameters and trigger errors exactly as the built-in array_column()
        // does in PHP 5.5.
        $argc = func_num_args();
        $params = func_get_args();

        if ($argc < 2) {
            trigger_error("array_column() expects at least 2 parameters, {$argc} given", E_USER_WARNING);
            return null;
        }

        if (!is_array($params[0])) {
            trigger_error('array_column() expects parameter 1 to be array, ' . gettype($params[0]) . ' given', E_USER_WARNING);
            return null;
        }

        if (!is_int($params[1])
            && !is_float($params[1])
            && !is_string($params[1])
            && $params[1] !== null
            && !(is_object($params[1]) && method_exists($params[1], '__toString'))
        ) {
            trigger_error('array_column(): The column key should be either a string or an integer', E_USER_WARNING);
            return false;
        }

        if (isset($params[2])
            && !is_int($params[2])
            && !is_float($params[2])
            && !is_string($params[2])
            && !(is_object($params[2]) && method_exists($params[2], '__toString'))
        ) {
            trigger_error('array_column(): The index key should be either a string or an integer', E_USER_WARNING);
            return false;
        }

        $paramsInput = $params[0];
        $paramsColumnKey = ($params[1] !== null) ? (string) $params[1] : null;

        $paramsIndexKey = null;
        if (isset($params[2])) {
            if (is_float($params[2]) || is_int($params[2])) {
                $paramsIndexKey = (int) $params[2];
            } else {
                $paramsIndexKey = (string) $params[2];
            }
        }

        $resultArray = array();

        foreach ($paramsInput as $row) {

            $key = $value = null;
            $keySet = $valueSet = false;

            if ($paramsIndexKey !== null && array_key_exists($paramsIndexKey, $row)) {
                $keySet = true;
                $key = (string) $row[$paramsIndexKey];
            }

            if ($paramsColumnKey === null) {
                $valueSet = true;
                $value = $row;
            } elseif (is_array($row) && array_key_exists($paramsColumnKey, $row)) {
                $valueSet = true;
                $value = $row[$paramsColumnKey];
            }

            if ($valueSet) {
                if ($keySet) {
                    $resultArray[$key] = $value;
                } else {
                    $resultArray[] = $value;
                }
            }

        }

        return $resultArray;
    }


}
