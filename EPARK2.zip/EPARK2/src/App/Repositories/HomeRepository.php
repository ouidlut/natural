<?php
namespace App\Repositories;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use App\Entities\LoginInfoEntity;
use App\Entities\UserEntity;
use App\Entities\UserProjectsEntity;
use App\Entities\UserDailyDataEntity;
use App\Entities\AllMembersEntity;
use App\Entities\HolidayEntity;
use App\Entities\NewUserEntity;
use App\Entities\ProcessEntity;
use App\Entities\LockEntity;
use Doctrine\DBAL\Connection;
use Symfony\Component\HttpFoundation\Session\Session;
use Carbon\Carbon;



class HomeRepository implements RepositoryInterface
{

  protected $db;
  protected $uuid;

  public function __construct(Connection $db)
  {
      $this->db = $db;
  }

    public function FindUserProjectsByAccountId(UserEntity $user_info, $tran = true)
    {
      try{
        if ($tran) {
               $this->db->beginTransaction();
           }
           $stmt = $this->db->prepare(
              'SELECT DISTINCT YM '
            . 'FROM MonthData '
            . 'WHERE AccountId='.$user_info->getLoginId(). ''
            . ' GROUP BY ProjectCord ORDER BY YM ASC');
          $stmt->execute();
          $projects=$stmt->fetchAll();
          foreach ($projects as $projects_data) {
            $project[] = $this->buildUserprojects($projects_data);
          }
          return $projects ? $project : false;
      }
      catch (\Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
      }
    }

    public function SearchUserData(UserEntity $user_info, $tran = true)
    {
      try{
        if ($tran) {
               $this->db->beginTransaction();
           }
           $stmt = $this->db->prepare(
              'SELECT * '
            . 'FROM AccountData '
            . 'WHERE AccountId = :AccountId');
           $stmt->bindValue(':AccountId', $user_info->getLoginId(), \PDO::PARAM_INT);
          $stmt->execute();
          $data = $stmt->fetchAll();
          // var_dump($data);
          // exit();
          if ($data) {
              $login_info = array(
              'user_id'   => $data[0]['AccountId'] ,
              'user_name' => $data[0]['Name'],
              'EMail'  => $data[0]['EMail'],
              'Level'  => $data[0]['Level']
              );
            }
          return $data ? $this->buildUserEntity($login_info) : false;
      }
      catch (\Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
      }
    }

    public function SearchIfUserProjectExists($ProjectCord, $AccountId, $YM, $tran = true){
        try {
             $stmt =$this->db->prepare(
               'SELECT ProjectCord '
              .' FROM DailyData '
              .' WHERE ProjectCord = :ProjectCord '
              .' AND AccountId = :AccountId '
              .' AND YM = :YM '
              );
             $stmt->bindValue('ProjectCord', $ProjectCord, \PDO::PARAM_STR);
             $stmt->bindValue('AccountId', $AccountId, \PDO::PARAM_STR);
             $stmt->bindValue('YM', $YM, \PDO::PARAM_STR);
             $stmt->execute();
             $projectcode = $stmt->fetchAll();
             return $projectcode ? true : false;
        } catch (Exception $e) {
          throw $e;
        }
    }

    public function SearchProjectStatus($ProjectCord, $AccountId, $YM, $tran = true){
        try {
             $stmt =$this->db->prepare(
               'SELECT Status '
              .' FROM ProjectData '
              .' WHERE ProjectCord = :ProjectCord '
              );
             $stmt->bindValue('ProjectCord', $ProjectCord, \PDO::PARAM_STR);
             $stmt->execute();
             $projectcode = $stmt->fetchAll();
             $code = $projectcode[0]['Status'];
             if ($code != '未着手' and $code != '開発中') {
               return false;
             }
             return true;
        } catch (Exception $e) {
          throw $e;
        }
    }

        public function FindUserProjectsForCopying(UserEntity $user_info, $selectedmonth, $tran = true)
    {
      try{
        if ($tran) {
               $this->db->beginTransaction();
           }
           if ($selectedmonth ==='1') {
            $ym = date('Ym', strtotime('-1 month'));
           }
           else{
            $ym = date('Ym');
           }
           $stmt = $this->db->prepare(
              'SELECT AccountId, Name, YM, Price, ProjectCord, Project, Process1, Process2, Status, Note, OPNo, ArticleNo, StartDate, CloseDate, OP_ArticleNo '
            . 'FROM DailyData '
            . 'WHERE AccountId = :AccountId '
            . 'AND (Status NOT LIKE "完了" AND Status NOT LIKE "中止" '
	    . 'AND YM = :YM)');
           $stmt->bindValue(':AccountId', $user_info->getLoginId(), \PDO::PARAM_INT);
           $stmt->bindValue(':YM', $ym, \PDO::PARAM_INT);
          $stmt->execute();
          $projects=$stmt->fetchAll();
          foreach ($projects as $projects_data) {
            $project[] = $this->buildDailyReport($projects_data);
          }
          return $projects ? $project : false;
      }
      catch (\Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
      }
    }

    public function CheckIfHolidayDataExists(UserEntity $user_info, $holiday_data, $tran = true, $date = null)
    {
    if ($date === null) {
            $$date = date('Ym');
        if($holiday_data){
            if($holiday_data->getHolidayYM()){
                $date = $holiday_data->getHolidayYM();
            }
        }
      }
      try{
        if ($tran) {
               $this->db->beginTransaction();
           }
           $stmt = $this->db->prepare(
              'SELECT AccountId '
            . 'FROM HolidayData '
            . 'WHERE AccountId='.$user_info->getLoginId(). ' '
            . 'AND HolidayYM = '.$date.''
            // . 'WHERE AccountId= 1111111 '
            
            );
          $stmt->execute();
          $holiday_data=$stmt->fetch();
          return $holiday_data ? $this->buildDailyReport($holiday_data) : false;
      }
      catch (\Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
      }
    }

    public function FindUserHolidayByAccountId(UserEntity $user_info, UserProjectsEntity $selectedmonth, $tran = true, $date = null)
    {
    if ($date === null) {
            $date = date('Ym');
      }
      try{
        if ($tran) {
               $this->db->beginTransaction();
           }
           $stmt = $this->db->prepare(
              'SELECT * '
            . 'FROM HolidayData '
            . 'WHERE AccountId = :AccountId '
            . 'AND HolidayYM = :HolidayYM'
            // . 'WHERE AccountId= 1111111 '
            
            );
           $stmt->bindValue(':AccountId', $user_info->getLoginId(), \PDO::PARAM_INT);
           $stmt->bindValue(':HolidayYM', $selectedmonth->getselectedmonth(), \PDO::PARAM_INT);
          $stmt->execute();
          $holiday_data=$stmt->fetch();
          return $holiday_data ? $holiday_data : false;
          // return $holiday_data ? $this->buildHolidayEntity($holiday_data) : false;
      }
      catch (\Exception $e) {
          if ($tran) {
              $this->db->rollBack();
          }
          throw $e;
      }
    }

    public function FindUserHoursByAccountId(
      UserEntity $user_info,
      UserProjectsEntity $selectedmonth,
      $sorting,
      $tran = true
      )
    {

      try {

        if ($tran) {
               $this->db->beginTransaction();
          }
        if ($sorting === 'ProjectCords')
          {
            $sorting ='ProjectCord';
            $stmt = $this->db->prepare(
             'SELECT t1.No, t1.Project, t1.ProjectCord, t1.OPNo, t1.ArticleNo, t2.CloseDate, t2.CancelDate, t2.StartDate, t2.Status, t1.HouseName, t1.Time1, t1.Time2, t1.Time3, t1.Time4, t1.Time5, t1.Time6, t1.Time7, t1.Time8, t1.Time9, t1.Time10, '
	        . 't1.Time11, t1.Time12, t1.Time13, t1.Time14, t1.Time15, t1.Time16, t1.Time17, t1.Time18, t1.Time19, t1.Time20, t1.Time21, t1.Time22, t1.Time23, t1.Time24, t1.Time25, t1.Time26, t1.Time27, t1.Time28, t1.Time29, t1.Time30, t1.Time31, t1.SubTime FROM DailyData as t1 '
	        . 'LEFT JOIN ProjectData as t2 ON t1.ArticleNo = t2.ArticleNo '
            .'WHERE AccountId = :loginid '
            .'AND YM = :ym AND UploadF != 1 '
            // .'AND ProjectCord IN (SELECT ProjectCord FROM ProjectData WHERE Status = :Status ) '
            .'ORDER BY ProjectCord ASC '
            );
          $stmt->bindValue(':loginid', $user_info->getLoginId(), \PDO::PARAM_INT);
          $stmt->bindValue(':ym', date('Ym'), \PDO::PARAM_INT);
          //$stmt->bindValue(':sorting', 'ProjectCord', \PDO::PARAM_INT);
          // $stmt->bindValue(':Status', '開発中', \PDO::PARAM_INT);
          }
          else{
              $stmt = $this->db->prepare(
               'SELECT * FROM DailyData '
              .'WHERE AccountId = :loginid '
              .'AND YM = :ym AND UploadF != 1 '
              // .'AND ProjectCord IN (SELECT ProjectCord FROM ProjectData WHERE Status = :Status ) '
              .'ORDER BY '.$sorting.' ASC '
              );
            $stmt->bindValue(':loginid', $user_info->getLoginId(), \PDO::PARAM_INT);
            $stmt->bindValue(':ym', $selectedmonth->getselectedmonth(), \PDO::PARAM_INT);
            // $stmt->bindValue(':Status', '開発中', \PDO::PARAM_INT);
          }
          $stmt->execute();
          $hours=$stmt->fetchAll();
          if(empty($hours))
          {
             $hours=0;
             return false ;
          }
          else {
            foreach ($hours as $daily_data) {
              $userhour[] = $this->buildUserDailydata($daily_data);
                }
              return $userhour ? $userhour : false;
            }
          } catch (Exception $e) {
        if ($tran) {
            $this->db->rollBack();
        }
        throw $e;

    }

    }

    public function FindTotalUserHoursByAccountId(
      UserEntity $user_info,
      UserProjectsEntity $selectedmonth,
      $sorting,
      $tran = true
      )
    {
      try {

        if ($tran) {
               $this->db->beginTransaction();
          }
              $stmt = $this->db->prepare(
               'SELECT '
               .'SUM(Time1) as Time1, '
               .'SUM(Time2) as Time2, '
               .'SUM(Time3) as Time3, '
               .'SUM(Time4) as Time4, '
               .'SUM(Time5) as Time5, '
               .'SUM(Time6) as Time6, '
               .'SUM(Time7) as Time7, '
               .'SUM(Time8) as Time8, '
               .'SUM(Time9) as Time9, '
               .'SUM(Time10) as Time10, '
               .'SUM(Time11) as Time11, '
               .'SUM(Time12) as Time12, '
               .'SUM(Time13) as Time13, '
               .'SUM(Time14) as Time14, '
               .'SUM(Time15) as Time15, '
               .'SUM(Time16) as Time16, '
               .'SUM(Time17) as Time17, '
               .'SUM(Time18) as Time18, '
               .'SUM(Time19) as Time19, '
               .'SUM(Time20) as Time20, '
               .'SUM(Time21) as Time21, '
               .'SUM(Time22) as Time22, '
               .'SUM(Time23) as Time23, '
               .'SUM(Time24) as Time24, '
               .'SUM(Time25) as Time25, '
               .'SUM(Time26) as Time26, '
               .'SUM(Time27) as Time27, '
               .'SUM(Time28) as Time28, '
               .'SUM(Time29) as Time29, '
               .'SUM(Time30) as Time30, '
               .'SUM(Time31) as Time31, '
               .'SUM(SubTime) as SubTime '
               .' FROM DailyData '
              .'WHERE AccountId = :loginid '
              .'AND YM = :ym '
              // .'ORDER BY '.$sorting.' ASC '
              );
            $stmt->bindValue(':loginid', $user_info->getLoginId(), \PDO::PARAM_INT);
            $stmt->bindValue(':ym', $selectedmonth->getselectedmonth(), \PDO::PARAM_INT);
          $stmt->execute();
          $hours=$stmt->fetch();
          return $hours ? $this->buildUserDailydata($hours):false;
          } catch (Exception $e) {
        if ($tran) {
            $this->db->rollBack();
        }
        throw $e;

    }

    }



public function GetProjectCord(EntityInterface $user_info, $selectedmonth, $tran = true)
{
try {
  if ($tran) {
         $this->db->beginTransaction();
     }
     // var_dump($user_info);
     // exit();

     $stmt = $this->db->prepare('SELECT '
      .' DISTINCT(ProjectCord) , Project, Process1 , Process2 '
      .' FROM DailyData '
      .' WHERE AccountId = :AccountId AND YM = :ym LIMIT 100');
     $stmt->bindValue(':ym', $selectedmonth->getselectedmonth(), \PDO::PARAM_INT);
     $stmt->bindValue(':AccountId', $user_info->getLoginId(), \PDO::PARAM_INT);
     $stmt->execute();
     $project=$stmt->fetchAll();

    return $project ? $project : false;
   }
   catch (Exception $e) {
     if ($tran) {
         $this->db->rollBack();
     }
     throw $e;
   }
}

public function GetProjectCord2(EntityInterface $user_info, $selectedmonth, $tran = true)
{
try {
  if ($tran) {
         $this->db->beginTransaction();
     }
/* 2017/07/03 MonthDataの必要性が見当たらないので＋触りたくないのでProjectをベースでいいのかな?  */
/* その場合yyyyではなくyyyymmでの取得でもいいのかもしれない?  */
/* ということで変更してみる。
/* 2017/07/05 ステータスが完了のものを弾いたり、OPNoで制限を掛けてみる
     $stmt = $this->db->prepare('SELECT '
      .' DISTINCT(ProjectCord) , Project'
      .' FROM MonthData2 '
      .' WHERE AccountId = :AccountId AND MemberY = :ym LIMIT 100'
      // .' WHERE AccountId = :AccountId AND MemberY = :ym AND ProjectCord IN (SELECT ProjectCord FROM ProjectData WHERE Status = :Status) LIMIT 100 '
      );
*/
     $stmt = $this->db->prepare('SELECT '
       .' DISTINCT(ArticleNo), Project, ProjectCord, StartDate, CloseDate'
       .' FROM ProjectData '
       .' WHERE ProjectY = :y AND Status <> \'完了\' AND  OPNo = :opno LIMIT 100'
     );
     $opno = $user_info->getopno();
     $year = str_split($selectedmonth->getselectedmonth(),4);
     $years = substr($selectedmonth->getselectedmonth(), 0, 4);
     //ねんどは４月からので
     //三月までだったら年を一引くする
     if ($year[1]<=3 ) {
       $year[0] = $year[0] - 1;
     }
     $stmt->bindValue(':opno', $opno, \PDO::PARAM_STR);
     $stmt->bindValue(':y', $years);
//     $stmt->bindValue(':ym', $year[0], \PDO::PARAM_INT);
//     $stmt->bindValue(':AccountId', $user_info->getLoginId(), \PDO::PARAM_INT);
     // $stmt->bindValue(':Status', '開発中', \PDO::PARAM_INT);
     $stmt->execute();
     $project=$stmt->fetchAll();
     // var_dump($year[0]);
     // var_dump($user_info->getLoginId());
     // var_dump($project);

    return $project ? $project : false;
   }
   catch (Exception $e) {
     if ($tran) {
         $this->db->rollBack();
     }
     throw $e;
   }
}
public function GetAllProjectCord($tran = true, $date = null)
{
try {
  if ($date === null) {
            $date = date('Y');
      }
  if ($tran) {
         $this->db->beginTransaction();
     }


     $stmt = $this->db->prepare('SELECT '
      .' DISTINCT(ProjectCord) , Project'
      .' FROM ProjectData '
      .' WHERE ProjectY + :date ');
     $stmt->bindValue(':date', $date, \PDO::PARAM_INT);
     $stmt->execute();
     $project_data = $stmt->fetchAll();
     foreach ($project_data as $project) {
                     $projectcord[] = $this->buildDailyReport($project);
                 }
    return $project_data ? $projectcord : false;
   }
   catch (Exception $e) {
     if ($tran) {
         $this->db->rollBack();
     }
     throw $e;
   }
}

public function GetAllProcess($tran = true)
{
try {
  if ($tran) {
         $this->db->beginTransaction();
     }

     $stmt = $this->db->prepare('SELECT '
      .' Process1 , Process2'
      .' FROM WorkCord ');
     $stmt->execute();
     $process_data = $stmt->fetchAll();
     foreach ($process_data as $process) {
                     $processcord[] = $this->buildProcess($process);
                 }
    return $process_data ? $processcord : false;
   }
   catch (Exception $e) {
     if ($tran) {
         $this->db->rollBack();
     }
     throw $e;
   }
}

public function GeManualLockDay($tran = true)
{
try {
  if ($tran) {
         $this->db->beginTransaction();
     }

     $stmt = $this->db->prepare('SELECT `lock_day`, `lock_flag` FROM `manual_lock` WHERE 1 ');
     $stmt->execute();
     $lock_day = $stmt->fetch();
    return $lock_day ? $this->buildManualLock($lock_day) : false;
   }
   catch (Exception $e) {
     if ($tran) {
         $this->db->rollBack();
     }
     throw $e;
   }
}

public function getCurrentPrice(
  EntityInterface $user_info,
  $tran = true,
  $date = null
  ){
  if ($date === null) {
            $date = date('Ym');
    }
    try {
      if($tran)
        {
          $this->db->beginTransaction();
        }
      $month = date('n');
      $sql = $this->getCurrentPriceSql($month);
      $stmt = $this->db->prepare($sql);
      $stmt->bindValue(':user_id', $user_info->getLoginId(), \PDO::PARAM_INT);
      $stmt->execute();
      $data = $stmt->fetchAll();
      $price = $this->buildUserDailydata($data[0]);
      return $price;
      if ($tran) {
            $this->db->commit();
      }
    } catch (Exception $e) {
      if ($tran) {
              $this->db->rollBack();
        }
    throw $e;

    }

}

private function getCurrentPriceSql($month)
{

  $sql = 'SELECT Price' .$month.' as Price FROM AccountData WHERE AccountId = :user_id ';
  return $sql;
}

public function getTotalDataFromDailyData(
  EntityInterface $add_data,
  EntityInterface $user_info
  ){
    try {
      $this->db->commit();
      $YM =  date('Y').date('m');
      $sql = $this->getTotalDataFromDailyDataSql();
      $stmt = $this->db->prepare($sql);
      $stmt->bindValue(':YM', $YM, \PDO::PARAM_INT);
      $stmt->bindValue(':ProjectCord', $add_data->getProjectCord(), \PDO::PARAM_STR);
      $stmt->bindValue(':AccountId', $user_info->getLoginId(),\PDO::PARAM_STR);
      $stmt->execute();
      $data = $stmt->fetchAll();
      $project_sum = $this->buildUserDailydata($data[0]);
      return $project_sum;
    } catch (Exception $e) {
    throw $e;

    }

}

private function getTotalDataFromDailyDataSql()
{

  $sql = 'SELECT '
        .' SUM(SubTime) as SubTime, '
        .' Sum(SubMoney) as SubMoney '
        .' FROM DailyData '
        .' WHERE YM = :YM '
        .' AND AccountId = :AccountId '
        .' AND ProjectCord = :ProjectCord ';
  return $sql;
}

public function updateProjectDataTotalTimeAndMoney(
  EntityInterface $project_data,
  EntityInterface $project_sum,
  EntityInterface $user_info,
  $connection,
  $tran = true,
  $date = null
  ){
  if ($date === null) {
            $date = date('m');
    }
    try {
      if($tran)
        {
          $this->db->beginTransaction();
        }
      $total = $this->getAllEntries($user_info, $project_data);
      $sql = $this->updateProjectDataTotalTimeAndMoneySql();
      $stmt = $this->db->prepare($sql);
      $stmt->bindValue(':TotalTime', $total[0], \PDO::PARAM_INT);
      $stmt->bindValue(':TotalMoney', $total[1], \PDO::PARAM_INT);
      $stmt->bindValue(':AccountId', $user_info->getLoginId(), \PDO::PARAM_INT);
      $stmt->bindValue(':ProjectCord', $project_data->getProjectCord(), \PDO::PARAM_STR);
      $stmt->execute();
      if ($tran) {
            $this->db->commit();
      }
    } catch (Exception $e) {
      if ($tran) {
              $this->db->rollBack();
        }
    throw $e;
    }
}

private function updateProjectDataTotalTimeAndMoneySql()
{
  $sql = 'UPDATE MonthData2 '
  .' SET TotalTime = :TotalTime, '
  .' TotalMoney = :TotalMoney '
  .' WHERE AccountId = :AccountId '
  .' AND ProjectCord = :ProjectCord ';
  return $sql;
}

public function insertProjectDataTotalTimeAndMoney(
  EntityInterface $project_data,
  EntityInterface $user_info,
  $connection,
  $tran = true,
  $date = null
  ){
  if ($date === null) {
            $date = date('m');
    }
    try {
      if($tran)
        {
          $this->db->beginTransaction();
        }
      $total = $this->getAllEntries($user_info, $project_data);
      $sql = $this->insertProjectDataTotalTimeAndMoneySql();
      $stmt = $this->db->prepare($sql);
      $stmt->bindValue(':TotalTime', $total[0], \PDO::PARAM_INT);
      $stmt->bindValue(':TotalMoney', $total[1], \PDO::PARAM_INT);
      $stmt->bindValue(':AccountId', $user_info->getLoginId(), \PDO::PARAM_INT);
      $stmt->bindValue(':ProjectCord', $project_data->getProjectCord(), \PDO::PARAM_STR);
      $stmt->execute();
      if ($tran) {
            $this->db->commit();
      }
    } catch (Exception $e) {
      if ($tran) {
              $this->db->rollBack();
        }
    throw $e;
    }
}

private function insertProjectDataTotalTimeAndMoneySql()
{
  $sql = 'UPDATE MonthData2 '
  .' SET TotalTime = :TotalTime, '
  .' TotalMoney = :TotalMoney '
  .' WHERE AccountId = :AccountId '
  .' AND ProjectCord = :ProjectCord ';
  return $sql;
}


public function getAllEntries(EntityInterface $user_info, EntityInterface $project_code)
{
  try{
    $sql =' SELECT * FROM MonthData2 '
         .' WHERE AccountId = :AccountId '
         .' AND ProjectCord = :ProjectCord ';
    $stmt = $this->db->prepare($sql);
    $stmt->bindValue(':AccountId', $user_info->getLoginId(), \PDO::PARAM_INT);
    $stmt->bindValue(':ProjectCord', $project_code->getProjectCord(), \PDO::PARAM_INT);
    $stmt->execute();
    $project_data = $stmt->fetchAll();
    $time_sum = 0;
    $money_sum = 0;
    for ($i=1; $i <=12 ; $i++) { 
      $time_sum = $time_sum + $project_data[0]['Time'.$i];
      $money_sum = $money_sum + $project_data[0]['Money'.$i];
    }
    $sum = array('0' => $time_sum, '1' => $money_sum);
    return $sum;
  } catch (Exception $e) {
    throw $e;
    
  }
}

public function updateProjectDataTimeAndMoney(
  EntityInterface $project_data,
  EntityInterface $project_sum,
  EntityInterface $user_info,
  $connection,
  $tran = true,
  $date = null
  ){
  if ($date === null) {
            $date = date('m');
    }
    try {
      if($tran)
        {
          $this->db->beginTransaction();
        }
      $ptime_var = $this->checkforMonth($date);
      $sql = $this->updateProjectDataTimeAndMoneySql($ptime_var);
      $stmt = $this->db->prepare($sql);
      $stmt->bindValue(':Time', $project_sum->getSubTime(), \PDO::PARAM_INT);
      $stmt->bindValue(':Money', $project_sum->getSubMoney(), \PDO::PARAM_INT);
      $stmt->bindValue(':AccountId', $user_info->getLoginId(), \PDO::PARAM_INT);
      $stmt->bindValue(':ProjectCord', $project_data->getProjectCord(), \PDO::PARAM_INT);
      $stmt->execute();
      if ($tran) {
            $this->db->commit();
      }
    } catch (Exception $e) {
      if ($tran) {
              $this->db->rollBack();
        }
    throw $e;
    }
}

private function updateProjectDataTimeAndMoneySql($i)
{
  $sql = 'UPDATE MonthData2 '
  .' SET Time'.$i.' = :Time, '
  .' Money'.$i.' = :Money '
  .' WHERE AccountId = :AccountId '
  .' AND ProjectCord = :ProjectCord ';
  return $sql;
}

public function insertProjectDataTimeAndMoney(
  EntityInterface $project_data,
  EntityInterface $user_info,
  $connection,
  $tran = true,
  $date = null
  ){
  if ($date === null) {
            $date = date('m');
    }
    try {
      if($tran)
        {
          $this->db->beginTransaction();
        }
        error_log('insertProjectDataTimeAndMoney', 0);
        $month = substr($project_data->getYM(), 4, 2);
       $ptime_var = $this->checkforMonth($month);
     // var_dump($ptime_var);
      //$sql = $this->updateProjectDataTimeAndMoneySql($ptime_var);
      //$sql = $this->insertProjectDataTimeAndMoneySql($ptime_var);
      $sql =  'INSERT INTO MonthData2 ( No, AccountId, Name,MemberY, OPNo, ProjectCord,  ArticleNo, Project, Time'.$ptime_var
	.') VALUES ( :No, :AccountId, :Name, :MemberY, :OPNo, :ProjectCord, :ArticleNo, :Project, :Time)';
//       var_dump($sql);
      $stmt = $this->db->prepare($sql);
      $stmt->bindValue(':No', $this->GetRandomNumber(), \PDO::PARAM_STR);
//       var_dump( $this->GetRandomNumber());
      $stmt->bindValue(':AccountId', $user_info->getLoginId(), \PDO::PARAM_STR);
//      var_dump($user_info->getLoginId());
      $stmt->bindValue(':Name', $user_info->getUserName(), \PDO::PARAM_STR);
//     var_dump($user_info->getUserName());
      $stmt->bindValue(':MemberY', substr($project_data->getYM(), 0, 4), \PDO::PARAM_STR);
//     var_dump(substr($project_data->getYM(), 0, 4));
            $stmt->bindValue('OPNo', $project_data->getOPNo(), \PDO::PARAM_STR);
      $stmt->bindValue(':ProjectCord', $project_data->getProjectCord(), \PDO::PARAM_STR);
//      var_dump($project_data->getProjectCord());
	$stmt->bindValue('ArticleNo', $project_data->getArticleNo(), \PDO::PARAM_STR);
      $stmt->bindValue(':Project', $project_data->getProject(), \PDO::PARAM_STR);
//      var_dump( $project_data->getProject());
      error_log('insertProjectDataTimeAndMoney----1', 0);
      
      error_log('insertProjectDataTimeAndMoney---11-0', 0);
//       error_log($project_data->getTime1()??0, 0);
      $tolalTime = $project_data->getTime1()+ $project_data->getTime2() + $project_data->getTime3() + $project_data->getTime4() + $project_data->getTime5() + $project_data->getTime6() + $project_data->getTime7() + $project_data->getTime8()
		 + $project_data->getTime9() + $project_data->getTime10() + $project_data->getTime11() + $project_data->getTime12() + $project_data->getTime13() + $project_data->getTime14() + $project_data->getTime15() + $project_data->getTime16()
		 + $project_data->getTime17() + $project_data->getTime18() + $project_data->getTime19() + $project_data->getTime20() + $project_data->getTime21() + $project_data->getTime22() + $project_data->getTime23() + $project_data->getTime24()
		 + $project_data->getTime25() + $project_data->getTime26() + $project_data->getTime27() + $project_data->getTime28() + $project_data->getTime29() + $project_data->getTime30() + $project_data->getTime31();
		 error_log('insertProjectDataTimeAndMoney---11-2', 0);
		 $stmt->bindValue(':Time',$tolalTime , \PDO::PARAM_INT);
      error_log('insertProjectDataTimeAndMoney----2', 0);
      //      var_dump($tolalTime);
      $stmt->execute();
  //   var_dump($stmt);
      if ($tran) {
      	error_log('insertProjectDataTimeAndMoney----3', 0);
      	$this->db->commit();
      }
    } catch (Exception $e) {
    	error_log('insertProjectDataTimeAndMoney----e', 0);
     if ($tran) {
              $this->db->rollBack();
       }
       error_log('insertProjectDataTimeAndMoney----4', 0);
       throw $e;
    }
}

private function insertProjectDataTimeAndMoneySql($i)
{
  $sql = 'INSERT INTO MonthData2 ( '
	. ' No, '
	. ' AccountId, '
	. ' Name, '
	.' MemberY, '
	.' ProjectCord, '
	.' Project, '
	.' Time'.$i
	.') VALUES ( '
	.' :No, ' 
            .' :AccountId, '
            .' :Name, ' 
            .' :MemberY, ' 
            .' :ProjectCord, ' 
            .' :Project, ' 
            .' :Time '
            .')';
  return $sql;
}

public function checkforMonth($date)
{
  if ($date <10) {
    $var = str_split($date);
    $ptime_var = $var[1];
  }
  else{
    $ptime_var = $date;
  }
  return $ptime_var;
}

public function deleteUserProject(
  EntityInterface $deletedata,
  EntityInterface $user_info,
  $tran = true,
  $date = null
  ){
  if ($date === null) {
            $date = date('Ym');
    }
    try {
      if($tran)
        {
          $this->db->beginTransaction();
        }
      $sql = $this->getDeleteUserProjectSql2();
      $stmt = $this->db->prepare($sql);
      $stmt->bindValue(':no', $deletedata->getNo(), \PDO::PARAM_INT);
      $stmt->execute();
      if ($tran) {
            $this->db->commit();
      }
    } catch (Exception $e) {
      if ($tran) {
              $this->db->rollBack();
        }
    throw $e;
    }
}

public function UpdateUserProject(
  EntityInterface $update_data,
  EntityInterface $user_info,
  EntityInterface $price,
  $connection,
  $tran = true,
  $date = null
  ){
  if ($date === null) {
            $date = date('Ym');
            if($update_data->getYM()){
                $date = $update_data->getYM();
            }
    }
    try {
      if($tran)
        {
          $connection->beginTransaction();
        }

      $status = "";
      if ($update_data->getStatus() === "未着手") {
	$status = "進行中";
      } else {
	$status = $update_data->getStatus();
      }

      $sql = $this->getUpdateUserProjectSql();
      $stmt = $connection->prepare($sql);
      $stmt->bindValue('no',$update_data->getNo(), \PDO::PARAM_INT);
      $stmt->bindValue(':YM', $date, \PDO::PARAM_INT);
      $stmt->bindValue(':AccountId', $user_info->getLoginId(),\PDO::PARAM_STR);
      $stmt->bindValue('Name', $user_info->getUserName(), \PDO::PARAM_STR);
      $stmt->bindValue('ProjectCord', $update_data->getProjectCord(), \PDO::PARAM_STR);
      $stmt->bindValue('Project', $update_data->getProject(), \PDO::PARAM_STR);
      $stmt->bindValue('Price', $price->getPrice(), \PDO::PARAM_STR);
      $stmt->bindValue('Process1', $update_data->getProcess1(), \PDO::PARAM_STR);
      $stmt->bindValue('Process2', $update_data->getProcess2(), \PDO::PARAM_STR);
      $stmt->bindValue(':Status', $status, \PDO::PARAM_STR);
      $stmt->bindValue('Time1', $update_data->getTime1(), \PDO::PARAM_STR);
      $stmt->bindValue('Time2', $update_data->getTime2(), \PDO::PARAM_STR);
      $stmt->bindValue('Time3', $update_data->getTime3(), \PDO::PARAM_STR);
      $stmt->bindValue('Time4', $update_data->getTime4(), \PDO::PARAM_STR);
      $stmt->bindValue('Time5', $update_data->getTime5(), \PDO::PARAM_STR);
      $stmt->bindValue('Time6', $update_data->getTime6(), \PDO::PARAM_STR);
      $stmt->bindValue('Time7', $update_data->getTime7(), \PDO::PARAM_STR);
      $stmt->bindValue('Time8', $update_data->getTime8(), \PDO::PARAM_STR);
      $stmt->bindValue('Time9', $update_data->getTime9(), \PDO::PARAM_STR);
      $stmt->bindValue('Time10', $update_data->getTime10(), \PDO::PARAM_STR);
      $stmt->bindValue('Time11', $update_data->getTime11(), \PDO::PARAM_STR);
      $stmt->bindValue('Time12', $update_data->getTime12(), \PDO::PARAM_STR);
      $stmt->bindValue('Time13', $update_data->getTime13(), \PDO::PARAM_STR);
      $stmt->bindValue('Time14', $update_data->getTime14(), \PDO::PARAM_STR);
      $stmt->bindValue('Time15', $update_data->getTime15(), \PDO::PARAM_STR);
      $stmt->bindValue('Time16', $update_data->getTime16(), \PDO::PARAM_STR);
      $stmt->bindValue('Time17', $update_data->getTime17(), \PDO::PARAM_STR);
      $stmt->bindValue('Time18', $update_data->getTime18(), \PDO::PARAM_STR);
      $stmt->bindValue('Time19', $update_data->getTime19(), \PDO::PARAM_STR);
      $stmt->bindValue('Time20', $update_data->getTime20(), \PDO::PARAM_STR);
      $stmt->bindValue('Time21', $update_data->getTime21(), \PDO::PARAM_STR);
      $stmt->bindValue('Time22', $update_data->getTime22(), \PDO::PARAM_STR);
      $stmt->bindValue('Time23', $update_data->getTime23(), \PDO::PARAM_STR);
      $stmt->bindValue('Time24', $update_data->getTime24(), \PDO::PARAM_STR);
      $stmt->bindValue('Time25', $update_data->getTime25(), \PDO::PARAM_STR);
      $stmt->bindValue('Time26', $update_data->getTime26(), \PDO::PARAM_STR);
      $stmt->bindValue('Time27', $update_data->getTime27(), \PDO::PARAM_STR);
      $stmt->bindValue('Time28', $update_data->getTime28(), \PDO::PARAM_STR);
      $stmt->bindValue('Time29', $update_data->getTime29(), \PDO::PARAM_STR);
      $stmt->bindValue('Time30', $update_data->getTime30(), \PDO::PARAM_STR);
      $stmt->bindValue('Time31', $update_data->getTime31(), \PDO::PARAM_STR);
      $stmt->bindValue('ArticleNo', $update_data->getArticleNo(), \PDO::PARAM_STR);
      $stmt->bindValue('HouseName', $update_data->getHouseName(), \PDO::PARAM_STR);
      $stmt->execute();

      if ($update_data->getStatus() === "未着手") {
      	$sql2 = $this->updateProjectStatus();
      	$stmt2 = $connection->prepare($sql2);
      	$stmt2->bindValue('Status', $status, \PDO::PARAM_STR);
      	$stmt2->bindValue('ArticleNo', $update_data->getArticleNo(), \PDO::PARAM_STR);
      	$stmt2->execute();

	$sql3 = $this->updateAllDailyDataStatus();
	$stmt3 = $connection->prepare($sql3);
	$stmt3->bindValue('Status', $status, \PDO::PARAM_STR);
	$stmt3->bindValue('ArticleNo', $update_data->getArticleNo(), \PDO::PARAM_STR);
      	$stmt3->execute();
      }

      if ($tran) {
            $connection->commit();

      }
    } catch (Exception $e) {
      if ($tran) {
              $connection->rollBack();
        }
    throw $e;
    }
}

private function getUpdateUserProjectSql()
{
  $sql ='UPDATE DailyData SET '
      . 'YM = :YM, '
      . 'AccountId = :AccountId, '
      . 'Name = :Name, '
      . 'ProjectCord = :ProjectCord, '
      . 'Project = :Project, '
      . 'Price = :Price, '
      . 'Process1 = :Process1, '
      . 'Process2 = :Process2, '
      . 'Status = :Status, '
      . 'Time1 = :Time1, '
      . 'Time2 = :Time2, '
      . 'Time3 = :Time3, '
      . 'Time4 = :Time4, '
      . 'Time5 = :Time5, '
      . 'Time6 = :Time6, '
      . 'Time7 = :Time7, '
      . 'Time8 = :Time8, '
      . 'Time9 = :Time9, '
      . 'Time10 = :Time10, '
      . 'Time11 = :Time11, '
      . 'Time12 = :Time12, '
      . 'Time13 = :Time13, '
      . 'Time14 = :Time14, '
      . 'Time15 = :Time15, '
      . 'Time16 = :Time16, '
      . 'Time17 = :Time17, '
      . 'Time18 = :Time18, '
      . 'Time19 = :Time19, '
      . 'Time20 = :Time20, '
      . 'Time21 = :Time21, '
      . 'Time22 = :Time22, '
      . 'Time23 = :Time23, '
      . 'Time24 = :Time24, '
      . 'Time25 = :Time25, '
      . 'Time26 = :Time26, '
      . 'Time27 = :Time27, '
      . 'Time28 = :Time28, '
      . 'Time29 = :Time29, '
      . 'Time30 = :Time30, '
      . 'Time31 = :Time31, '
      . 'SubTime = :Time1 + :Time2 + :Time3 + :Time4 + :Time5 + :Time6 + :Time7 + :Time8 + :Time9 + :Time10 + '
      . ':Time11 + :Time12 + :Time13 + :Time14 + :Time15 + :Time16 + :Time17 + :Time18 + :Time19 + :Time20 + '
      . ':Time21 + :Time22 + :Time23 + :Time24 + :Time25 + :Time26 + :Time27 + :Time28 + :Time29 + :Time30 + :Time31, '

      . 'SubMoney = (( :Time1 + :Time2 + :Time3 + :Time4 + :Time5 + :Time6 + :Time7 + :Time8 + :Time9 + :Time10 + '
      . ':Time11 + :Time12 + :Time13 + :Time14 + :Time15 + :Time16 + :Time17 + :Time18 + :Time19 + :Time20 + '
      . ':Time21 + :Time22 + :Time23 + :Time24 + :Time25 + :Time26 + :Time27 + :Time28 + :Time29 + :Time30 + :Time31) * :Price), '
      . 'ArticleNo = :ArticleNo, '
      . 'HouseName = :HouseName '
      . 'WHERE No = :no';
      return $sql;
}

private function updateProjectStatus() 
{
   $sql = 'UPDATE ProjectData SET Status = :Status, StartDate = :StartDate  WHERE ArticleNo = :ArticleNo';
   return $sql;
}

private function updateAllDailyDataStatus()
{
   $sql = 'UPDATE DailyData SET Status = :Status, StartDate = :StartDate WHERE ArticleNo = :ArticleNo';
   return $sql;
}

private function getDeleteUserProjectSql()
{

  $sql = 'DELETE FROM DailyData WHERE No = :no ';
  return $sql;
}

private function getDeleteUserProjectSql2()
{

  $sql = 'UPDATE DailyData SET UploadF = 1 WHERE No = :no ';
  return $sql;
}

  public function AddUserProjectAfterCopying(
  EntityInterface $user_info,
  EntityInterface $project,
  $connection,
  $tran = true,
  $date = null
  ) {
    if ($date === null) {
            $date = date('Ym');
    }
    try {
        if($tran)
        {
            $connection->beginTransaction();
        }
	$Ym = date('Ym');
        $sql = $this->insertProjectCopySql();
        $no = $this->GetRandomNumber();
        $stmt = $connection->prepare($sql);
        $stmt->bindValue(':no', $no, \PDO::PARAM_INT);
        $stmt->bindValue(':YM',$Ym, \PDO::PARAM_INT);
        $stmt->bindValue(':AccountId', $project->getAccountId(),\PDO::PARAM_STR);
        $stmt->bindValue(':Name', $project->getName(),\PDO::PARAM_STR);
        $stmt->bindValue('ProjectCord', $project->getProjectcord(), \PDO::PARAM_STR);
        $stmt->bindValue('Project', $project->getProject(), \PDO::PARAM_STR);
        $stmt->bindValue('Price', $project->getPrice(), \PDO::PARAM_STR);
        $stmt->bindValue('Process1', $project->getProcess1(), \PDO::PARAM_STR);
        $stmt->bindValue('Process2', $project->getProcess2(), \PDO::PARAM_STR);
	$stmt->bindValue(':Status', $project->getStatus(), \PDO::PARAM_STR);
	$stmt->bindValue(':Note', $project->getNote(), \PDO::PARAM_STR);
	$stmt->bindValue(':OPNo', $project->getOPNo(), \PDO::PARAM_STR);
	$stmt->bindValue(':ArticleNo', $project->getArticleNo(), \PDO::PARAM_STR);
	$stmt->bindValue(':StartDate', $project->getStartDate(), \PDO::PARAM_STR);
	$stmt->bindValue(':CloseDate', $project->getCloseDate(), \PDO::PARAM_STR);
	$stmt->bindValue(':OP_ArticleNo', $project->getOP_ArticleNo(), \PDO::PARAM_STR);
        $stmt->execute();
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }

private function insertProjectCopySql()
{
  $sql ='INSERT INTO DailyData ( '
      . 'No, '
      . 'YM, '
      . 'AccountId, '
      . 'Name, '
      . 'ProjectCord, '
      . 'Project, '
      . 'Price, '
      . 'Process1, '
      . 'Process2, '
      . 'Status, '
      . 'Note, '
      . 'OPNo, '
      . 'ArticleNo, '
      . 'StartDate, '
      . 'CloseDate, '
      . 'OP_ArticleNo '
      . ') VALUES ( '
      . ':no, '
      . ':YM, '
      . ':AccountId, '
      . ':Name, '
      . ':ProjectCord, '
      . ':Project, '
      . ':Price, '
      . ':Process1, '
      . ':Process2, '
      . ':Status, '
      . ':Note, '
      . ':OPNo, '
      . ':ArticleNo, '
      . ':StartDate, '
      . ':CloseDate, '
      . ':OP_ArticleNo '
      . ') ' ;
  return $sql;
}



public function AddNewUserProject(
  EntityInterface $daily_report,
  EntityInterface $user_info,
  EntityInterface $numberentity,
  EntityInterface $price,
  $connection,
  $tran = true,
  $date = null
  ) 
{
    if ($date === null) {
    	$date = date('Ym');
        if($daily_report->getYM()){
        	$date = $daily_report->getYM();
        }
    }
    try {
        if($tran) {
            $connection->beginTransaction();
        }

      $status = "";
      if ($daily_report->getStatus() === "未着手") {
	$status = "進行中";
      } else {
	$status = $daily_report->getStatus();
      }

        $sql = $this->insertNewProjectSql();
        $SubTime = 31;
        $stmt = $connection->prepare($sql);
        $stmt->bindValue(':no', $numberentity->getNumber(), \PDO::PARAM_INT);
        $stmt->bindValue(':opno', $daily_report->getOPNo(), \PDO::PARAM_STR);
        $stmt->bindValue(':YM', $date, \PDO::PARAM_INT);
        $stmt->bindValue(':AccountId', $user_info->getLoginId(),\PDO::PARAM_STR);
        $stmt->bindValue('Name', $user_info->getUserName(), \PDO::PARAM_STR);
        $stmt->bindValue('ProjectCord', $daily_report->getProjectCord(), \PDO::PARAM_STR);
        $stmt->bindValue('Project', $daily_report->getProject(), \PDO::PARAM_STR);
        $stmt->bindValue('ArticleNo', $daily_report->getArticleNo(), \PDO::PARAM_STR);
	$stmt->bindValue('HouseName', $daily_report->getHouseName(), \PDO::PARAM_STR);
        $stmt->bindValue('Price', $price->getPrice(), \PDO::PARAM_INT);
        $stmt->bindValue('Process1', $daily_report->getProcess1(), \PDO::PARAM_STR);
        $stmt->bindValue('Process2', $daily_report->getProcess2(), \PDO::PARAM_STR);
	$stmt->bindValue(':Status', $status, \PDO::PARAM_STR);
	$stmt->bindValue('StartDate', $daily_report->getStartDate(), \PDO::PARAM_STR);
	$stmt->bindValue('CloseDate', $daily_report->getCloseDate(), \PDO::PARAM_STR);
        $stmt->bindValue('Time1', $daily_report->getTime1(), \PDO::PARAM_STR);
        $stmt->bindValue('Time2', $daily_report->getTime2(), \PDO::PARAM_STR);
        $stmt->bindValue('Time3', $daily_report->getTime3(), \PDO::PARAM_STR);
        $stmt->bindValue('Time4', $daily_report->getTime4(), \PDO::PARAM_STR);
        $stmt->bindValue('Time5', $daily_report->getTime5(), \PDO::PARAM_STR);
        $stmt->bindValue('Time6', $daily_report->getTime6(), \PDO::PARAM_STR);
        $stmt->bindValue('Time7', $daily_report->getTime7(), \PDO::PARAM_STR);
        $stmt->bindValue('Time8', $daily_report->getTime8(), \PDO::PARAM_STR);
        $stmt->bindValue('Time9', $daily_report->getTime9(), \PDO::PARAM_STR);
        $stmt->bindValue('Time10', $daily_report->getTime10(), \PDO::PARAM_STR);
        $stmt->bindValue('Time11', $daily_report->getTime11(), \PDO::PARAM_STR);
        $stmt->bindValue('Time12', $daily_report->getTime12(), \PDO::PARAM_STR);
        $stmt->bindValue('Time13', $daily_report->getTime13(), \PDO::PARAM_STR);
        $stmt->bindValue('Time14', $daily_report->getTime14(), \PDO::PARAM_STR);
        $stmt->bindValue('Time15', $daily_report->getTime15(), \PDO::PARAM_STR);
        $stmt->bindValue('Time16', $daily_report->getTime16(), \PDO::PARAM_STR);
        $stmt->bindValue('Time17', $daily_report->getTime17(), \PDO::PARAM_STR);
        $stmt->bindValue('Time18', $daily_report->getTime18(), \PDO::PARAM_STR);
        $stmt->bindValue('Time19', $daily_report->getTime19(), \PDO::PARAM_STR);
        $stmt->bindValue('Time20', $daily_report->getTime20(), \PDO::PARAM_STR);
        $stmt->bindValue('Time21', $daily_report->getTime21(), \PDO::PARAM_STR);
        $stmt->bindValue('Time22', $daily_report->getTime22(), \PDO::PARAM_STR);
        $stmt->bindValue('Time23', $daily_report->getTime23(), \PDO::PARAM_STR);
        $stmt->bindValue('Time24', $daily_report->getTime24(), \PDO::PARAM_STR);
        $stmt->bindValue('Time25', $daily_report->getTime25(), \PDO::PARAM_STR);
        $stmt->bindValue('Time26', $daily_report->getTime26(), \PDO::PARAM_STR);
        $stmt->bindValue('Time27', $daily_report->getTime27(), \PDO::PARAM_STR);
        $stmt->bindValue('Time28', $daily_report->getTime28(), \PDO::PARAM_STR);
        $stmt->bindValue('Time29', $daily_report->getTime29(), \PDO::PARAM_STR);
        $stmt->bindValue('Time30', $daily_report->getTime30(), \PDO::PARAM_STR);
        $stmt->bindValue('Time31', $daily_report->getTime31(), \PDO::PARAM_STR);
	$stmt->bindValue(':OP_ArticleNo', $daily_report->getOPNo().$daily_report->getArticleNo(), \PDO::PARAM_STR);
//var_dump($stmt);
//echo PHP_EOL.'price: '.$user_info->getUserName();
//echo PHP_EOL.'name: '.$user_info->getLoginId();
//echo $numberentity->getNumber();
        $stmt->execute();

          if ($daily_report->getStatus() === "未着手") {
	$startDate = date("Y-m-d");
      	$sql2 = $this->updateProjectStatus();
      	$stmt2 = $connection->prepare($sql2);
      	$stmt2->bindValue('Status', $status, \PDO::PARAM_STR);
      	$stmt2->bindValue('StartDate', $startDate, \PDO::PARAM_STR);
      	$stmt2->bindValue('ArticleNo', $daily_report->getArticleNo(), \PDO::PARAM_STR);
      	$stmt2->execute();

	$sql3 = $this->updateAllDailyDataStatus();
	$stmt3 = $connection->prepare($sql3);
	$stmt3->bindValue('Status', $status, \PDO::PARAM_STR);
      	$stmt3->bindValue('StartDate', $startDate, \PDO::PARAM_STR);
	$stmt3->bindValue('ArticleNo', $daily_report->getArticleNo(), \PDO::PARAM_STR);
      	$stmt3->execute();
      }

            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }
private function insertNewProjectSql()
{
  $sql ='INSERT INTO DailyData ( '
      . 'No, '
      . 'OPNo, '
      . 'YM, '
      . 'AccountId, '
      . 'Name, '
      . 'ProjectCord, '
      . 'Project, '
      . 'Price, '
      . 'Process1, '
      . 'Process2, '
      . 'Status, '
      . 'StartDate, '
      . 'CloseDate, '
      . 'Time1, '
      . 'Time2, '
      . 'Time3, '
      . 'Time4, '
      . 'Time5, '
      . 'Time6, '
      . 'Time7, '
      . 'Time8, '
      . 'Time9, '
      . 'Time10, '
      . 'Time11, '
      . 'Time12, '
      . 'Time13, '
      . 'Time14, '
      . 'Time15, '
      . 'Time16, '
      . 'Time17, '
      . 'Time18, '
      . 'Time19, '
      . 'Time20, '
      . 'Time21, '
      . 'Time22, '
      . 'Time23, '
      . 'Time24, '
      . 'Time25, '
      . 'Time26, '
      . 'Time27, '
      . 'Time28, '
      . 'Time29, '
      . 'Time30, '
      . 'Time31, '
      . 'SubTime, '
      . 'SubMoney, '
      . 'ArticleNo, '
      . 'HouseName, '
      . 'OP_ArticleNo '
      . ') VALUES ( '
      . ':no, '
      . ':opno, '
      . ':YM, '
      . ':AccountId, '
      . ':Name, '
      . ':ProjectCord, '
      . ':Project, '
      . ':Price, '
      . ':Process1, '
      . ':Process2, '
      . ':Status, '
      . ':StartDate, '
      . ':CloseDate, '
      . ':Time1, '
      . ':Time2, '
      . ':Time3, '
      . ':Time4, '
      . ':Time5, '
      . ':Time6, '
      . ':Time7, '
      . ':Time8, '
      . ':Time9, '
      . ':Time10, '
      . ':Time11, '
      . ':Time12, '
      . ':Time13, '
      . ':Time14, '
      . ':Time15, '
      . ':Time16, '
      . ':Time17, '
      . ':Time18, '
      . ':Time19, '
      . ':Time20, '
      . ':Time21, '
      . ':Time22, '
      . ':Time23, '
      . ':Time24, '
      . ':Time25, '
      . ':Time26, '
      . ':Time27, '
      . ':Time28, '
      . ':Time29, '
      . ':Time30, '
      . ':Time31, '
      . ':Time1 + :Time2 + :Time3 + :Time4 + :Time5 + :Time6 + :Time7 + :Time8 + :Time9 + :Time10 + '
      . ':Time11 + :Time12 + :Time13 + :Time14 + :Time15 + :Time16 + :Time17 + :Time18 + :Time19 + :Time20 + '
      . ':Time21 + :Time22 + :Time23 + :Time24 + :Time25 + :Time26 + :Time27 + :Time28 + :Time29 + :Time30 + :Time31, '

      . '(:Time1 + :Time2 + :Time3 + :Time4 + :Time5 + :Time6 + :Time7 + :Time8 + :Time9 + :Time10 + '
      . ':Time11 + :Time12 + :Time13 + :Time14 + :Time15 + :Time16 + :Time17 + :Time18 + :Time19 + :Time20 + '
      . ':Time21 + :Time22 + :Time23 + :Time24 + :Time25 + :Time26 + :Time27 + :Time28 + :Time29 + :Time30 + :Time31 )* :Price, '
      . ':ArticleNo, ' 
      . ':HouseName, ' 
      . ':OP_ArticleNo '
      . ') ';
  return $sql;
}

public function AddHolidayData(
  EntityInterface $holiday_data,
  EntityInterface $user_info,
  $connection,
  $tran = true,
  $date = null
  ) {
    if ($date === null) {
        $date = date('Ym');
        if($holiday_data->getHolidayYM()){
            $date = $holiday_data->getHolidayYM();
        }
    }
    try {
        if($tran)
        {
            $connection->beginTransaction();
        }
        $sql = $this->insertHolidayDatSql();
        $no = $this->GetRandomNumber();
        $stmt = $connection->prepare($sql);
        $stmt->bindValue(':no', $no, \PDO::PARAM_INT);
        $stmt->bindValue(':HolidayYM', $date, \PDO::PARAM_INT);
        $stmt->bindValue(':AccountId', $user_info->getLoginId(),\PDO::PARAM_STR);
        $stmt->bindValue('Name', $user_info->getUserName(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday1', $holiday_data->getHoliday1(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday2', $holiday_data->getHoliday2(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday3', $holiday_data->getHoliday3(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday4', $holiday_data->getHoliday4(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday5', $holiday_data->getHoliday5(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday6', $holiday_data->getHoliday6(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday7', $holiday_data->getHoliday7(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday8', $holiday_data->getHoliday8(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday9', $holiday_data->getHoliday9(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday10', $holiday_data->getHoliday10(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday11', $holiday_data->getHoliday11(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday12', $holiday_data->getHoliday12(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday13', $holiday_data->getHoliday13(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday14', $holiday_data->getHoliday14(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday15', $holiday_data->getHoliday15(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday16', $holiday_data->getHoliday16(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday17', $holiday_data->getHoliday17(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday18', $holiday_data->getHoliday18(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday19', $holiday_data->getHoliday19(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday20', $holiday_data->getHoliday20(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday21', $holiday_data->getHoliday21(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday22', $holiday_data->getHoliday22(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday23', $holiday_data->getHoliday23(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday24', $holiday_data->getHoliday24(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday25', $holiday_data->getHoliday25(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday26', $holiday_data->getHoliday26(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday27', $holiday_data->getHoliday27(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday28', $holiday_data->getHoliday28(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday29', $holiday_data->getHoliday29(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday30', $holiday_data->getHoliday30(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday31', $holiday_data->getHoliday31(), \PDO::PARAM_STR);
        $stmt->execute();
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }    

private function insertHolidayDatSql()
{
  $sql ='INSERT INTO HolidayData ( '
      . 'No, '
      . 'HolidayYM, '
      . 'AccountId, '
      . 'Name, '
      . 'Holiday1, '
      . 'Holiday2, '
      . 'Holiday3, '
      . 'Holiday4, '
      . 'Holiday5, '
      . 'Holiday6, '
      . 'Holiday7, '
      . 'Holiday8, '
      . 'Holiday9, '
      . 'Holiday10, '
      . 'Holiday11, '
      . 'Holiday12, '
      . 'Holiday13, '
      . 'Holiday14, '
      . 'Holiday15, '
      . 'Holiday16, '
      . 'Holiday17, '
      . 'Holiday18, '
      . 'Holiday19, '
      . 'Holiday20, '
      . 'Holiday21, '
      . 'Holiday22, '
      . 'Holiday23, '
      . 'Holiday24, '
      . 'Holiday25, '
      . 'Holiday26, '
      . 'Holiday27, '
      . 'Holiday28, '
      . 'Holiday29, '
      . 'Holiday30, '
      . 'Holiday31 '
      
      . ') VALUES ( '
      . ':no, '
      . ':HolidayYM, '
      . ':AccountId, '
      . ':Name, '
      . ':Holiday1, '
      . ':Holiday2, '
      . ':Holiday3, '
      . ':Holiday4, '
      . ':Holiday5, '
      . ':Holiday6, '
      . ':Holiday7, '
      . ':Holiday8, '
      . ':Holiday9, '
      . ':Holiday10, '
      . ':Holiday11, '
      . ':Holiday12, '
      . ':Holiday13, '
      . ':Holiday14, '
      . ':Holiday15, '
      . ':Holiday16, '
      . ':Holiday17, '
      . ':Holiday18, '
      . ':Holiday19, '
      . ':Holiday20, '
      . ':Holiday21, '
      . ':Holiday22, '
      . ':Holiday23, '
      . ':Holiday24, '
      . ':Holiday25, '
      . ':Holiday26, '
      . ':Holiday27, '
      . ':Holiday28, '
      . ':Holiday29, '
      . ':Holiday30, '
      . ':Holiday31 '
      
      . ') ' ;
  return $sql;
}

public function UpdateHolidayData(
  EntityInterface $holiday_data,
  EntityInterface $user_info,
  $connection,
  $tran = true,
  $date = null
  ){
  if ($date === null) {
        $date = date('Ym');
        if($holiday_data->getHolidayYM()){
            $date = $holiday_data->getHolidayYM();
        }
    }
    try {
      if($tran)
        {
          $connection->beginTransaction();
        }
        
      $sql = $this->UpdateUserHolidaySql();
      $stmt = $connection->prepare($sql);
      $stmt->bindValue(':HolidayYM', $date, \PDO::PARAM_INT);
        $stmt->bindValue(':AccountId', $user_info->getLoginId(),\PDO::PARAM_STR);
        $stmt->bindValue('Holiday1', $holiday_data->getHoliday1(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday2', $holiday_data->getHoliday2(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday3', $holiday_data->getHoliday3(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday4', $holiday_data->getHoliday4(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday5', $holiday_data->getHoliday5(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday6', $holiday_data->getHoliday6(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday7', $holiday_data->getHoliday7(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday8', $holiday_data->getHoliday8(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday9', $holiday_data->getHoliday9(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday10', $holiday_data->getHoliday10(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday11', $holiday_data->getHoliday11(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday12', $holiday_data->getHoliday12(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday13', $holiday_data->getHoliday13(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday14', $holiday_data->getHoliday14(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday15', $holiday_data->getHoliday15(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday16', $holiday_data->getHoliday16(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday17', $holiday_data->getHoliday17(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday18', $holiday_data->getHoliday18(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday19', $holiday_data->getHoliday19(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday20', $holiday_data->getHoliday20(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday21', $holiday_data->getHoliday21(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday22', $holiday_data->getHoliday22(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday23', $holiday_data->getHoliday23(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday24', $holiday_data->getHoliday24(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday25', $holiday_data->getHoliday25(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday26', $holiday_data->getHoliday26(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday27', $holiday_data->getHoliday27(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday28', $holiday_data->getHoliday28(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday29', $holiday_data->getHoliday29(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday30', $holiday_data->getHoliday30(), \PDO::PARAM_STR);
        $stmt->bindValue('Holiday31', $holiday_data->getHoliday31(), \PDO::PARAM_STR);
      $stmt->execute();
      if ($tran) {
            $connection->commit();

      }
    } catch (Exception $e) {
      if ($tran) {
              $connection->rollBack();
        }
    throw $e;
    }
}

private function UpdateUserHolidaySql()
{
  $sql ='UPDATE HolidayData SET '
      . 'Holiday1 = :Holiday1, '
      . 'Holiday2 = :Holiday2, '
      . 'Holiday3 = :Holiday3, '
      . 'Holiday4 = :Holiday4, '
      . 'Holiday5 = :Holiday5, '
      . 'Holiday6 = :Holiday6, '
      . 'Holiday7 = :Holiday7, '
      . 'Holiday8 = :Holiday8, '
      . 'Holiday9 = :Holiday9, '
      . 'Holiday10 = :Holiday10, '
      . 'Holiday11 = :Holiday11, '
      . 'Holiday12 = :Holiday12, '
      . 'Holiday13 = :Holiday13, '
      . 'Holiday14 = :Holiday14, '
      . 'Holiday15 = :Holiday15, '
      . 'Holiday16 = :Holiday16, '
      . 'Holiday17 = :Holiday17, '
      . 'Holiday18 = :Holiday18, '
      . 'Holiday19 = :Holiday19, '
      . 'Holiday20 = :Holiday20, '
      . 'Holiday21 = :Holiday21, '
      . 'Holiday22 = :Holiday22, '
      . 'Holiday23 = :Holiday23, '
      . 'Holiday24 = :Holiday24, '
      . 'Holiday25 = :Holiday25, '
      . 'Holiday26 = :Holiday26, '
      . 'Holiday27 = :Holiday27, '
      . 'Holiday28 = :Holiday28, '
      . 'Holiday29 = :Holiday29, '
      . 'Holiday30 = :Holiday30, '
      . 'Holiday31 = :Holiday31 '
      . 'WHERE AccountId = :AccountId And HolidayYM = :HolidayYM';
      return $sql;
}


  public function GetRandomNumber()
  {
    $randnum = rand(100000,999999);
    $date= date("YmdHis");
    $no = $date*100000+$randnum;
    return $no;
  }

 public function releaseLockDay(
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('j');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            // if ($date>=2) {
            //   return false;
            // }
            $sql = $this->releaseLockDaySql();
            $stmt = $connection->prepare($sql);
            $stmt->bindValue('lock_flag', '0', \PDO::PARAM_STR); 
            $stmt->execute();
            
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }

  private function releaseLockDaySql()
  {
    $sql ='UPDATE `manual_lock` SET '
        . '`lock_flag`= :lock_flag WHERE 1';
    return $sql;
  }


 public function insertLockDay(
        EntityInterface $lockdata,
        $lock_flag,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            $sql = $this->insertlock();
            $stmt = $connection->prepare($sql);
            $stmt->bindValue('lock_day', $lockdata->getlockDay(), \PDO::PARAM_STR);
            $stmt->bindValue('lock_flag',$lock_flag, \PDO::PARAM_STR);
            $stmt->execute();
            
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }
            return false;
        }
    }
 private function insertlock()
  {
    $sql ='UPDATE `manual_lock` SET '
        . '`lock_day`= :lock_day, `lock_flag`= :lock_flag WHERE 1';
    return $sql;
  }


public function buildDailyReport(Array $paramaters)
{
  $entity = new UserDailyDataEntity;
  $entity->setProperties($paramaters);
  return $entity;
}

public function buildManualLock(Array $paramaters)
{
  $entity = new LockEntity;
  $entity->setProperties($paramaters);
  return $entity;
}

    public function buildHolidayEntity($paramaters)
    {
      $entity = new HolidayEntity;
      $entity->setProperties($paramaters);
      return $entity;
    }

    public function buildmonthInfo($paramaters)
    {
      $entity = new UserProjectsEntity;
      $entity->setselectedmonth($paramaters);
      return $entity;
    }

    public function builAddMember(array $paramaters)
    {
      $entity = new AllMembersEntity;
      $entity->setProperties($paramaters);
      return $entity;
    }

    public function add(EntityInterface $entity)
    {
        return;
    }
    /**
     * @param EntityInterface $entity
     */
    public function remove(EntityInterface $entity)
    {
        return;
    }

    public function buildUserprojects(array $parameters)
    {
        $entity = new UserProjectsEntity();
        $entity->setProperties($parameters);
        return $entity;
    }

    public function buildProcess(array $parameters)
    {
        $entity = new ProcessEntity();
        $entity->setProperties($parameters);
        return $entity;
    }

    

        public function buildUserEntity(array $parameters)
    {
        $entity = new UserEntity();
        $entity->setProperties($parameters);
        return $entity;
    }

    public function buildUserDailydata(array $parameters)
    {
          $entity = new UserDailyDataEntity();
          $entity->setProperties($parameters);
          return $entity;
    }

        public function buildUserInfo(array $parameters)
    {
          $entity = new UserEntity();
          $entity->setProperties($parameters);
          // if (array_key_exists('AccountId', $parameters)) {
          //   $entity->setUserName(mb_convert_kana($parameters['AccountId']));
          // }
          // if (array_key_exists('Name', $parameters)) {
          //   $entity->setUserName(mb_convert_kana($parameters['Name']));
          // }
          // if (array_key_exists('EMail', $parameters)) {
          //   $entity->setUserName(mb_convert_kana($parameters['EMail']));
          // }
          return $entity;
    }

}
