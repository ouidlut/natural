<?php
namespace App\Repositories;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use App\Entities\LoginInfoEntity;
use App\Entities\UserEntity;
use App\Entities\UserProjectsEntity;
use App\Entities\UserDailyDataEntity;
use App\Entities\AllProjectsEntity;
use App\Entities\NewUserEntity;
use Doctrine\DBAL\Connection;
use Symfony\Component\HttpFoundation\Session\Session;
use Carbon\Carbon;


class CsvDownloadRepository implements RepositoryInterface
{

  protected $db;
  protected $uuid;

  public function __construct(Connection $db)
  {
      $this->db = $db;
  }

  public function findGyoshuBestuCF($YM ,$sort) //業種別(CF)
  {
        try {
            if(empty($YM)){
                $YM =  date('Ym');
            }
            if(date("m", strtotime($YM))<4){
                $between1 = date("Ym", strtotime((date("Y", strtotime($YM))-1).'-04-01'));
                $between2 = date("Ym", strtotime(date("Y", strtotime($YM)).'-03-01'));
                $Y = date("Y", strtotime($YM))-1;
                $dl = (date("Y", strtotime($YM))-1).'-04-01';
            }else{
                $between1 = date("Ym", strtotime(date("Y", strtotime($YM)).'-04-01'));
                $between2 = date("Ym", strtotime((date("Y", strtotime($YM))+1).'-03-01'));
                $Y = date("Y", strtotime($YM));
                $dl = (date("Y", strtotime($YM))).'-04-01';
            }

            if(date("m")<4){
                $TCheck = date("Ym", strtotime((date("Y")-1).'-04-01'));
                $SY = date("Y", strtotime((date("Y")-1).'-04-01'));
            }else{
                $TCheck = date("Ym", strtotime((date("Y")).'-04-01'));
                $SY = date("Y", strtotime((date("Y")).'-04-01'));
            }
            $stmt = $this->db->prepare(
            'SELECT DISTINCT BusinessType FROM ProjectData '
            );
            $stmt->execute();
            $all_type = $stmt->fetchAll();

            foreach ($all_type as $key => $type) {
                if(!empty($type['BusinessType'])){
                    $result[$key] = array(
                        'BusinessType' => $type['BusinessType']
                    );
                    $stmt1 = $this->db->prepare( //当月(PL)
                        'SELECT PMO, Accounting  FROM PMO '
                        .'WHERE BusinessType = :BusinessType '
                        .'LIMIT  1'
                    );
                    $stmt1->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt1->execute();
                    $pmo = $stmt1->fetchAll();
                    $result[$key]['PMO'] = '';
                    $result[$key]['Accounting'] = '';
                    if(!empty($pmo)){
                        $result[$key]['PMO'] = $pmo[0]['PMO'];
                        $result[$key]['Accounting'] = $pmo[0]['Accounting'];
                    }
                    $stmt2 = $this->db->prepare( //当月(CF)
                    'SELECT AccountData.PriceGroup, SUM(ProjectData.Budget) Budget ,SUM(SubTime) Time,'
                    . 'SUM(SubMoney) Money, PMO.PMO, PMO.Accounting '
                    . ' FROM DailyData '
                    . 'LEFT JOIN ProjectData ON ProjectData.ProjectCord = DailyData.ProjectCord '
                    . 'LEFT JOIN PMO ON PMO.BusinessType = ProjectData.BusinessType '
                    . 'LEFT JOIN AccountData ON AccountData.AccountId = DailyData.AccountId '
                    .'WHERE ProjectData.BusinessType = :BusinessType AND YM = :YM '
                    .'GROUP BY AccountData.PriceGroup '
                    // .'LIMIT 1'
                    );
                    $stmt2->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt2->bindValue('YM',$YM, \PDO::PARAM_STR);
                    $stmt2->execute();
                    $month_data = $stmt2->fetchAll();
                    $result[$key]['toMonth'] = $month_data;

                    $stmt3 = $this->db->prepare( //経過月(CF)
                    'SELECT AccountData.PriceGroup, SUM(ProjectData.Budget) PMoney ,SUM(SubMoney) Money,'
                    . ' SUM(SubTime) Time'
                    . ' FROM DailyData '
                    . 'LEFT JOIN ProjectData ON ProjectData.ProjectCord = DailyData.ProjectCord '
                    . 'LEFT JOIN AccountData ON AccountData.AccountId = DailyData.AccountId '
                    .'WHERE ProjectData.BusinessType = :BusinessType AND '
                    .'YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
                    .'GROUP BY AccountData.PriceGroup'
                    );
                    $stmt3->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt3->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
                    $stmt3->bindValue('BETWEEN2',$YM, \PDO::PARAM_STR);
                    $stmt3->execute();
                    $em_data = $stmt3->fetchAll();
                    $result[$key]['elapsedMonth'] = $em_data;

                    $stmt4 = $this->db->prepare( //年間(CF)
                    'SELECT AccountData.PriceGroup, SUM(ProjectData.Budget) PMoney ,SUM(SubMoney) Money,'
                    . 'SUM(SubTime) Time'
                    . ' FROM DailyData '
                    . 'LEFT JOIN ProjectData ON ProjectData.ProjectCord = DailyData.ProjectCord '
                    . 'LEFT JOIN AccountData ON AccountData.AccountId = DailyData.AccountId '
                    .'WHERE ProjectData.BusinessType = :BusinessType AND '
                    .'YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
                    .'GROUP BY AccountData.PriceGroup'
                    );
                    $stmt4->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt4->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
                    $stmt4->bindValue('BETWEEN2',$between2, \PDO::PARAM_STR);
                    $stmt4->execute();
                    $year_data = $stmt4->fetchAll();
                    $result[$key]['toYear'] = $year_data;

                }
            }
            return $result;
        }
        catch (\Exception $e) {
            throw $e;
        }
    }

public function findGyoshuBestuPL($YM)  //業種別PL
  {
        try {

            if(empty($YM)){
                $YM =  date('Ym');
            }
            if(date("m", strtotime($YM))<4){
                $between1 = date("Ym", strtotime((date("Y", strtotime($YM))-1).'-04-01'));
                $between2 = date("Ym", strtotime(date("Y", strtotime($YM)).'-03-01'));
                $Y = date("Y", strtotime($YM))-1;
                $dl = (date("Y", strtotime($YM))-1).'-04-01';
            }else{
                $between1 = date("Ym", strtotime(date("Y", strtotime($YM)).'-04-01'));
                $between2 = date("Ym", strtotime((date("Y", strtotime($YM))+1).'-03-01'));
                $Y = date("Y", strtotime($YM));
                $dl = (date("Y", strtotime($YM))).'-04-01';
            }
            if(date("m")<4){
                $TCheck = date("Ym", strtotime((date("Y")-1).'-04-01'));
                $SY = date("Y", strtotime((date("Y")-1).'-04-01'));
            }else{
                $TCheck = date("Ym", strtotime((date("Y")).'-04-01'));
                $SY = date("Y", strtotime((date("Y")).'-04-01'));
            }
            $stmt = $this->db->prepare(
            'SELECT DISTINCT BusinessType FROM ProjectData '
            );
            $stmt->execute();
            $all_type = $stmt->fetchAll();

            foreach ($all_type as $key => $type) {
                if(!empty($type['BusinessType'])){
                    $result[$key] = array(
                        'BusinessType' => $type['BusinessType']
                    );
                    $stmt1 = $this->db->prepare( //当月(PL)
                    'SELECT PMO,Accounting  FROM PMO '
                    .'WHERE BusinessType = :BusinessType '
                    .'LIMIT  1'
                    );
                    $stmt1->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt1->execute();
                    $pmo = $stmt1->fetchAll();
                    $result[$key]['PMO'] = '';
                    $result[$key]['Accounting'] = '';
                    if(!empty($pmo)){
                        $result[$key]['PMO'] = $pmo[0]['PMO'];
                        $result[$key]['Accounting'] = $pmo[0]['Accounting'];
                    }
                    $stmt2 = $this->db->prepare( //当月(PL)
                    'SELECT AccountData.PriceGroup, SUM(ProjectData.Budget) Budget ,SUM(SubTime) Time,'
                    . 'SUM(SubMoney) Money'
                    . ' FROM DailyData '
                    . 'LEFT JOIN ProjectData ON ProjectData.ProjectCord = DailyData.ProjectCord '
                    . 'LEFT JOIN AccountData ON AccountData.AccountId = DailyData.AccountId '
                    .'WHERE ProjectData.BusinessType = :BusinessType AND YM = :YM '
                    .'AND Process1 BETWEEN 100 AND 199 '
                    .'GROUP BY AccountData.PriceGroup'
                    );
                    $stmt2->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt2->bindValue('YM',$YM, \PDO::PARAM_STR);
                    $stmt2->execute();
                    $month_data = $stmt2->fetchAll();
                    $result[$key]['toMonth'] = $month_data;

                    $stmt3 = $this->db->prepare( //経過月(PL)
                    'SELECT AccountData.PriceGroup, SUM(ProjectData.Budget) PMoney ,SUM(SubMoney) Money,'
                    . 'SUM(SubTime) '
                    . ' FROM DailyData '
                    . 'LEFT JOIN ProjectData ON ProjectData.ProjectCord = DailyData.ProjectCord '
                    . 'LEFT JOIN AccountData ON AccountData.AccountId = DailyData.AccountId '
                    .'WHERE ProjectData.BusinessType = :BusinessType AND '
                    .'YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
                    .'AND Process1 BETWEEN 100 AND 199 '
                    .'GROUP BY AccountData.PriceGroup'
                    );
                    $stmt3->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt3->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
                    $stmt3->bindValue('BETWEEN2',$YM, \PDO::PARAM_STR);
                    $stmt3->execute();
                    $em_data = $stmt3->fetchAll();
                    $result[$key]['elapsedMonth'] = $em_data;

                    $stmt4 = $this->db->prepare( //年間(PL)
                    'SELECT AccountData.PriceGroup, SUM(ProjectData.Budget) PMoney ,SUM(SubMoney) Money,'
                    . 'SUM(SubTime) '
                    . ' FROM DailyData '
                    . 'LEFT JOIN ProjectData ON ProjectData.ProjectCord = DailyData.ProjectCord '
                    . 'LEFT JOIN AccountData ON AccountData.AccountId = DailyData.AccountId '
                    .'WHERE ProjectData.BusinessType = :BusinessType AND '
                    .'YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
                    .'AND Process1 BETWEEN 100 AND 199 '
                    .'GROUP BY AccountData.PriceGroup'
                    );
                    $stmt4->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt4->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
                    $stmt4->bindValue('BETWEEN2',$between2, \PDO::PARAM_STR);
                    $stmt4->execute();
                    $year_data = $stmt4->fetchAll();
                    $result[$key]['toYear'] = $year_data;
                }
            }
            return $result;
        }
        catch (\Exception $e) {
            throw $e;
        }
    }

    public function findProductBetsuCF($YM) //プロダクト別(CF)
  {
        try {
            if(empty($YM)){
                $YM =  date('Ym');
            }
            if(date("m", strtotime($YM))<4){
                $between1 = date("Ym", strtotime((date("Y", strtotime($YM))-1).'-04-01'));
                $between2 = date("Ym", strtotime(date("Y", strtotime($YM)).'-03-01'));
                $Y = date("Y", strtotime($YM))-1;
                $dl = (date("Y", strtotime($YM))-1).'-04-01';
            }else{
                $between1 = date("Ym", strtotime(date("Y", strtotime($YM)).'-04-01'));
                $between2 = date("Ym", strtotime((date("Y", strtotime($YM))+1).'-03-01'));
                $Y = date("Y", strtotime($YM));
                $dl = (date("Y", strtotime($YM))).'-04-01';
            }
            if(date("m")<4){
                $TCheck = date("Ym", strtotime((date("Y")-1).'-04-01'));
                $SY = date("Y", strtotime((date("Y")-1).'-04-01'));
            }else{
                $TCheck = date("Ym", strtotime((date("Y")).'-04-01'));
                $SY = date("Y", strtotime((date("Y")).'-04-01'));
            }
            $stmt = $this->db->prepare(
            'SELECT DISTINCT BusinessType, Product FROM ProjectData '
            );
            $stmt->execute();
            $all_type = $stmt->fetchAll();
            foreach ($all_type as $key => $type) {
                if(!empty($type['BusinessType'])){
                    $result[$key] = array(
                        'BusinessType' => $type['BusinessType'],
                        'Product' => $type['Product']
                    );
                    $stmt1 = $this->db->prepare( //当月(PL)
                    'SELECT PMO, Accounting  FROM PMO '
                    .'WHERE BusinessType = :BusinessType '
                    .'LIMIT  1'
                    );
                    $stmt1->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt1->execute();
                    $pmo = $stmt1->fetchAll();
                    $result[$key]['PMO'] = '';
                    $result[$key]['Accounting'] = '';
                    if(!empty($pmo)){
                    $result[$key]['PMO'] = $pmo[0]['PMO'];
                        $result[$key]['Accounting'] = $pmo[0]['Accounting'];
                    }
                    $stmt2 = $this->db->prepare( //当月(CF)
                    'SELECT AccountData.PriceGroup, SUM(ProjectData.Budget) Budget ,'
                    . 'SUM(SubTime) Time,SUM(SubMoney) Money, PMO.PMO, PMO.Accounting '
                    . ' FROM DailyData '
                    . 'LEFT JOIN ProjectData ON ProjectData.ProjectCord = DailyData.ProjectCord '
                    . 'LEFT JOIN PMO ON PMO.BusinessType = ProjectData.BusinessType '
                    . 'LEFT JOIN AccountData ON AccountData.AccountId = DailyData.AccountId '
                    .'WHERE ProjectData.BusinessType = :BusinessType AND YM = :YM '
                    .'GROUP BY AccountData.PriceGroup'
                    );
                    $stmt2->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt2->bindValue('YM',$YM, \PDO::PARAM_STR);
                    $stmt2->execute();
                    $month_data = $stmt2->fetchAll();
                    $result[$key]['toMonth'] = $month_data;

                    $stmt3 = $this->db->prepare( //経過月(CF)
                    'SELECT AccountData.PriceGroup, SUM(ProjectData.Budget) PMoney ,SUM(SubMoney) Money, '
                    . 'SUM(SubTime) Time'
                    . ' FROM DailyData '
                    . 'LEFT JOIN ProjectData ON ProjectData.ProjectCord = DailyData.ProjectCord '
                    . 'LEFT JOIN AccountData ON AccountData.AccountId = DailyData.AccountId '
                    .'WHERE ProjectData.BusinessType = :BusinessType AND '
                    .'YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
                    .'GROUP BY AccountData.PriceGroup'
                    );
                    $stmt3->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt3->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
                    $stmt3->bindValue('BETWEEN2',$YM, \PDO::PARAM_STR);
                    $stmt3->execute();
                    $em_data = $stmt3->fetchAll();
                    $result[$key]['elapsedMonth'] = $em_data;

                    $stmt4 = $this->db->prepare( //年間(CF)
                    'SELECT AccountData.PriceGroup, SUM(ProjectData.Budget) PMoney ,SUM(SubMoney) Money,'
                    . 'SUM(SubTime) Time'
                    . ' FROM DailyData '
                    . 'LEFT JOIN ProjectData ON ProjectData.ProjectCord = DailyData.ProjectCord '
                    . 'LEFT JOIN AccountData ON AccountData.AccountId = DailyData.AccountId '
                    .'WHERE ProjectData.BusinessType = :BusinessType AND '
                    .'YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
                    .'GROUP BY AccountData.PriceGroup'
                    );
                    $stmt4->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt4->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
                    $stmt4->bindValue('BETWEEN2',$between2, \PDO::PARAM_STR);
                    $stmt4->execute();
                    $year_data = $stmt4->fetchAll();
                    $result[$key]['toYear'] = $year_data;
                }
            }
            return $result;     
            
        }
        catch (\Exception $e) {
            throw $e;
        }
    }
    
    public function findProductBetsuPL($YM)  //業種別PL
    {
        try {
            if(empty($YM)){
                $YM =  date('Ym');
            }
            if(date("m", strtotime($YM))<4){
                $between1 = date("Ym", strtotime((date("Y", strtotime($YM))-1).'-04-01'));
                $between2 = date("Ym", strtotime(date("Y", strtotime($YM)).'-03-01'));
                $Y = date("Y", strtotime($YM))-1;
                $dl = (date("Y", strtotime($YM))-1).'-04-01';
            }else{
                $between1 = date("Ym", strtotime(date("Y", strtotime($YM)).'-04-01'));
                $between2 = date("Ym", strtotime((date("Y", strtotime($YM))+1).'-03-01'));
                $Y = date("Y", strtotime($YM));
                $dl = (date("Y", strtotime($YM))).'-04-01'; 
            }

            if(date("m")<4){
                $TCheck = date("Ym", strtotime((date("Y")-1).'-04-01'));
                $SY = date("Y", strtotime((date("Y")-1).'-04-01'));
            }else{
                $TCheck = date("Ym", strtotime((date("Y")).'-04-01'));
                $SY = date("Y", strtotime((date("Y")).'-04-01'));
            }
            $stmt = $this->db->prepare(
            'SELECT DISTINCT BusinessType,Product FROM ProjectData '
            );
            $stmt->execute();
            $all_type = $stmt->fetchAll();

            foreach ($all_type as $key => $type) {
                if(!empty($type['BusinessType'])){
                    $result[$key] = array(
                        'BusinessType' => $type['BusinessType'],
                        'Product' => $type['Product']
                    );
                    $stmt1 = $this->db->prepare( //当月(PL)
                    'SELECT PMO,Accounting  FROM PMO '
                    .'WHERE BusinessType = :BusinessType '
                    .'LIMIT  1'
                    );
                    $stmt1->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt1->execute();
                    $pmo = $stmt1->fetchAll();
                    $result[$key]['PMO'] = '';
                    $result[$key]['Accounting'] = '';
                    if(!empty($pmo)){
                        $result[$key]['PMO'] = $pmo[0]['PMO'];
                        $result[$key]['Accounting'] = $pmo[0]['Accounting'];
                    }
                    $stmt2 = $this->db->prepare( //当月(PL)
                    'SELECT AccountData.PriceGroup, SUM(ProjectData.Budget) Budget ,SUM(SubTime) Time'
                    . ',SUM(SubMoney) Money'
                    . ' FROM DailyData '
                    . 'LEFT JOIN ProjectData ON ProjectData.ProjectCord = DailyData.ProjectCord '
                    . 'LEFT JOIN AccountData ON AccountData.AccountId = DailyData.AccountId '
                    .'WHERE ProjectData.BusinessType = :BusinessType AND YM = :YM '
                    .'AND Process1 BETWEEN 100 AND 199 '
                    .'GROUP BY AccountData.PriceGroup'
                    );
                    $stmt2->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt2->bindValue('YM',$YM, \PDO::PARAM_STR);
                    $stmt2->execute();
                    $month_data = $stmt2->fetchAll();
                    $result[$key]['toMonth'] = $month_data;

                    $stmt3 = $this->db->prepare( //経過月(PL)
                    'SELECT AccountData.PriceGroup, SUM(ProjectData.Budget) PMoney ,SUM(SubMoney) Money,'
                    . 'SUM(SubTime) '
                    . ' FROM DailyData '
                    . 'LEFT JOIN ProjectData ON ProjectData.ProjectCord = DailyData.ProjectCord '
                    . 'LEFT JOIN AccountData ON AccountData.AccountId = DailyData.AccountId '
                    .'WHERE ProjectData.BusinessType = :BusinessType AND '
                    .'YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
                    .'AND Process1 BETWEEN 100 AND 199 '
                    .'GROUP BY AccountData.PriceGroup'
                    );
                    $stmt3->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt3->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
                    $stmt3->bindValue('BETWEEN2',$YM, \PDO::PARAM_STR);
                    $stmt3->execute();
                    $em_data = $stmt3->fetchAll();
                    $result[$key]['elapsedMonth'] = $em_data;

                    $stmt4 = $this->db->prepare( //年間(PL)
                    'SELECT AccountData.PriceGroup, SUM(ProjectData.Budget) PMoney ,SUM(SubMoney) Money,'
                    . 'SUM(SubTime) '
                    . ' FROM DailyData '
                    . 'LEFT JOIN ProjectData ON ProjectData.ProjectCord = DailyData.ProjectCord '
                    . 'LEFT JOIN AccountData ON AccountData.AccountId = DailyData.AccountId '
                    .'WHERE ProjectData.BusinessType = :BusinessType AND '
                    .'YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
                    .'AND Process1 BETWEEN 100 AND 199 '
                    .'GROUP BY AccountData.PriceGroup'
                    );
                    $stmt4->bindValue('BusinessType',$type['BusinessType'], \PDO::PARAM_STR);
                    $stmt4->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
                    $stmt4->bindValue('BETWEEN2',$between2, \PDO::PARAM_STR);
                    $stmt4->execute();
                    $year_data = $stmt4->fetchAll();
                    $result[$key]['toYear'] = $year_data;
                }
            }
            return $result;
        }
        catch (\Exception $e) {
            throw $e;
        }
    }
 public function getAllPJ($YM) //AllProject
  {
        try {
            if(empty($YM)){
                $YM =  date('Ym');
            }
            if(date("m", strtotime($YM))<4){
                $between1 = date("Ym", strtotime((date("Y", strtotime($YM))-1).'-04-01'));
                $between2 = date("Ym", strtotime(date("Y", strtotime($YM)).'-03-01'));
                $between3 = date("Y-m-d", strtotime((date("Y", strtotime($YM))-1).'-04-01'));
                $between4 = date("Y-m-d", strtotime(date("Y", strtotime($YM)).'-03-01'));
                $Y = date("Y", strtotime($YM))-1;
                $dl = (date("Y", strtotime($YM))-1).'-04-01';
            }else{
                $between1 = date("Ym", strtotime(date("Y", strtotime($YM)).'-04-01'));
                $between2 = date("Ym", strtotime((date("Y", strtotime($YM))+1).'-03-01'));
                $between3 = date("Y-m-d", strtotime(date("Y", strtotime($YM)).'-04-01'));
                $between4 = date("Y-m-d", strtotime((date("Y", strtotime($YM))+1).'-03-01'));
                $Y = date("Y", strtotime($YM));
                $dl = (date("Y", strtotime($YM))).'-04-01';
            }

            if(date("m")<4){
                $TCheck = date("Ym", strtotime((date("Y")-1).'-04-01'));
                $SY = date("Y", strtotime((date("Y")-1).'-04-01'));
            }else{
                $TCheck = date("Ym", strtotime((date("Y")).'-04-01'));
                $SY = date("Y", strtotime((date("Y")).'-04-01'));
            }

            $stmt = $this->db->prepare( //Project
            'SELECT DISTINCT ProjectCord, Project, BusinessType, Product, Budget FROM ProjectData '
            .'WHERE ProjectY = :ProjectY '
            .'ORDER BY BusinessType DESC, Product DESC '
            );
            $stmt->bindValue('ProjectY',$Y, \PDO::PARAM_STR);
            $stmt->execute();
            $all_project = $stmt->fetchAll();
                    
            $stmt = $this->db->prepare( //PMO
            'SELECT PMO, Accounting, BusinessType FROM `PMO`'
            );
            $stmt->execute();
            $pmo_array = $stmt->fetchAll();
            $pmo = array();
            foreach ($pmo_array as $key => $pmo_value) {
               $business_type = $pmo_value['BusinessType'];
               $pmo[$business_type] = $pmo_value;
            }
//                        echo "<meta charset='UTF-8'/><pre>";
//            print_r($pmo);
//            echo "</pre>";
//            exit;
            $stmt = $this->db->prepare( //当月(CF)
            'SELECT ProjectCord, SUM(SubMoney) toMonthCFMoney, SUM(SubTime) toMonthCFTime '
            .'FROM DailyData '
            .'WHERE YM = :YM '
            .'GROUP BY DailyData.ProjectCord'
            );
            $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt->execute();
            $month_data_cf_array = $stmt->fetchAll();
            $tomonth_cf = array();
            foreach ($month_data_cf_array as $key => $month_data_cf) {
               $project_cord = $month_data_cf['ProjectCord'];
               $tomonth_cf[$project_cord] = $month_data_cf;
            }

            $stmt = $this->db->prepare( //当月(PL)
            'SELECT ProjectCord, SUM(SubMoney) toMonthPLMoney,SUM(SubTime) toMonthPLTime '
            . 'FROM DailyData '
            .'WHERE YM = :YM '
            .'AND Process1 BETWEEN 100 AND 199 '
            .'GROUP BY DailyData.ProjectCord'
            );
            $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt->execute();
            $month_data_pl_array = $stmt->fetchAll();
            $tomonth_pl = array(); 
            foreach ($month_data_pl_array as $key => $month_data_pl) {
               $project_cord = $month_data_pl['ProjectCord'];
               $tomonth_pl[$project_cord] = $month_data_pl;
            } 

            $stmt = $this->db->prepare( //当月(AS/費用)
            'SELECT ProjectCord, SUM(SubMoney) toMonthASMoney,SUM(SubTime) toMonthASTime '
            .'FROM DailyData '
            .'WHERE YM = :YM '
            .'AND Process1 BETWEEN 200 AND 399 '
            .'GROUP BY DailyData.ProjectCord'
            );
            $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt->execute();
            $month_data_as_array = $stmt->fetchAll();
            $tomonth_as = array(); 
            foreach ($month_data_as_array as $key => $month_data_as) {
               $project_cord = $month_data_as['ProjectCord'];
               $tomonth_as[$project_cord] = $month_data_as;
            } 

            $stmt = $this->db->prepare( //経過月(CF)
            'SELECT ProjectCord, SUM(SubMoney) emCFMoney,SUM(SubTime) emCFTime '
            .' FROM DailyData '
            .'WHERE YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
            // .'WHERE YM = :YM '
            .'GROUP BY DailyData.ProjectCord'
            );
            $stmt->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
            $stmt->bindValue('BETWEEN2',$YM, \PDO::PARAM_STR);
             // $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt->execute();
            $em_data_cf_array = $stmt->fetchAll();
            $em_cf = array(); 
            foreach ($em_data_cf_array as $key => $em_data_cf) {
               $project_cord = $em_data_cf['ProjectCord'];
               $em_cf[$project_cord] = $em_data_cf;
            } 

            $stmt = $this->db->prepare( //経過月(PL/資産)
            'SELECT ProjectCord, SUM(SubMoney) emPLMoney,SUM(SubTime) emPLTime '
            .'FROM DailyData '
            .'WHERE YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
            // .'WHERE YM = :YM '
            .'AND Process1 BETWEEN 100 AND 199 '
            .'GROUP BY DailyData.ProjectCord'
            );
            $stmt->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
            $stmt->bindValue('BETWEEN2',$YM, \PDO::PARAM_STR);
            // $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt->execute();
            $em_data_pl_array = $stmt->fetchAll();
            $em_pl = array(); 
            foreach ($em_data_pl_array as $key => $em_data_pl) {
               $project_cord = $em_data_pl['ProjectCord'];
               $em_pl[$project_cord] = $em_data_pl;
            } 

            $stmt = $this->db->prepare( //経過月(AS/費用)
            'SELECT ProjectCord, SUM(SubMoney) emASMoney,SUM(SubTime) emASTime '
            .'FROM DailyData '
            .'WHERE YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
            // .'WHERE YM = :YM '
            .'AND Process1 BETWEEN 200 AND 399 '
            .'GROUP BY DailyData.ProjectCord'
            );
            $stmt->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
            $stmt->bindValue('BETWEEN2',$YM, \PDO::PARAM_STR);
            // $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt->execute();
            $em_data_as_array = $stmt->fetchAll();
            $em_as = array(); 
            foreach ($em_data_as_array as $key => $em_data_as) {
               $project_cord = $em_data_as['ProjectCord'];
               $em_as[$project_cord] = $em_data_as;
            } 

            $stmt = $this->db->prepare( //通年(CF)
            'SELECT ProjectCord, SUM(SubMoney) toYearCFMoney, SUM(SubTime) toYearCFTime '
            .' FROM DailyData '
            // .'WHERE YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
            .'WHERE YM = :YM '
            .'GROUP BY DailyData.ProjectCord'
            );
            // $stmt->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
            // $stmt->bindValue('BETWEEN2',$between2, \PDO::PARAM_STR);
            $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt->execute();
            $toyear_data_cf_array = $stmt->fetchAll();
            $toyear_cf = array(); 
            foreach ($toyear_data_cf_array as $key => $toyear_data_cf) {
               $project_cord = $toyear_data_cf['ProjectCord'];
               $toyear_cf[$project_cord] = $toyear_data_cf;
            } 

            $stmt = $this->db->prepare( //通年(PL/資産)
            'SELECT ProjectCord, SUM(SubMoney) toYearPLMoney,SUM(SubTime) toYearPLTime '
            .'FROM DailyData '
            // .'WHERE YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
            .'WHERE YM = :YM '
            .'AND Process1 BETWEEN 100 AND 199 '
            .'GROUP BY DailyData.ProjectCord'
            );
            // $stmt->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
            // $stmt->bindValue('BETWEEN2',$between2, \PDO::PARAM_STR);
            $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt->execute();
            $toyear_data_pl_array = $stmt->fetchAll();
            $toyear_pl = array(); 
            foreach ($toyear_data_pl_array as $key => $toyear_data_pl) {
               $project_cord = $toyear_data_pl['ProjectCord'];
               $toyear_pl[$project_cord] = $toyear_data_pl;
            } 

            $stmt = $this->db->prepare( //通年(AS/費用)
            'SELECT ProjectCord, SUM(SubMoney) toYearASMoney,SUM(SubTime) toYearASTime '
            .'FROM DailyData '
            // .'WHERE YM BETWEEN :BETWEEN1 AND :BETWEEN2 '
            // .'WHERE YM >= :BETWEEN1 AND YM <=:BETWEEN2 '
            .'WHERE YM = :YM '
            .'AND Process1 BETWEEN 200 AND 400 '
            .'GROUP BY DailyData.ProjectCord'
            );
            // $stmt->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
            // $stmt->bindValue('BETWEEN2',$between2, \PDO::PARAM_STR);
            $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt->execute();
            $toyear_data_as_array = $stmt->fetchAll();
            $toyear_as = array(); 
            foreach ($toyear_data_as_array as $key => $toyear_data_as) {
               $project_cord = $toyear_data_as['ProjectCord'];
               $toyear_as[$project_cord] = $toyear_data_as;
            } 

            foreach ($all_project as $key => $project) {
                $project_cord = $project['ProjectCord'];
                $business_type = $project['BusinessType'];
                $result[$key] = array(
                    'ProjectCord' => $project['ProjectCord'],
                    'Project' => $project['Project'],
                    'BusinessType' => $project['BusinessType'],
                    'Product' => $project['Product'],
                    'Budget' => $project['Budget']
                );
               if(!empty($pmo[$business_type])){
                  $result[$key]['PMO'] = $pmo[$business_type]['PMO']; 
                  $result[$key]['Accounting'] = $pmo[$business_type]['Accounting']; 
               }
               else{
                  $result[$key]['PMO'] = ""; 
                  $result[$key]['Accounting'] = ""; 
               }
               if(!empty($tomonth_cf[$project_cord])){
                  $result[$key]['toMonthCFTime'] = $tomonth_cf[$project_cord]['toMonthCFTime']; 
                  $result[$key]['toMonthCFMoney'] = $tomonth_cf[$project_cord]['toMonthCFMoney']; 
               }
               else{
                  $result[$key]['toMonthCFTime'] = 0; 
                  $result[$key]['toMonthCFMoney'] = 0; 
               }
               if(!empty($tomonth_pl[$project_cord])){
                  $result[$key]['toMonthPLTime'] = $tomonth_pl[$project_cord]['toMonthPLTime']; 
                  $result[$key]['toMonthPLMoney'] = $tomonth_pl[$project_cord]['toMonthPLMoney']; 
               }
               else{
                  $result[$key]['toMonthPLTime'] = 0; 
                  $result[$key]['toMonthPLMoney'] = 0; 
               }
               if(!empty($tomonth_as[$project_cord])){
                  $result[$key]['toMonthASTime'] = $tomonth_as[$project_cord]['toMonthASTime']; 
                  $result[$key]['toMonthASMoney'] = $tomonth_as[$project_cord]['toMonthASMoney']; 
               }
               else{
                  $result[$key]['toMonthASTime'] = 0; 
                  $result[$key]['toMonthASMoney'] = 0; 
               }
               if(!empty($em_cf[$project_cord])){
                  $result[$key]['emCFTime'] = $em_cf[$project_cord]['emCFTime']; 
                  $result[$key]['emCFMoney'] = $em_cf[$project_cord]['emCFMoney']; 
               }
               else{
                  $result[$key]['emCFTime'] = 0; 
                  $result[$key]['emCFMoney'] = 0; 
               }
               if(!empty($em_pl[$project_cord])){
                  $result[$key]['emPLTime'] = $em_pl[$project_cord]['emPLTime']; 
                  $result[$key]['emPLMoney'] = $em_pl[$project_cord]['emPLMoney']; 
               }
               else{
                  $result[$key]['emPLTime'] = 0; 
                  $result[$key]['emPLMoney'] = 0; 
               }
               if(!empty($em_as[$project_cord])){
                  $result[$key]['emASTime'] = $em_as[$project_cord]['emASTime']; 
                  $result[$key]['emASMoney'] = $em_as[$project_cord]['emASMoney']; 
               }
               else{
                  $result[$key]['emASTime'] = 0; 
                  $result[$key]['emASMoney'] = 0; 
               }
               if(!empty($tomonth_cf[$project_cord])){
                  $result[$key]['toYearCFTime'] = $toyear_cf[$project_cord]['toYearCFTime']; 
                  $result[$key]['toYearCFMoney'] = $toyear_cf[$project_cord]['toYearCFMoney']; 
               }
               else{
                  $result[$key]['toYearCFTime'] = 0; 
                  $result[$key]['toYearCFMoney'] = 0; 
               }
               if(!empty($tomonth_pl[$project_cord])){
                  $result[$key]['toYearPLTime'] = $toyear_pl[$project_cord]['toYearPLTime']; 
                  $result[$key]['toYearPLMoney'] = $toyear_pl[$project_cord]['toYearPLMoney']; 
               }
               else{
                  $result[$key]['toYearPLTime'] = 0; 
                  $result[$key]['toYearPLMoney'] = 0; 
               }
               if(!empty($tomonth_as[$project_cord])){
                  $result[$key]['toYearASTime'] = $toyear_as[$project_cord]['toYearASTime']; 
                  $result[$key]['toYearASMoney'] = $toyear_as[$project_cord]['toYearASMoney']; 
               }
               else{
                  $result[$key]['toYearASTime'] = 0; 
                  $result[$key]['toYearASMoney'] = 0; 
               }
                
            }
            
//            echo "<meta charset='UTF-8'/><pre>";
//            print_r($result);
//            echo "</pre>";
//            exit;
            return $result;
        }
        catch (\Exception $e) {
            throw $e;
        }
    }

 public function FindAllProjects($YM = null, $month, $year)
 {
    try {
        $stmt = $this->db->prepare(
            'SELECT SUM(m.Money'.$month.') AS Money, SUM(m.PTime'.$month.') AS PTime, '
            . 'SUM(m.Time'.$month.') AS Time, m.ProjectCord, m.Project, p.Budget, '
            . 'p.BusinessType, p.Product, p.PMO '
            .'FROM MonthData2 m LEFT JOIN ProjectData p ON m.ProjectCord = p.ProjectCord '
            .'WHERE m.MemberY = :Year '
            .'GROUP BY ProjectCord ORDER BY p.BusinessType DESC'
        );
        $stmt->bindValue('Year',$year, \PDO::PARAM_STR);
        $stmt->execute();
        $allprojects = $stmt->fetchAll();
        foreach ($allprojects as $key => $project) {
            $stmt2 = $this->db->prepare(
                'SELECT SUM(SubTime) AS SubTime, SUM(SubMoney) AS SubMoney FROM DailyData '
                .'WHERE ProjectCord = :ProjectCord AND YM = :YM GROUP BY ProjectCord'
            );
            $stmt2->bindValue('ProjectCord',$project['ProjectCord'], \PDO::PARAM_STR);
            $stmt2->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt2->execute();
            $result_moto = $stmt2->fetchAll();
            $result = array(
                'DMoney3_sum'=>0,
                'Dtime1_sum'=>0
            );
            $result2 = array(
                'DMoney1' => 0,
                'DMoney2' => 0
            );
            $result3 = array(
                'DMoney1_sum'=>0
            );
            $result4 = array(
                'DMoney2_sum'=>0
            );
            if(!empty($result_moto)){
                foreach ($result_moto as $value) {
                    $result['DMoney3_sum'] += $value['SubMoney']; //月合計
                    $result['Dtime1_sum'] += $value['SubTime']; //月合計
                }
            }
            $allprojects[$key] = array_merge($allprojects[$key], $result);

            if(strstr($project['ProjectCord'],"EPK")){
                $stmt3 = $this->db->prepare(
                    'SELECT SUM(SubMoney) AS SubMoney FROM DailyData '
                    .'WHERE ProjectCord = :ProjectCord '
                    .'AND YM = :YM '
                    .'AND Process1 BETWEEN 100 AND 199 GROUP BY ProjectCord'
                );
                $stmt3->bindValue('ProjectCord',$project['ProjectCord'], \PDO::PARAM_STR);
                $stmt3->bindValue('YM',$YM, \PDO::PARAM_STR);
                $stmt3->execute();
                $result3_moto = $stmt3->fetchAll();
                
                if(!empty($result3_moto)){
                    foreach ($result_moto as $value) {
                        $result3['DMoney1_sum'] += $value['SubMoney']; //月合計
                    }
                }
                $stmt4 = $this->db->prepare(
                    'SELECT SUM(SubMoney) AS SubMoney FROM DailyData '
                    .'WHERE ProjectCord = :ProjectCord '
                    .'AND YM = :YM AND Process1 BETWEEN 200 AND 399 GROUP BY ProjectCord'
                );
                $stmt4->bindValue('ProjectCord',$project['ProjectCord'], \PDO::PARAM_STR);
                $stmt4->bindValue('YM',$YM, \PDO::PARAM_STR);
                $stmt4->execute();
                $result4_moto = $stmt4->fetchAll();
                if(!empty($result4_moto)){
                    $result4['DMoney2_sum'] += $value['SubMoney']; //月合計
                }
            }
            else{
                $result2 = array(     
                    'DMoney1' => 0,
                    'DMoney2' => $allprojects[$key]['DMoney3_sum']
                );
            }
            $allprojects[$key] = array_merge($allprojects[$key], $result2);
            $allprojects[$key] = array_merge($allprojects[$key], $result3);
            $allprojects[$key] = array_merge($allprojects[$key], $result4);
        }
        return $allprojects;
    }
    catch (\Exception $e) {
        throw $e;
    }
}
public function findHitoBetsuJisseki($YM = null, $month, $year, $sort)
{
    try {
        if(empty($YM)){
            $YM =  date('Ym');
        }
        $stmt = $this->db->prepare(
            'SELECT d.`YM`,'
            .'d.`Process1`, '
            .'SUM(d.`SubTime`) AS DTime1,'
            .'d.`ProjectCord`, '
            .'a.`AccountId`, a.`Name`, a.`Class`, a.`PMO`, '
            .'a.`Price1`, a.`Price2`, a.`Price3`, a.`Price4`, a.`Price5`, '
            .'a.`Price6`, a.`Price7`, a.`Price8`, a.`Price9`, a.`Price10`, a.`Price11`, a.`Price12` '
            .'FROM DailyData d '
            .'LEFT JOIN AccountData a ON d.`AccountId` = a.`AccountId` '
            .'WHERE d.`YM` = :YM '
            .'AND `Process1` BETWEEN 100 AND 199 '
            .'GROUP BY d.`AccountId`, d.`ProjectCord` '
            .'ORDER BY d.`ProjectCord`, a.PMO DESC, a.Class DESC, a.`AccountId`'
        );
        $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
        $stmt->execute();
        $all_daily_data = $stmt->fetchAll();
        
        $project = array();
        foreach ($all_daily_data as $key => $daily_data) {
            $project_code = $daily_data['ProjectCord']; 
            if(empty($project[$project_code])){
                $stmt2 = $this->db->prepare(
                'SELECT  `ProjectCord`,`Project`,`Status`,`BusinessType`,`Custodian`,`Budget`,'
                . '`Accounting`,`Product` '
                .'FROM ProjectData  '
                .'WHERE `ProjectCord` = :ProjectCord '
                );
                $stmt2->bindValue('ProjectCord',$project_code, \PDO::PARAM_STR);
                $stmt2->execute();
                $project_data[$project_code] = $stmt2->fetch();
            }
           $all_daily_data[$key] = array_merge($all_daily_data[$key], $project_data[$project_code]); 
        }
        foreach ($all_daily_data as $key => $daily_data) {
            $stmt3 = $this->db->prepare(
            'SELECT SUM(d.`SubTime`) AS DTime2 '
            . 'FROM DailyData d '
            .'WHERE d.YM = :YM '
            . 'AND Process1 BETWEEN 200 AND 399 '
            . 'AND d.AccountId = :AccountId '
            .'GROUP BY d.`AccountId`'
            );
            $stmt3->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt3->bindValue('AccountId',$daily_data['AccountId'], \PDO::PARAM_STR);
            $stmt3->execute();
            $daily_data2 = $stmt3->fetch(); 
            $all_daily_data[$key]['DTime2'] = $daily_data2['DTime2'];
        } 
        return $all_daily_data;
    }
    catch (\Exception $e) {
       throw $e;
    }

}

public function getHitoBetsuNippou($YM = null, $sort)
{
    try {
        if(empty($YM)){
            $YM =  date('Ym');
        }
        $stmt = $this->db->prepare(
            'SELECT d.`YM`,'
            . ' d.`Process1`, '
            . 'SUM(d.`SubTime`) AS DTime1,'
            . 'd.`ProjectCord`, '
            . 'SUM(d.`Time1`) Time1, SUM(d.`Time2`) Time2, SUM(d.`Time3`) Time3, '
            . 'SUM(d.`Time4`) Time4, SUM(d.`Time5`) Time5, SUM(d.`Time6`) Time6, '
            . 'SUM(d.`Time7`) Time7, SUM(d.`Time8`) Time8, SUM(d.`Time9`) Time9, '
            . 'SUM(d.`Time10`) Time10, SUM(d.`Time11`) Time11, SUM(d.`Time12`) Time12, '
            . 'SUM(d.`Time13`) Time13, SUM(d.`Time14`) Time14, SUM(d.`Time15`) Time15, '
            . 'SUM(d.`Time16`) Time16, SUM(d.`Time17`) Time17, SUM(d.`Time18`) Time18, '
            . 'SUM(d.`Time19`) Time19, SUM(d.`Time20`) Time20, SUM(d.`Time21`) Time21, '
            . 'SUM(d.`Time22`) Time22, SUM(d.`Time23`) Time23, SUM(d.`Time24`) Time24, '
            . 'SUM(d.`Time25`) Time25, SUM(d.`Time26`) Time26, SUM(d.`Time27`) Time27, '
            . 'SUM(d.`Time28`) Time28, SUM(d.`Time29`) Time29, SUM(d.`Time30`) Time30, '
            . 'SUM(d.`Time31`) Time31, '
            . 'a.`AccountId`, a.`Name`, a.`Class`, a.`PMO` '
            . 'FROM DailyData d '
            .'LEFT JOIN AccountData a ON d.AccountId = a.AccountId '
            .'WHERE d.YM = :YM '
            . 'AND Process1 BETWEEN 100 AND 199 '
            .'GROUP BY d.`AccountId`'
//                . ',d.`ProjectCord` '
            .'ORDER BY  a.`PMO` DESC,  a.`Class` DESC, d.`AccountId`'
//                . ',d.`ProjectCord`'
        );
        $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
        $stmt->execute();
        $all_daily_data = $stmt->fetchAll();
        
        $project = array();
//        foreach ($all_daily_data as $key => $daily_data) {
//            $project_code = $daily_data['ProjectCord']; 
//            if(empty($project[$project_code])){
//                $stmt2 = $this->db->prepare(
//                'SELECT * '
//                .'FROM ProjectData  '
//                .'WHERE `ProjectCord` = :ProjectCord '
//                );
//                $stmt2->bindValue('ProjectCord',$project_code, \PDO::PARAM_STR);
//                $stmt2->execute();
//                $project_data[$project_code] = $stmt2->fetch();
//            }
//           $all_daily_data[$key] = array_merge($all_daily_data[$key], $project_data[$project_code]); 
//        }
        foreach ($all_daily_data as $key => $daily_data) {
            $stmt3 = $this->db->prepare(
            'SELECT SUM(d.`SubTime`) AS DTime2 ,'
            . 'SUM(d.`Time1`) Time1, SUM(d.`Time2`) Time2, SUM(d.`Time3`) Time3, '
            . 'SUM(d.`Time4`) Time4, SUM(d.`Time5`) Time5, SUM(d.`Time6`) Time6, '
            . 'SUM(d.`Time7`) Time7, SUM(d.`Time8`) Time8, SUM(d.`Time9`) Time9, '
            . 'SUM(d.`Time10`) Time10, SUM(d.`Time11`) Time11, SUM(d.`Time12`) Time12, '
            . 'SUM(d.`Time13`) Time13, SUM(d.`Time14`) Time14, SUM(d.`Time15`) Time15, '
            . 'SUM(d.`Time16`) Time16, SUM(d.`Time17`) Time17, SUM(d.`Time18`) Time18, '
            . 'SUM(d.`Time19`) Time19, SUM(d.`Time20`) Time20, SUM(d.`Time21`) Time21, '
            . 'SUM(d.`Time22`) Time22, SUM(d.`Time23`) Time23, SUM(d.`Time24`) Time24, '
            . 'SUM(d.`Time25`) Time25, SUM(d.`Time26`) Time26, SUM(d.`Time27`) Time27, '
            . 'SUM(d.`Time28`) Time28, SUM(d.`Time29`) Time29, SUM(d.`Time30`) Time30, '
            . 'SUM(d.`Time31`) Time31 '
            . 'FROM DailyData d '
            .'WHERE d.YM = :YM '
            . 'AND Process1 BETWEEN 200 AND 399 '
            . 'AND d.AccountId = :AccountId '
            .'GROUP BY d.`AccountId`'
            );
            $stmt3->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt3->bindValue('AccountId',$daily_data['AccountId'], \PDO::PARAM_STR);
            $stmt3->execute();
            $daily_data2 = $stmt3->fetch(); 
            $all_daily_data[$key]['DTime2'] = $daily_data2['DTime2'];
            
            $input_date = "";
            for($i = 1;$i<=31;$i++){
                if($daily_data['Time'.$i] != 0){
                    $input_date .= $i."日,";
                }
                elseif($daily_data2['Time'.$i] != 0){
                    $input_date .= $i."日,";
                }
            }
            $input_date = rtrim($input_date, ",");
            $all_daily_data[$key]['InputDate'] = $input_date;
        } 

//        echo "<meta charset='UTF-8'/><pre>";
//print_r($all_daily_data);
//echo "</pre>";
//exit;

        return $all_daily_data;
    }
    catch (\Exception $e) {
       throw $e;
    }
}
public function getProjectBetsuNippou($YM = null, $sort)
{
    try {
        if(empty($YM)){
            $YM =  date('Ym');
        }
        $stmt = $this->db->prepare(
            'SELECT d.`YM`,'
            . ' d.`Process1`, '
            . 'SUM(d.`SubTime`) AS DTime1,'
            . 'd.`ProjectCord`, '
            . ' a.`AccountId`, a.`Name`, a.`Class`, a.`PMO` '
            . 'FROM DailyData d '
            .'LEFT JOIN AccountData a ON d.AccountId = a.AccountId '
            .'WHERE d.YM = :YM '
            . 'AND Process1 BETWEEN 100 AND 199 '
            .'GROUP BY d.`AccountId`'
                . ',d.`ProjectCord` '
            .'ORDER BY d.`ProjectCord`, a.`Class` DESC, a.`AccountId`'
        );
        $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
        $stmt->execute();
        $all_daily_data = $stmt->fetchAll();
        
        $project = array();
        foreach ($all_daily_data as $key => $daily_data) {
            $project_code = $daily_data['ProjectCord']; 
            if(empty($project[$project_code])){
                $stmt2 = $this->db->prepare(
                'SELECT * '
                .'FROM ProjectData  '
                .'WHERE `ProjectCord` = :ProjectCord '
                );
                $stmt2->bindValue('ProjectCord',$project_code, \PDO::PARAM_STR);
                $stmt2->execute();
                $project_data[$project_code] = $stmt2->fetch();
            }
           $all_daily_data[$key] = array_merge($all_daily_data[$key], $project_data[$project_code]); 
        }
        foreach ($all_daily_data as $key => $daily_data) {
            $stmt3 = $this->db->prepare(
            'SELECT SUM(d.`SubTime`) AS DTime2 '
            . 'FROM DailyData d '
            .'WHERE d.YM = :YM '
            . 'AND Process1 BETWEEN 200 AND 399 '
            . 'AND d.AccountId = :AccountId '
            .'GROUP BY d.`AccountId`'
            );
            $stmt3->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt3->bindValue('AccountId',$daily_data['AccountId'], \PDO::PARAM_STR);
            $stmt3->execute();
            $daily_data2 = $stmt3->fetch(); 
            $all_daily_data[$key]['DTime2'] = $daily_data2['DTime2'];
        } 

//        echo "<meta charset='UTF-8'/><pre>";
//print_r($all_daily_data);
//echo "</pre>";
//exit;

        return $all_daily_data;
    }
    catch (\Exception $e) {
       throw $e;
    }
}
public function getHitoBetsu($YM = null, $sort)
{
    try {
        if(empty($YM)){
            $YM =  date('Ym');
        }

        $stmt = $this->db->prepare(
            'SELECT * FROM DailyData '
            .'LEFT JOIN ProjectData ON DailyData.ProjectCord = ProjectData.ProjectCord '
            .'LEFT JOIN AccountData ON DailyData.AccountId = AccountData.AccountId '
            .'WHERE DailyData.YM = :YM '
            .'GROUP BY DailyData.AccountId '
            .'ORDER BY  '. $sort . ' DESC'
        );
        $stmt->bindValue('YM',$YM, \PDO::PARAM_STR);
        $stmt->execute();
        $allprojects = $stmt->fetchAll();

        foreach ($allprojects as $key => $project) {
            $stmt2 = $this->db->prepare(
                'SELECT SUM(SubTime) AS SubTime FROM DailyData '
                .'WHERE AccountId = :AccountId AND YM = :YM '
                .'AND Process1 BETWEEN 100 AND 199 GROUP BY AccountId'
            );
            $stmt2->bindValue('AccountId',$project['AccountId'], \PDO::PARAM_STR);
            $stmt2->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt2->execute();
            $result2_moto = $stmt2->fetchAll();
            $result2 = array();
            $result2['DTime1'] = 0;
            if(!empty($result2_moto)){
                foreach ($result2_moto as $value) {
                    $result2['DTime1'] += $value['SubTime']; //月合計
                }
            }
            $allprojects[$key] = array_merge($allprojects[$key], $result2);

            $stmt3 = $this->db->prepare(
                'SELECT SUM(SubTime) AS SubTime FROM DailyData '
                .'WHERE AccountId = :AccountId AND YM = :YM AND Process1 BETWEEN 200 AND 399 GROUP BY AccountId'
            );
            $stmt3->bindValue('AccountId',$project['AccountId'], \PDO::PARAM_STR);
            $stmt3->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt3->execute();
            $result3_moto = $stmt3->fetchAll();
            $result3 = array();
            $result3['DTime2'] = 0;
            if(!empty($result3_moto)){
                foreach ($result3_moto as $value) {
                    $result3['DTime2'] += $value['SubTime']; //月合計  
                }
            }
            $allprojects[$key] = array_merge($allprojects[$key], $result3);

            $stmt4 = $this->db->prepare(
                'SELECT SUM(SubTime) AS SubTime FROM DailyData '
                .'WHERE AccountId = :AccountId AND ProjectCord NOT LIKE "%EPK%" '
                .'AND YM = :YM GROUP BY AccountId'
            );
            $stmt4->bindValue('AccountId',$project['AccountId'], \PDO::PARAM_STR);
            $stmt4->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt4->execute();
            $result4_moto = $stmt4->fetchAll();
            $result4 = array();
            $result4['DTime3'] = 0;
            if(!empty($result4_moto)){
                foreach ($result4_moto as $value) {
                    $result4['DTime3'] += $value['SubTime']; //月合計
                }
            }
            $allprojects[$key] = array_merge($allprojects[$key], $result4);

            $stmt5 = $this->db->prepare(
                'SELECT SUM(SubTime) AS SubTime FROM DailyData '
                .'WHERE AccountId = :AccountId AND ProjectCord LIKE "%EPK%" '
                .'AND YM = :YM GROUP BY AccountId'
            );
            $stmt5->bindValue('AccountId',$project['AccountId'], \PDO::PARAM_STR);
            $stmt5->bindValue('YM',$YM, \PDO::PARAM_STR);
            $stmt5->execute();
            $result5_moto = $stmt5->fetchAll();
            $result5 = array();
            $result5['DTime4'] = 0;
            if(!empty($result5_moto)){
                foreach ($result5_moto as $value) {
                    $result5['DTime4'] += $value['SubTime']; //月合計
                }
            }
            $allprojects[$key] = array_merge($allprojects[$key], $result5);

        }
        return $allprojects;
    }
    catch (\Exception $e) {
       throw $e;
    }
}
    
public function getShuKeiMoto($YM = null, $sort = 'PMO')
{
    try {
        if(empty($YM)){
            $YM =  date('Ym');
        }
        $stmt = $this->db->prepare(
            'SELECT * FROM (DailyData LEFT JOIN AccountData '
            . 'ON DailyData.`AccountId` = AccountData.`AccountId`) '
            .'WHERE `YM` = "'.$YM.'" '
            // .'ORDER BY  AccountData.PMO DESC, DailyData.ProjectCord,AccountData.PriceGroup, AccountData.Name'
            .'ORDER BY  DailyData.Process2 DESC,AccountData.PriceGroup, AccountData.Name'
        );
        $stmt->execute();
        $all_data = $stmt->fetchAll();

        foreach ($all_data as $key => $data) {

            $stmt2 = $this->db->prepare(
            'SELECT `BusinessType`,`Accounting`,`Custodian`,`Product` FROM ProjectData '
                    . 'WHERE `ProjectCord` = "'.$data['ProjectCord'].'"'
            );
            $stmt2->execute();
            $data2 = $stmt2->fetch();
            $merge['Custodian'] = $data2['Custodian']; 
            $merge['BusinessType'] = $data2['BusinessType']; 
            $merge['Accounting'] = $data2['Accounting']; 
            $merge['Product'] = $data2['Product']; 
            if($data['Process1']<200){
                $merge['Box1'] = '資産';
            }else{
                $merge['Box1'] = '費用';
            }
            if(strstr($data['ProjectCord'],"EPK")){
                $merge['Box2'] = '直接費';
            }else{
                $merge['Box2'] = '間接費';
            }
            $all_data[$key] = array_merge($all_data[$key], $merge);
        }
        return $all_data;
    }
    catch (\Exception $e) {
        throw $e;
    }
}

public function getDeveloper($between1,$between2,$status,$YM2)
 {
    try {


        $stmt = $this->db->prepare(
            'SELECT * FROM MonthData2 '
            .'WHERE MemberY = :MemberY AND AccountId IN(SELECT AccountId FROM AccountData WHERE PriceGroup = :PriceGroup)'.
            ' GROUP BY AccountId ORDER BY PMO DESC LIMIT 2'
            // ' GROUP BY AccountId ORDER BY PMO DESC'
        );
        $YM2 = '2015';
        $stmt->bindValue('MemberY',$YM2, \PDO::PARAM_STR);
        $stmt->bindValue('PriceGroup',$status, \PDO::PARAM_STR);
        $stmt->execute();
        $all_data = $stmt->fetchAll();

        foreach ($all_data as $key => $data) {
            $stmt2 = $this->db->prepare(
                'SELECT (PMoney1 + PMoney2 + PMoney3 + PMoney4 + PMoney5 + PMoney6  + 
                PMoney7 + PMoney8 + PMoney9 + PMoney10 + PMoney11 + PMoney12) AS PMoney,
                PMoney1, PMoney2, PMoney3, PMoney4, PMoney5, PMoney6, PMoney7, PMoney8, PMoney9, PMoney10,
                PMoney11 ,PMoney12,
                (Money1 + Money2 + Money3 + Money4 + Money5 + Money6  + Money7 + Money8 + Money9 + Money10 +
                Money11 + Money12) AS Money,
                Money1, Money2, Money3, Money4, Money5, Money6, 
                Money7, Money8, Money9, Money10, Money11, Money12
                FROM MonthData2
                WHERE AccountId = :AccountId AND MemberY = :MemberY GROUP BY MemberY'
            );
            $stmt2->bindValue('AccountId',$data['AccountId'], \PDO::PARAM_STR);
            $stmt2->bindValue('MemberY',$YM2, \PDO::PARAM_STR);
           
            $stmt2->execute();
            $result2 = $stmt2->fetchAll();
            if(!empty($result2)){
                $merge = array();
                $merge['Moneys']['PMoney']['sum'] = 0;
                $merge['Moneys']['Money']['sum'] = 0;
                foreach ($result2 as $key2 => $value2) {
                    $cnt = 1;
                    while ($cnt <= 12 ) {
                        if(!empty($value2)){
                            $merge['Moneys']['PMoney'][$cnt] = $value2['PMoney'.$cnt];
                            $merge['Moneys']['PMoney']['sum'] += $value2['PMoney'];
                            $merge['Moneys']['Money'][$cnt] = $value2['Money'.$cnt];
                            $merge['Moneys']['Money']['sum'] += $value2['Money'];
                        }
                        $cnt++;
                    }
                }
                $cnt = 1;
                while ($cnt <= 12 ) {
                    if(empty($merge['Moneys']['PMoney'][$cnt])){
                        $merge['Moneys']['PMoney'][$cnt] = 0;
                    }
                    if(empty($merge['Moneys']['Money'][$cnt])){
                        $merge['Moneys']['Money'][$cnt] = 0;
                    }
                    $cnt++;
                }
                $all_data[$key] = array_merge($all_data[$key], $merge);
            }
            $stmt3 = $this->db->prepare(
                'SELECT SUM(PMoney1 + PMoney2 + PMoney3 + PMoney4 + PMoney5 + 
                    PMoney6  + PMoney7 + PMoney8 + PMoney9 + PMoney10 +
                    PMoney11 + PMoney12)
                    AS PMoney, SUM(Money1 + Money2 + Money3 + Money4 + Money5 + 
                    Money6  + Money7 + Money8 + Money9 + Money10 +
                    Money11 + Money12) AS Money FROM MonthData2 '
                    . 'WHERE AccountId = :AccountId AND MemberY = :MemberY '
            );
            $stmt3->bindValue('AccountId',$data['AccountId'], \PDO::PARAM_STR);
           // $stmt3->bindValue('BETWEEN1',$between1, \PDO::PARAM_STR);
           // $stmt3->bindValue('BETWEEN2',$between2, \PDO::PARAM_STR);
            $stmt3->bindValue('MemberY',$YM2, \PDO::PARAM_STR);
            $stmt3->execute();
            $result3 = $stmt3->fetchAll();
            $merge2 = array('row3'=>array());
            if(!empty($result3)){
                foreach ($result3 as $key3 => $value3) {
                    if(!empty($value3)){
                        $merge2['row3'] = $value3;
                    }
                }
                $all_data[$key] = array_merge($all_data[$key], $merge2);
            }
        }
        return $all_data;
    }
    catch (\Exception $e) {
        throw $e;
    }
}

public function getProjectCodeMaster()
 {

    try {
        $stmt = $this->db->prepare(
            'SELECT * FROM ProjectData ORDER BY `ProjectCord` DESC, `BusinessType`, `Status` '
        );
        $stmt->execute();
        $all_data = $stmt->fetchAll();
        return $all_data;
    }
    catch (\Exception $e) {
        throw $e;
    }
 }

 public function getAllUserHours($YM, $showYear, $showMonth)
 {
    try{
        $stmt = $this->db->prepare(
            'SELECT AccountId, Name,
                    CASE WHEN SUM(Time1) = 0 THEN "0" ELSE SUM(Time1) END as Time1, 
                    CASE WHEN SUM(Time2) = 0 THEN "0" ELSE SUM(Time2) END as Time2, 
                    CASE WHEN SUM(Time3) = 0 THEN "0" ELSE SUM(Time3) END as Time3, 
                    CASE WHEN SUM(Time4) = 0 THEN "0" ELSE SUM(Time4) END as Time4, 
                    CASE WHEN SUM(Time5) = 0 THEN "0" ELSE SUM(Time5) END as Time5, 
                    CASE WHEN SUM(Time6) = 0 THEN "0" ELSE SUM(Time6) END as Time6, 
                    CASE WHEN SUM(Time7) = 0 THEN "0" ELSE SUM(Time7) END as Time7, 
                    CASE WHEN SUM(Time8) = 0 THEN "0" ELSE SUM(Time8) END as Time8, 
                    CASE WHEN SUM(Time9) = 0 THEN "0" ELSE SUM(Time9) END as Time9, 
                    CASE WHEN SUM(Time10) = 0 THEN "0" ELSE SUM(Time10) END as Time10, 
                    CASE WHEN SUM(Time11) = 0 THEN "0" ELSE SUM(Time11) END as Time11, 
                    CASE WHEN SUM(Time12) = 0 THEN "0" ELSE SUM(Time12) END as Time12, 
                    CASE WHEN SUM(Time13) = 0 THEN "0" ELSE SUM(Time13) END as Time13, 
                    CASE WHEN SUM(Time14) = 0 THEN "0" ELSE SUM(Time14) END as Time14, 
                    CASE WHEN SUM(Time15) = 0 THEN "0" ELSE SUM(Time15) END as Time15, 
                    CASE WHEN SUM(Time16) = 0 THEN "0" ELSE SUM(Time16) END as Time16, 
                    CASE WHEN SUM(Time17) = 0 THEN "0" ELSE SUM(Time17) END as Time17, 
                    CASE WHEN SUM(Time18) = 0 THEN "0" ELSE SUM(Time18) END as Time18, 
                    CASE WHEN SUM(Time19) = 0 THEN "0" ELSE SUM(Time19) END as Time19, 
                    CASE WHEN SUM(Time20) = 0 THEN "0" ELSE SUM(Time20) END as Time20, 
                    CASE WHEN SUM(Time21) = 0 THEN "0" ELSE SUM(Time21) END as Time21, 
                    CASE WHEN SUM(Time22) = 0 THEN "0" ELSE SUM(Time22) END as Time22, 
                    CASE WHEN SUM(Time23) = 0 THEN "0" ELSE SUM(Time23) END as Time23, 
                    CASE WHEN SUM(Time24) = 0 THEN "0" ELSE SUM(Time24) END as Time24, 
                    CASE WHEN SUM(Time25) = 0 THEN "0" ELSE SUM(Time25) END as Time25, 
                    CASE WHEN SUM(Time26) = 0 THEN "0" ELSE SUM(Time26) END as Time26, 
                    CASE WHEN SUM(Time27) = 0 THEN "0" ELSE SUM(Time27) END as Time27, 
                    CASE WHEN SUM(Time28) = 0 THEN "0" ELSE SUM(Time28) END as Time28, 
                    CASE WHEN SUM(Time29) = 0 THEN "0" ELSE SUM(Time29) END as Time29, 
                    CASE WHEN SUM(Time30) = 0 THEN "0" ELSE SUM(Time30) END as Time30, 
                    CASE WHEN SUM(Time31) = 0 THEN "0" ELSE SUM(Time31) END as Time31, 
                    SUM(SubTime) as SubTime
                    '
            .'FROM DailyData WHERE YM = :YM GROUP BY AccountId DESC '
        );
        // $stmt->bindvalue('YM', $YM, \PDO::PARAM_STR);
        $stmt->bindvalue('YM', '201608', \PDO::PARAM_STR);
        $stmt->execute();
        $user_data = $stmt->fetchAll();
        if ($user_data) {
            foreach ($user_data as $user) {
                $authority = $this->GETPMO($user['AccountId']);
                $user['authority'] = $authority;
                for ($i=1; $i <= 31 ; $i++) {
                    $day_var = date("w", mktime(0,0,0,$showMonth, $i, $showYear));
                    if (($day_var == 6 || $day_var == 0) && $user['Time'.$i] == 0) {
                        $user['Time'.$i] = '休';
                    }
                }

                $holiday_data[] = $this->buildUserDailyData($user);
            }
        }
        return $user_data ? $holiday_data : false;
    }
    catch(\Exception $e){
        throw $e;
    }
 }

 public function GetPMO($AccountId, $tran = true)
    {
      try {
          if ($tran) {
            $this->db->beginTransaction();
            }
            $stmt = $this->db->prepare(
               'SELECT PMO '
              .'FROM AccountData '
              .'WHERE AccountId = :AccountId'
            );
            $stmt->bindvalue('AccountId', $AccountId, \PDO::PARAM_STR);
            $stmt->execute();
            $allpmo = $stmt->fetch();
            return $allpmo ? $allpmo['PMO'] : false;
            }
      catch (\Exception $e) {
        if ($tran) {
          $this->db->rollBack();
          }
        throw $e;
      }
  }



  public function Buildyearandstatus(Array $paramaters = array())
  {
    $entity = new AllProjectsEntity;
    $entity->setProperties($paramaters);
    return $entity;
  }


  public function BuildAllProjects($paramaters)
  {
    $entity = new AllProjectsEntity;
    $entity->setProperties($paramaters);
    return $entity;
  }

  public function buildUserDailyData(Array $paramaters)
{
  $entity = new UserDailyDataEntity;
  $entity->setProperties($paramaters);
  return $entity;
}


  public function add(EntityInterface $entity)
  {
      return;
  }
  /**
   * @param EntityInterface $entity
   */
  public function remove(EntityInterface $entity)
  {
      return;
  }

}
