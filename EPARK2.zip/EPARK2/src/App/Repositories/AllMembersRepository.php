<?php
namespace App\Repositories;

use PHPMentors\DomainKata\Repository\RepositoryInterface;
use PHPMentors\DomainKata\Entity\EntityInterface;
use App\Entities\AllMembersEntity;
use Doctrine\DBAL\Connection;
use Symfony\Component\HttpFoundation\Session\Session;
use Carbon\Carbon;


class AllMembersRepository implements RepositoryInterface
{

  protected $db;
  protected $uuid;

  public function __construct(Connection $db )
  {
      $this->db = $db;
  }

    public function FindAllMembers(AllMembersEntity $memberpricegroup, EntityInterface $user_info, $tran = true)
    {

      try {
             if ($tran) {
                     $this->db->beginTransaction();
             }
	     $id = $user_info->getLoginId();
	     $stmt2 = $this->db->prepare('SELECT OPNo FROM AccountID_OPNo WHERE AccountID = :AccountID');
	     $stmt2->bindValue('AccountID', $id, \PDO::PARAM_STR);
	     $stmt2->execute();
	     $opno = $this->array_column($stmt2->fetchAll(), 'OPNo');
	     $where = ' t2.OPNo LIKE :OPNo ';
	     for ($i = 1; $i < count($opno); $i++) {
		$where = $where.' OR t2.OPNo LIKE :OPNo'.$i.' ';
	     }
             if ($memberpricegroup->getMemberPriceGroup() =="all") {
                $stmt = $this->db->prepare('SELECT DISTINCT t1.No, t1.Name, t1.Company, t1.AccountId, t1.Pass, t1.Class, t1.Level, t1.Area, t1.Note FROM AccountData AS t1 INNER JOIN AccountID_OPNo AS t2 ON t1.AccountId = t2.AccountID WHERE '.$where.' ORDER BY t1.AccountId ASC');
             }
             else {
                $stmt = $this->db->prepare('SELECT * FROM AccountData WHERE PriceGroup = "'.$memberpricegroup->getMemberPriceGroup().'" ORDER  BY AccountId ASC');
              }
		$stmt->bindValue('OPNo', $opno[0], \PDO::PARAM_STR);
		for ($i = 1; $i < count($opno); $i++) {
			$stmt->bindValue('OPNo'.$i, $opno[$i], \PDO::PARAM_STR);
		}
             $stmt->execute();
             $allmembers=$stmt->fetchAll();
             foreach ($allmembers as $all_members) {
                             $members[] = $this->BuildAllmembers($all_members);
                         }
             return $members ? $members : false;
            }
      catch (\Exception $e) {
            if ($tran) {
                $this->db->rollBack();
            }
            throw $e;
          }

    }

        public function FindAllMembersWithSearch(AllMembersEntity $pricegroup, $tran = true)
    {

      try {
              if ($tran) {
                     $this->db->beginTransaction();
                 }
             if ($pricegroup->getMemberPriceGroup() =="all") {
                $stmt = $this->db->prepare(
                  'SELECT * FROM AccountData '
                  .'WHERE ( '
                  .'Name LIKE CONCAT("%" , :search , "%") '
                  .'OR AccountId LIKE CONCAT("%" , :search , "%") '
                  .'OR WinPass LIKE CONCAT("%" , :search , "%") '
                  .'OR Class LIKE CONCAT("%" , :search , "%") '
                  .'OR Level LIKE CONCAT("%" , :search , "%") '
                  .'OR Company LIKE CONCAT("%" , :search , "%") '
                  .'OR PriceGroup LIKE CONCAT("%" , :search , "%") '
                  .'OR PMO LIKE CONCAT("%" , :search , "%") '
                  .'OR Price1 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price2 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price3 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price4 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price5 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price6 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price7 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price8 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price9 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price10 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price11 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price12 LIKE CONCAT("%" , :search , "%") '
                  .'OR Area LIKE CONCAT("%" , :search , "%") '
                  .'OR Note LIKE CONCAT("%" , :search , "%") '
                  .'OR MailingList LIKE CONCAT("%" , :search , "%") '
                  .') '
                  .'ORDER  BY AccountId ASC'
                  );
                // $stmt->bindValue('search', $pricegroup->getSearch(), \PDO::PARAM_STR);
             }
             else {
                $stmt = $this->db->prepare(
                   'SELECT * FROM AccountData '
                  .'WHERE PriceGroup = :PriceGroup '
                  .'AND ('
                  .'Name LIKE CONCAT("%" , :search , "%") '
                  .'OR AccountId LIKE CONCAT("%" , :search , "%") '
                  .'OR WinPass LIKE CONCAT("%" , :search , "%") '
                  .'OR Class LIKE CONCAT("%" , :search , "%") '
                  .'OR Level LIKE CONCAT("%" , :search , "%") '
                  .'OR Company LIKE CONCAT("%" , :search , "%") '
                  .'OR PriceGroup LIKE CONCAT("%" , :search , "%") '
                  .'OR PMO LIKE CONCAT("%" , :search , "%") '
                  .'OR Price1 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price2 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price3 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price4 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price5 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price6 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price7 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price8 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price9 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price10 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price11 LIKE CONCAT("%" , :search , "%") '
                  .'OR Price12 LIKE CONCAT("%" , :search , "%") '
                  .'OR Area LIKE CONCAT("%" , :search , "%") '
                  .'OR Note LIKE CONCAT("%" , :search , "%") '
                  .'OR MailingList LIKE CONCAT("%" , :search , "%") '                    
                  .' )'
                  .'ORDER  BY AccountId ASC');
              }
             if ($pricegroup->getMemberPriceGroup()!= "all") {
               $stmt->bindValue('PriceGroup', $pricegroup->getMemberPriceGroup(), \PDO::PARAM_STR);
             }
             $stmt->bindValue('search', $pricegroup->getSearch(), \PDO::PARAM_STR);
             $stmt->execute();
             $allmembers=$stmt->fetchAll();
             if ($allmembers) {
              foreach ($allmembers as $all_members) {
                             $members[] = $this->BuildAllmembers($all_members);
                         }
             return $members ? $members : false;
             }
             return false;
             
            }
      catch (\Exception $e) {
            if ($tran) {
                $this->db->rollBack();
            }
            throw $e;
          }

    }



    public function GetPMO($tran = true)
    {
      try {
          if ($tran) {
            $this->db->beginTransaction();
            }
            $stmt = $this->db->prepare(
               'SELECT DISTINCT PMO '
              .'FROM PMO '
              .'ORDER BY Accounting DESC'
            );
            $stmt->execute();
            $allpmo=$stmt->fetchAll();
            foreach ($allpmo as $all_pmo) {
              $pmo[] = $this->BuildAllPMO($all_pmo);
              }
            return $pmo ? $pmo : false;
            }
      catch (\Exception $e) {
        if ($tran) {
          $this->db->rollBack();
          }
        throw $e;
      }
  }

  public function SearchIfUserExists($AccountId, $tran = true){
        try {
             $stmt =$this->db->prepare(
               'SELECT AccountId '
              .' FROM AccountData '
              .' WHERE AccountId = :AccountId '
              );
             $stmt->bindValue('AccountId', $AccountId, \PDO::PARAM_STR);
             $stmt->execute();
             $accountid = $stmt->fetchAll();
             return $accountid ? true : false;
        } catch (Exception $e) {
          throw $e;
        }
    }


    public function saveToTest(
        EntityInterface $member,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            $sql = $this->inserttestSql();
            $stmt = $connection->prepare($sql);
            $stmt->bindValue(':no', $member->getNumber(), \PDO::PARAM_INT);
            $stmt->bindValue('ngflag', $member->getNGFlg(), \PDO::PARAM_STR);
            $stmt->bindValue('name', $member->getName(), \PDO::PARAM_STR);
            $stmt->bindValue('company', $member->getCompany(), \PDO::PARAM_STR);
            $stmt->bindValue(':accountid', strval( $member->getAccountId() ), \PDO::PARAM_STR);
            $stmt->bindValue('pass', $member->getPass(), \PDO::PARAM_STR);
            $stmt->bindValue('level', $member->getLevel(), \PDO::PARAM_STR);
            $stmt->bindValue('class', $member->getClass(), \PDO::PARAM_STR);
            $stmt->bindValue('pricegroup', $member->getPriceGroup(), \PDO::PARAM_STR);
            $stmt->bindValue('pmo', $member->GetPMO(), \PDO::PARAM_STR);
            $stmt->bindValue('price1', ($member->getPrice1() ? $member->getPrice1() : 0), \PDO::PARAM_STR);
            $stmt->bindValue('price2', ($member->getPrice2() ? $member->getPrice2() : 0), \PDO::PARAM_STR);
            $stmt->bindValue('price3', ($member->getPrice3() ? $member->getPrice3() : 0), \PDO::PARAM_STR);
            $stmt->bindValue('price4', ($member->getPrice4() ? $member->getPrice4() : 0), \PDO::PARAM_STR);
            $stmt->bindValue('price5', ($member->getPrice5() ? $member->getPrice5() : 0), \PDO::PARAM_STR);
            $stmt->bindValue('price6', ($member->getPrice6() ? $member->getPrice6() : 0), \PDO::PARAM_STR);
            $stmt->bindValue('price7', ($member->getPrice7() ? $member->getPrice7() : 0), \PDO::PARAM_STR);
            $stmt->bindValue('price8', ($member->getPrice8() ? $member->getPrice8() : 0), \PDO::PARAM_STR);
            $stmt->bindValue('price9', ($member->getPrice9() ? $member->getPrice9() : 0), \PDO::PARAM_STR);
            $stmt->bindValue('price10', ($member->getPrice10() ? $member->getPrice10() : 0), \PDO::PARAM_STR);
            $stmt->bindValue('price11', ($member->getPrice11() ? $member->getPrice11() : 0), \PDO::PARAM_STR);
            $stmt->bindValue('price12', ($member->getPrice12() ? $member->getPrice12() : 0), \PDO::PARAM_STR);
            $stmt->bindValue('Note', $member->getNote(), \PDO::PARAM_STR);
            $stmt->bindValue('Area', $member->getArea(), \PDO::PARAM_STR);
            $stmt->execute();
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }

            return false;
        }
    }

    public function UpdateMember(
        EntityInterface $member,
        $connection,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $connection->beginTransaction();
            }
            $sql = $this->UpdateMemberSql();
            $stmt = $connection->prepare($sql);
            $stmt->bindValue(':No', $member->getNumber(), \PDO::PARAM_INT);
            $stmt->bindValue('NGFlg', $member->getNGFlg(), \PDO::PARAM_STR);
            $stmt->bindValue('Name', $member->getName(), \PDO::PARAM_STR);
            $stmt->bindValue('Company', $member->getCompany(), \PDO::PARAM_STR);
            $stmt->bindValue(':AccountId', strval( $member->getAccountId() ), \PDO::PARAM_STR);
            $stmt->bindValue('Pass', $member->getPass(), \PDO::PARAM_STR);
            $stmt->bindValue('Level', $member->getLevel(), \PDO::PARAM_STR);
            $stmt->bindValue('Class', $member->getClass(), \PDO::PARAM_STR);
            $stmt->bindValue('PriceGroup', $member->getPriceGroup(), \PDO::PARAM_STR);
            $stmt->bindValue('PMO', $member->GetPMO(), \PDO::PARAM_STR);
            $stmt->bindValue('Price1', $member->getPrice1(), \PDO::PARAM_STR);
            $stmt->bindValue('Price2', $member->getPrice2(), \PDO::PARAM_STR);
            $stmt->bindValue('Price3', $member->getPrice3(), \PDO::PARAM_STR);
            $stmt->bindValue('Price4', $member->getPrice4(), \PDO::PARAM_STR);
            $stmt->bindValue('Price5', $member->getPrice5(), \PDO::PARAM_STR);
            $stmt->bindValue('Price6', $member->getPrice6(), \PDO::PARAM_STR);
            $stmt->bindValue('Price7', $member->getPrice7(), \PDO::PARAM_STR);
            $stmt->bindValue('Price8', $member->getPrice8(), \PDO::PARAM_STR);
            $stmt->bindValue('Price9', $member->getPrice9(), \PDO::PARAM_STR);
            $stmt->bindValue('Price10', $member->getPrice10(), \PDO::PARAM_STR);
            $stmt->bindValue('Price11', $member->getPrice11(), \PDO::PARAM_STR);
            $stmt->bindValue('Price12', $member->getPrice12(), \PDO::PARAM_STR);
            $stmt->execute();
            if ($tran) {
                $connection->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $connection->rollBack();
                throw $e;
            }

            return false;
        }
    }

      private function UpdateMemberSql()
  {
     $sql ='UPDATE AccountData SET '
      . 'No = :No, '
      . 'NGFlg = :NGFlg, '
      . 'Name = :Name, '
      . 'Company = :Company, '
      . 'AccountId = :AccountId, '
      . 'Pass = :Pass, '
      . 'Level = :Level, '
      . 'Class = :Class, '
      . 'PriceGroup = :PriceGroup, '
      . 'PMO = :PMO, '
      . 'Price1 = :Price1, '
      . 'Price2 = :Price2, '
      . 'Price3 = :Price3, '
      . 'Price4 = :Price4, '
      . 'Price5 = :Price5, '
      . 'Price6 = :Price6, '
      . 'Price7 = :Price7, '
      . 'Price8 = :Price8, '
      . 'Price9 = :Price9, '
      . 'Price10 = :Price10, '
      . 'Price11 = :Price11, '
      . 'Price12 = :Price12 '
      // . 'Area = :Area, '
      // . 'MailingList = :MailingList '
      . 'WHERE No = :No';
      return $sql; 
  }

    public function GetMemberData(
        EntityInterface $member,
        $tran = true,
        $date = null
    ) {
        if ($date === null) {
            $date = date('Y-m-d H:i;s');
        }
        try {
            if ($tran) {
                $this->db->beginTransaction();
            }
            $sql = $this->SelectMemberByIdSql();
            $stmt = $this->db->prepare($sql);
            $stmt->bindValue(':no', $member->getNumber(), \PDO::PARAM_INT);

            $stmt->execute();
            $member_data=$stmt->fetchAll();
            return $member_data ? $this->BuildAllmembers($member_data[0]) : false;
            if ($tran) {
                $this->db->commit();
                return true;
            }
        } catch (\Exception $e) {
            if ($tran) {
                $this->db->rollBack();
                throw $e;
            }

            return false;
        }
    }
  
  private function SelectMemberByIdSql()
  {
    $sql ='SELECT * FROM AccountData '
        . 'WHERE No = :no';
        return $sql;  
  }

  public function RemoveMemberById(
  EntityInterface $deletedata,
  $tran = true,
  $date = null
  ){
  if ($date === null) {
            $date = date('Ym');
    }
    try {
      if($tran)
        {
          $this->db->beginTransaction();
        }
      $sql = $this->RemoveMemberByIdSql();
      $stmt = $this->db->prepare($sql);
      $stmt->bindValue(':no', $deletedata->getNumber(), \PDO::PARAM_INT);
      $stmt->execute();

      if ($tran) {
            $this->db->commit();
      }
    } catch (Exception $e) {
      if ($tran) {
              $this->db->rollBack();
        }
    throw $e;
    }
}

  private function RemoveMemberByIdSql()
{

  $sql = 'DELETE FROM AccountData WHERE No = :no ';
  return $sql;
}



  private function inserttestSql()
  {
    $sql = 'INSERT INTO `AccountData` ('
      . '`No`,'
      . 'NGFlg,'
      . 'Name,'
      . 'Company,'
      . '`AccountId`,'
      . 'Pass,'
      . 'Level,'
      . 'Class,'
      . 'PriceGroup,'
      . 'PMO,'
      . 'Price1,'
      . 'Price2,'
      . 'Price3,'
      . 'Price4,'
      . 'Price5,'
      . 'Price6,'
      . 'Price7,'
      . 'Price8,'
      . 'Price9,'
      . 'Price10,'
      . 'Price11,'
      . 'Price12,'
      . 'Note,'
      . 'Area'
      // . 'MailingList,'

      . ') '
       .'VALUES ('
      . ':no,'
      . ':ngflag,'
      . ':name,'
      . ':company,'
      . ':accountid,'
      . ':pass,'
      . ':level,'
      . ':class,'
      . ':pricegroup,'
      . ':pmo,'
      . ':price1,'
      . ':price2,'
      . ':price3,'
      . ':price4,'
      . ':price5,'
      . ':price6,'
      . ':price7,'
      . ':price8,'
      . ':price9,'
      . ':price10,'
      . ':price11,'
      . ':price12,'
      . ':Note,'
      . ':Area'
      // . ':mailinglist,'

      .')';
  return $sql;
  }

        public function BuildAllmembers($paramaters)
        {
          $entity = new AllMembersEntity;
          $entity->setProperties($paramaters);
          return $entity;
        }

        public function BuildAllPMO($paramaters)
        {
          $entity = new AllMembersEntity;
          $entity->setProperties($paramaters);
          return $entity;
        }

        public function builAddMember($paramaters )
        {
          $entity = new AllMembersEntity;
          $entity->setProperties($paramaters);
          return $entity;
        }

      public function add(EntityInterface $entity)
      {
          return;
      }
      /**
       * @param EntityInterface $entity
       */
      public function remove(EntityInterface $entity)
      {
          return;
      }


	/**
     * Returns the values from a single column of the input array, identified by
     * the $columnKey.
     *
     * Optionally, you may provide an $indexKey to index the values in the returned
     * array by the values from the $indexKey column in the input array.
     *
     * @param array $input A multi-dimensional array (record set) from which to pull
     *                     a column of values.
     * @param mixed $columnKey The column of values to return. This value may be the
     *                         integer key of the column you wish to retrieve, or it
     *                         may be the string key name for an associative array.
     * @param mixed $indexKey (Optional.) The column to use as the index/keys for
     *                        the returned array. This value may be the integer key
     *                        of the column, or it may be the string key name.
     * @return array
     */
    function array_column($input = null, $columnKey = null, $indexKey = null)
    {
        // Using func_get_args() in order to check for proper number of
        // parameters and trigger errors exactly as the built-in array_column()
        // does in PHP 5.5.
        $argc = func_num_args();
        $params = func_get_args();

        if ($argc < 2) {
            trigger_error("array_column() expects at least 2 parameters, {$argc} given", E_USER_WARNING);
            return null;
        }

        if (!is_array($params[0])) {
            trigger_error('array_column() expects parameter 1 to be array, ' . gettype($params[0]) . ' given', E_USER_WARNING);
            return null;
        }

        if (!is_int($params[1])
            && !is_float($params[1])
            && !is_string($params[1])
            && $params[1] !== null
            && !(is_object($params[1]) && method_exists($params[1], '__toString'))
        ) {
            trigger_error('array_column(): The column key should be either a string or an integer', E_USER_WARNING);
            return false;
        }

        if (isset($params[2])
            && !is_int($params[2])
            && !is_float($params[2])
            && !is_string($params[2])
            && !(is_object($params[2]) && method_exists($params[2], '__toString'))
        ) {
            trigger_error('array_column(): The index key should be either a string or an integer', E_USER_WARNING);
            return false;
        }

        $paramsInput = $params[0];
        $paramsColumnKey = ($params[1] !== null) ? (string) $params[1] : null;

        $paramsIndexKey = null;
        if (isset($params[2])) {
            if (is_float($params[2]) || is_int($params[2])) {
                $paramsIndexKey = (int) $params[2];
            } else {
                $paramsIndexKey = (string) $params[2];
            }
        }

        $resultArray = array();

        foreach ($paramsInput as $row) {

            $key = $value = null;
            $keySet = $valueSet = false;

            if ($paramsIndexKey !== null && array_key_exists($paramsIndexKey, $row)) {
                $keySet = true;
                $key = (string) $row[$paramsIndexKey];
            }

            if ($paramsColumnKey === null) {
                $valueSet = true;
                $value = $row;
            } elseif (is_array($row) && array_key_exists($paramsColumnKey, $row)) {
                $valueSet = true;
                $value = $row[$paramsColumnKey];
            }

            if ($valueSet) {
                if ($keySet) {
                    $resultArray[$key] = $value;
                } else {
                    $resultArray[] = $value;
                }
            }

        }

        return $resultArray;
    }

}
