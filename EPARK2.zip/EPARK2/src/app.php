<?php

use Silex\Application;
use Silex\Provider\UrlGeneratorServiceProvider;
use Silex\Provider\SessionServiceProvider;
use Silex\Provider\ValidatorServiceProvider;
use Silex\Provider\ServiceControllerServiceProvider;
use Silex\Provider\HttpFragmentServiceProvider;
use Silex\Provider\DoctrineServiceProvider;
use Silex\Provider\TwigServiceProvider;
use Silex\Provider\SwiftmailerServiceProvider;

use App\Providers\UserAuthorizationServiceProvider;
use App\Providers\UserAdditionServiceProvider;
use App\Providers\MailServiceProvider;
use Hikaritsushin\Provider\HikaritsushinServiceProvider;
use App\Providers\HomeServiceProvider;

use App\Providers;

$app = new Application();

$app->register(new SessionServiceProvider());
$app->register(new UrlGeneratorServiceProvider());
$app->register(new ValidatorServiceProvider());
$app->register(new ServiceControllerServiceProvider());
$app->register(new HttpFragmentServiceProvider());
$app->register(new Silex\Provider\SessionServiceProvider());


// $db_options = array(
//         'driver' => 'pdo_mysql',
//         'dbname' => 'epark_report_manage',
//         'host' => 'localhost',
//         'user' => 'root',
//         'password' => '',
//         'charset' => 'utf8'
// );

$db_options = array(
        'driver' => 'pdo_mysql',
        'dbname' => 'epark_report_manage',
        'host' => 'localhost',
        'user' => 'root',
        'password' => '',
        'charset' => 'utf8'
);



// $db_options = array(
//         'driver' => 'pdo_mysql',
//         'dbname' => 'epark_report_manage2',
//         'host' => 'localhost',
//         'user' => 'root',
//         'password' => 'password',
//         'charset' => 'utf8'
// );


$app->register(new DoctrineServiceProvider(), array(
    'db.options' => $db_options
));
$app->register(new TwigServiceProvider());
$app->register(new Silex\Provider\SwiftmailerServiceProvider());

$swiftmailer_options = array(
    'host' => 'localhost',
    'port' => '25',
    'encryption' => null,
    'auth_mode' => null
);

//swiftmailer
$app->register(new SwiftmailerServiceProvider(),array(
    'swiftmailer.options' => $swiftmailer_options,
));

$app['twig'] = $app->share($app->extend('twig', function ($twig, $app) {
return $twig;
}));



// $app->register(new SessionServiceProvider(), array('session.storage.options' => array('cookie_lifetime' => (1800)))); //10 sec
// $app->register(new Silex\Provider\SessionServiceProvider(), array(
//         'session.storage.options' => array('cookie_lifetime' => (60 )), // 1 min
//     ));

//$app->register(new Providers\AgreementServiceProvider());

$app->register(new HikaritsushinServiceProvider(), array());
$app->register(new UserAdditionServiceProvider(), array());
$app->register(new UserAuthorizationServiceProvider(), array());
$app->register(new MailServiceProvider(), array());
$app->register(new Providers\UserServiceProvider());
$app->register(new Providers\LoginInfoServiceProvider());
$app->register(new Providers\HomeServiceProvider());
$app->register(new Providers\AllProjectServiceProvider());
$app->register(new Providers\AllMembersServiceProvider());
$app->register(new Providers\AddProjectServiceProvider());
$app->register(new Providers\CsvDownloadServiceProvider());
return $app;
