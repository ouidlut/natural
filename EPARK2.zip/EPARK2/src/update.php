<?php

/* HTML特殊文字をエスケープする関数 */
function h($str) {
	return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

//全レコード件数カウント
function recCount($pdo) {
	$sth = $pdo->query("SELECT count(*) FROM shop");
	return $sth->fetchColumn();
	
}

try {

    // 未定義である・複数ファイルである・$_FILES Corruption 攻撃を受けた
    // どれかに該当していれば不正なパラメータとして処理する
    if (!isset($_FILES['upfile']['error']) || !is_int($_FILES['upfile']['error'])) {
        throw new RuntimeException('パラメータが不正です');
    }

    // $_FILES['upfile']['error'] の値を確認
    switch ($_FILES['upfile']['error']) {
        case UPLOAD_ERR_OK: // OK
            break;
        case UPLOAD_ERR_NO_FILE:   // ファイル未選択
            throw new RuntimeException('ファイルが選択されていません');
        case UPLOAD_ERR_INI_SIZE:  // php.ini定義の最大サイズ超過
        case UPLOAD_ERR_FORM_SIZE: // フォーム定義の最大サイズ超過 (設定した場合のみ)
            throw new RuntimeException('ファイルサイズが大きすぎます');
        default:
            throw new RuntimeException('その他のエラーが発生しました');
    }

    // ここで定義するサイズ上限のオーバーチェック
    // (必要がある場合のみ)
    if ($_FILES['upfile']['size'] > 1000000) {
        throw new RuntimeException('ファイルサイズが大きすぎます');
    }
	
	$name = $_FILES['upfile']['name'];
	$tmp_name = $_FILES['upfile']['tmp_name'];
	$detect_order = 'ASCII,JIS,UTF-8,CP51932,SJIS-win';
	setlocale(LC_ALL, 'ja_JP.UTF-8');

	if (!strpos($name , ".csv")) {
		throw new RuntimeException('ファイル形式が不正です');
	}

    // $_FILES['upfile']['mime']の値はブラウザ側で偽装可能なので
    // MIMEタイプに対応する拡張子を自前で取得する
    if (!$ext = array_search(
        mime_content_type($tmp_name),
        array(
            'csv' => 'text/plain'
        ),
        true
    )) {
        throw new RuntimeException('ファイル形式が不正です');
    }
	
	/* 文字コードを変換してファイルを置換 */
	$buffer = file_get_contents($tmp_name);
	if (!$encoding = mb_detect_encoding($buffer, $detect_order, true)) {
		// 文字コードの自動判定に失敗
		unset($buffer);
		throw new RuntimeException('Character set detection failed');
	}
	file_put_contents($tmp_name, mb_convert_encoding($buffer, 'UTF-8', $encoding));
	unset($buffer);
	
	//データベース選択
	$pdo = new PDO(
		'mysql:dbname=dailyreport;host=localhost;charset=utf8',
		'root',
		'',
		array(
			 // カラム型に合わない値がINSERTされようとしたときSQLエラーとする
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET SESSION sql_mode='TRADITIONAL'",
                // SQLエラー発生時にPDOExceptionをスローさせる
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                // プリペアドステートメントのエミュレーションを無効化する
                PDO::ATTR_EMULATE_PREPARES => false,
		)
	);
	
	//$stmt = $pdo->prepare('UPDATE shop SET clientName = ?, orderDay = ?, company = ?, completeDay = ? WHERE clientID = ?');
	$stmt = $pdo->prepare('INSERT INTO shop (clientID, clientName, orderDay, company, completeDay) VALUES (?, ?, ?, ?, ?)
								ON DUPLICATE KEY UPDATE
									clientName = ?, orderDay = ?, company = ?, completeDay = ?');

	/* トランザクション処理 */
	$pdo->beginTransaction();
	try {
		$fp = fopen($tmp_name, 'rb');
		fgetcsv($fp);
		while ($row = fgetcsv($fp)) {
			
			$count = recCount($pdo);
			$error = "";
			
			if($row === array(null)) {
				//　空行はスキップ
				continue;
			}
			
			if (count($row) !== 5) {
				$error = 'データ項目数が誤っています';
			} else if ($row[0] === "" or $row[1] === "" or $row[2] === "" or $row[3] === "") {
				if ($row[0] === "") {
					$error .= '顧客IDが入力されていません<br>';
					$row[0] = '顧客ID不明';
				}
				if ($row[1] === "") {
					$error .= '顧客名が入力されていません<br>';
				}
				if ($row[2] === "") {
					$error .= "受注日が入力されていません<br>";
				}				
				if ($row[3] === "") {
					$error .= "会社名が入力されていません";
				}
			} else {
				if ($row[4] === "") {
					$row[4] = NULL;
				} 
				$row[] = $row[1];
				$row[] = $row[2];
				$row[] = $row[3];
				$row[] = $row[4];
								
				$executed = $stmt->execute($row);
				$error = "OK: ";
				
				$newCount = recCount($pdo);
				if ($newCount === $count) {
					$error .= "更新";
				} else {
					$error .= "新規追加";
				}
			}
			
			$clientIDs[] = $row[0];
			$results[] = $error;
			
		}
		if(!feof($fp)) {
			throw new RuntimeException('読み込みの途中でエラーが発生しました');
		}
		fclose($fp);
		$pdo->commit();
	} catch(Exception $e) {
		fclose($fp);
		$pdo->rollBack();
		throw $e;
	}
	
	if (isset($executed)) {
		//一回以上実行された
		$msg = array('green', '新規作成・更新成功');
	} else {
		//一回も実行されていない
		$msg = array('black', '新規作成・更新できるデータはありませんでした');
	}
	
	} catch (Exception $e) {
		$msg = array('red', $e->getMessage());
	}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>確認</title>
</head>
<body>
	<fieldset>
		<legend>処理結果</legend>
		<span style="color:<?=h($msg[0])?>;"><?=h($msg[1])?></span>
	</fieldset>
	<table border=1>
		<tr>
			<td>顧客ID</td>
			<td>更新結果</td>
		</tr>
		<?php
			while ((list(, $clientID) = each($clientIDs)) && (list(, $result) = each($results)) ) {
				echo "<tr>";
				echo "<td>".$clientID."</td><td>".$result."</td>";
				echo "</tr>";
			}
		?>
	</table>
</body>
</html>