<?php

use Symfony\Component\Console\Application;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputOption;

$console = new Application('My Silex Application', 'n/a');
$console->getDefinition()->addOption(new InputOption('--env', '-e', InputOption::VALUE_REQUIRED, 'The Environment name.', 'dev'));
$console->setDispatcher($app['dispatcher']);
$console
    ->register('export_application_csv')
    ->setDefinition(array(
        // new InputOption('some-option', null, InputOption::VALUE_NONE, 'Some help'),
    ))
    ->setDescription('My command description')
    ->setCode(function (InputInterface $input, OutputInterface $output) use ($app) {
        $app['monolog']->addInfo('export_start');
        $result = $app['application_output.usecase']->exportApplicationForCsv();
        if (!$result) {
            echo '書き込むデータがありません。';
            $app['monolog']->addError('書き込むデータがありません。');
        }
        $app['monolog']->addInfo('end');
    })
;

$console
    ->register('export_application_detail_csv')
    ->setDefinition(array(
        // new InputOption('some-option', null, InputOption::VALUE_NONE, 'Some help'),
    ))
    ->setDescription('My command description')
    ->setCode(function (InputInterface $input, OutputInterface $output) use ($app) {
        $app['monolog']->addInfo('export_start');
        $result = $app['application_output.usecase']->exportApplicationDetailForCsv();
        if (!$result) {
            echo '書き込むデータがありません。';
            $app['monolog']->addError('書き込むデータがありません。');
        }
        $app['monolog']->addInfo('end');
    })
;
//
// $console
//     ->register('export_dantotsu_csv')
//     ->setDescription('My command description')
//     ->setCode(function (InputInterface $input, OutputInterface $output) use ($app) {
//         $app['monolog']->addInfo('export_start');
//         $result = $app['application_output.usecase']->exportCsvForDantotsu();
//         if (!$result) {
//             echo '書き込むデータがありません。';
//             $app['monolog']->addError('書き込むデータがありません。');
//         }
//         $app['monolog']->addInfo('end');
//     })
// ;
return $console;
