<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ja" lang="ja">
    <head>
    
    </head>
    
    <body> 
        <?php
		 	$st = 15000;
			//$st = 0;
			$FLG = 0;
			include_once 'db_link.php';
			$findRequest = array();
			$findRequest[0] = $data->newFindRequest('daily');
			$findRequest[0]->addFindCriterion('record_id', '*');
			//$findRequest[0]->addFindCriterion('record_id', '17680');
			$compoundFind = $data->newCompoundFindCommand('daily');
			$compoundFind->add(1, $findRequest[0]);
			$compoundFind->setRange($st, 1000);
			$result = $compoundFind->execute();	
			if (FileMaker::isError($result))	 {
				/* ERROR*********************************** */
				$Subject = '[FM ERROR] '.str_replace('/'.basename(__FILE__), "", str_replace("/Users/hti/html/", "", __FILE__));
				$mysql_error = 'ERROR DIRECTORY ---> '.str_replace('/'.basename(__FILE__), "", str_replace("/Users/hti/html/", "", __FILE__)).'/...'.chr(13).chr(10).'ERROR FILE ---> '.basename(__FILE__).chr(13).chr(10).chr(13).chr(10).
					'ERROR POINT ---> '.(__LINE__-1).' $mysql_error'.chr(13).chr(10).'ERROR NO ---> '.mysql_errno().chr(13).chr(10).'ERROR ---> '.$result->getMessage();
				/* ***************************************** */				
			}else{
				$foundCount = $result->getFoundSetCount();
				$records = $result->getRecords();
				$i = 0;
				$Mcn = 1;
				$cn1 = 0;
				$cn2 = 0;
				$step = 100/1000;
				foreach ($records as $record)	{
					$cn2 = ($cn1/100)*100;
					$cn1 = $cn1+$step;
					$record_id = $record->getField('record_id');
					$ReNo = $record->getField('ReNo');
					$record_id = $record->getField('record_id');
					if($Mcn == 1){
						$Start = $record_id;
					}
					$work_date = date('Y-m-d', strtotime($record->getField('work_date')));
					$work_id = $record->getField('work_id');
					$work_name = $record->getField('work_name');
					$pj_cd = $record->getField('pj_cd');
					$pj_name = $record->getField('pj_name');
					$process = $record->getField('process');
					$note = $record->getField('note');
					
					$cn = 1;
					while( $cn <= 31 ){
						$day[$cn] = $record->getField('day'.$cn);
						$cn++;
					}
					$total_time = $record->getField('total_time');
					$money = $record->getField('in_money');
					$com_exp = $record->getField('in_com');
					$total_money = $record->getField('in_mc');
					$array01 = $record->getField('array01');
					
					include_once 'Link_Sql.php';	
					mysql_set_charset('utf8');
					$result = mysql_query("INSERT INTO daily(record_id, work_date, work_id, work_name,  pj_cd, pj_name, process, note, day1, day2, day3, day4, day5, day6, day7, day8, day9, day10, day11, day12, day13, day14, day15, day16, day17, day18, 
					day19, day20, day21, day22, day23, day24, day25, day26, day27, day28, day29, day30, day31, total_time, money, com_exp, total_money, array01)	VALUES('$record_id', '$work_date', '$work_id', '$work_name', '$pj_cd', '$pj_name', '$process', '$note', '$day[1]', '$day[2]', '$day[3]', 
					'$day[4]', '$day[5]', '$day[6]', '$day[7]', '$day[8]', '$day[9]', '$day[10]', '$day[11]', '$day[12]', '$day[13]', '$day[14]', '$day[15]', '$day[16]', '$day[17]', '$day[18]', '$day[19]', '$day[20]', '$day[21]', '$day[22]', '$day[23]', '$day[24]', '$day[25]', 
					'$day[26]', '$day[27]', '$day[28]', '$day[29]', '$day[30]', '$day[31]', '$total_time', '$money', '$com_exp', '$total_money', '$array01')", $link);
					if (!$result) {
						echo $record_id.'<br/>';
						echo 'NEXT → '.($st+$i);
						/* ERROR*********************************** */
						$Subject = '[SQL ERROR] '.str_replace('/'.basename(__FILE__), "", str_replace("/Users/hti/html/", "", __FILE__));
						$mysql_error = 'ERROR DIRECTORY ---> '.str_replace('/'.basename(__FILE__), "", str_replace("/Users/hti/html/", "", __FILE__)).'/...'.chr(13).chr(10).'ERROR FILE ---> '.basename(__FILE__).chr(13).chr(10).chr(13).chr(10).
							'ERROR POINT ---> '.(__LINE__-1).' $mysql_error'.chr(13).chr(10).'ERROR NO ---> '.mysql_errno().chr(13).chr(10).'ERROR ---> '.mysql_error();
						echo mysql_error().'<br/>';
						/* ***************************************** */
						$FLG = 1;
					}
					$Mcn++;
					$i++;
				}
			}
			if($FLG == 0){
				echo 'OK → '.$i.'<br/>';
				if($i < 1000){
					echo 'END';
				}else{
					echo 'Last → '.$record_id.'<br/>';
					echo 'NEXT → '.($st+1000);
				}
			}else{
				echo 'NG';
			}
			/*$url = 'https://hti3.majestic.jp/iflag/iflag01/Trigger1.php';
			header("Location: $url");
			exit;*/
		?>
    </body> 
</html>